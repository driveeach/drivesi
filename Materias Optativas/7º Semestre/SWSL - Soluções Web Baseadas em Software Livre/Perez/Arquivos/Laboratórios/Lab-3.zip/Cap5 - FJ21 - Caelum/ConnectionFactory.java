package Dao;

import java.sql.*;
import java.util.Enumeration;

public class ConnectionFactory {
	
	public Connection getConnection() {
		System.out.println("Conectando ao banco");
		try {
			return DriverManager.getConnection("jdbc:postgresql:postgres://localhost:5432/postgres", "postgres", "m0b1l3p@d");
					
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
				
	}
}