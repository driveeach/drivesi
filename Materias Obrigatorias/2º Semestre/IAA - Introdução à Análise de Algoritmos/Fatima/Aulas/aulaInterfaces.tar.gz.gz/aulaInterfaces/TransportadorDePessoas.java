interface TransportadorDePessoas
{
  void entramPessoas();
  void saemPessoas();
}