class Quitanda2
{
  // define array e construtor
  Fruta [] frutas = new Fruta [5];
  
  public Quitanda2()
  {
    frutas [0] = new Fruta ("Laranja", 0.2, 0.5);
    frutas [1] = new Fruta ("Kiwi", 0.1, 2);
    frutas [2] = new Fruta ("Mam�o", 1.5, 1.2);
    frutas [3] = new Fruta ("Pera", 0.3, 1.7);
    frutas [4] = new Fruta ("Banana", 0.3, 0.2);
  }
  
  // imprime frutas
  
  public void imprime()
  {
    for (int i = 0; i < frutas.length; i++)
      frutas [i].imprime();
  }
  
  // ordena por Pre�o
  // m�todo inser��o direta
  void ordena (ComparadorDeFrutas c)
  {
    int ivet, isubv;
    Fruta frutaAInserir;
    
    for (ivet=1; ivet < frutas.length; ivet++) 
    {
      
      frutaAInserir = frutas[ivet]; 
      isubv = ivet;
      
      while ((isubv > 0) && (c.ehMenor(frutaAInserir, frutas [isubv -1]) ))  
      {
        frutas[isubv] = frutas[isubv - 1];
        isubv--;
      }
      frutas [isubv] = frutaAInserir;

    }
  }

  // m�todo principal que invoca os demais
  public static void main (String [] args)
  {
    Quitanda2 xepa = new Quitanda2();
    
    System.out.println("Frutas desordenadas");
    xepa.imprime();
    
    System.out.println("Em ordem de pre�o");
    ComparadorDeFrutas cpr = new ComparaPreco();
    xepa.ordena(cpr);
    xepa.imprime();
    
    System.out.println("Em ordem de peso");
    ComparadorDeFrutas cp = new ComparaPeso();
    xepa.ordena(cp);
    xepa.imprime();

    System.out.println("Em ordem alfab�tica de nome");
    xepa.ordena(new ComparaNome ()); // forma super contra�da de chamar o m�todo ordena
    xepa.imprime();
  }
  
}