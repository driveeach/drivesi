class Zoologico
{
  static void cicloDeVida (Animal animal)
  {
    animal.nas�a();
    animal.passeiePelaTela();
    animal.durma();
  }
  
  static public void fazFuncionar()
  {
    Zebra zebraPequena = new Zebra(50, 105); // cria zebra a partir da classe Zebra
    Animal zebraGrande = new Zebra(230,160); // cria zebra a partir da classe Animal
    Animal morceguinho = new Morcego();
    Morcego m = new Morcego();
    Pato p= new Pato (3.2);
    
    cicloDeVida(zebraPequena);
    cicloDeVida(zebraGrande);
    cicloDeVida(m);
    cicloDeVida(p);
    cicloDeVida(morceguinho);   
  }
}