class Onibus implements TransportadorDePessoas
{
  public void entramPessoas()
  { 
    System.out.println ("Abre a porta para as pessoas entrarem");
  }
  public void saemPessoas()
  {
    System.out.println ("Abre a porta para as pessoas sa�rem");
  }
}