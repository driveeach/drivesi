class Quitanda
{
  // define array e construtor
  Fruta [] frutas = new Fruta [5];
  
  public Quitanda()
  {
    frutas [0] = new Fruta ("Laranja", 0.2, 0.5);
    frutas [1] = new Fruta ("Kiwi", 0.1, 2);
    frutas [2] = new Fruta ("Mam�o", 1.5, 1.2);
    frutas [3] = new Fruta ("Pera", 0.3, 1.7);
    frutas [4] = new Fruta ("Banana", 0.3, 0.2);
  }
  
  // imprime frutas
  
  public void imprime()
  {
    for (int i = 0; i < frutas.length; i++)
      frutas [i].imprime();
  }
  
  // ordena por Pre�o
  // m�todo inser��o direta
    void ordenaPorPreco ()
  {
    int ivet, isubv;
    Fruta frutaAInserir;
    
    for (ivet=1; ivet < frutas.length; ivet++) 
    {
      
      frutaAInserir = frutas[ivet]; 
      isubv = ivet;
      
      while ((isubv > 0) && (frutas [isubv -1].preco > frutaAInserir.preco))  
      {
        frutas[isubv] = frutas[isubv - 1];
        isubv--;
      }
      frutas [isubv] = frutaAInserir;

    }
  }

  // ordena por Peso
  void ordenaPorPeso ()
  {
    int ivet, isubv;
    Fruta frutaAInserir;
    
    for (ivet=1; ivet < frutas.length; ivet++) 
    {
      
      frutaAInserir = frutas[ivet]; 
      isubv = ivet;
      
      while ((isubv > 0) && (frutas [isubv -1].peso > frutaAInserir.peso))  
      {
        frutas[isubv] = frutas[isubv - 1];
        isubv--;
      }
      frutas [isubv] = frutaAInserir;

    }
  } 
  
  // m�todo principal que invoca os demais
  public static void main (String [] args)
  {
    Quitanda xepa = new Quitanda();
    
    System.out.println("Desordenado");
    xepa.imprime();
    System.out.println("Em ordem de pre�o");
    xepa.ordenaPorPreco();
    xepa.imprime();
    System.out.println("Em ordem de peso");
    xepa.ordenaPorPeso();
    xepa.imprime();
  }
  
}