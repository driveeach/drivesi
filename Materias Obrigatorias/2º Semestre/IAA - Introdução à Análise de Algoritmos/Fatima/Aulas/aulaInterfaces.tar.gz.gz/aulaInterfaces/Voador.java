interface Voador
{
  void voa();
  void aterrisa();
}
  