public class Morcego implements Animal
{

   public void nas�a()
   {
      System.out.println("Nasceu um morceguinho...");
   }

   public void passeiePelaTela()
   {
      System.out.println("Voo r�pido e rasante !!!");
   }

  public void durma()
   {
      System.out.println("Dorme de cabe�a para baixo.");
   }

  public double peso()
   {
      System.out.println("Este � um morcego gordo!");
      return (4.5);
   }

}