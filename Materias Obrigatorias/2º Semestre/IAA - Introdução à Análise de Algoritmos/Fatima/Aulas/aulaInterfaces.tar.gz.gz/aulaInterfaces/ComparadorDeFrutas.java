interface ComparadorDeFrutas
{
  boolean ehMenor (Fruta a, Fruta b);
}