public class Pato implements Animal
{

   double peso;

   Pato(double p)
   {
      peso = p;
   }
   
   public void nas�a()
   {
      System.out.println("Quebra o ovo.");
   }

  public void passeiePelaTela()
   {
      System.out.println("Anda em duas patas. Qu� Qu� Qu�.");
   }

  public void durma()
   {
      System.out.println("Dorme em p�.");
   }

  public double peso()
   {
      return peso;
   }

}
