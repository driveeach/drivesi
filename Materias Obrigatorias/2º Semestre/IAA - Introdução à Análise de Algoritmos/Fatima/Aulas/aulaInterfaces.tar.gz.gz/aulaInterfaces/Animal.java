interface Animal
{
   void nas�a();
   void passeiePelaTela();
   void durma();
   double peso();
}
