class TestaInterface
{
  static public void executa()
  {
    TransportadorDePessoas t = new Onibus();
    Voador v = new Ave();
    Aviao a  = new Aviao();
  
    t.entramPessoas();
    t.saemPessoas();
    v.voa();
    v.aterrisa();
    a.entramPessoas();
    a.voa();
  }
}