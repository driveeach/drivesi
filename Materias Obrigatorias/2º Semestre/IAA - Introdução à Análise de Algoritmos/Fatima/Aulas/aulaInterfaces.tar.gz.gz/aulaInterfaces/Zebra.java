public class Zebra implements Animal
{

   double peso;
   int listras;
   
   Zebra(double p, int l)
   {
      peso = p;
      listras =l;
   }
   
   public void nas�a()
   {
      System.out.println("Zebrinha beb� nascendo...");
   }

   public void passeiePelaTela()
   {
     System.out.println("Zebra galopa pela tela.");
   }

   public void durma()
   {
     System.out.println("Zebra dorme sem roncar.... zzzzzzzzzzzzzzzz...");
   }

   public double peso()
   {
     return peso;
   }

   public void exibeListras()
   {
     System.out.println("Minha zebra tem " + listras + " listras.");
   }

}
