class Fruta
{
  String nome;
  double preco, peso;
  
  Fruta (String n, double p, double pr)
  {
    nome = n;
    peso = p;
    preco = pr;
  }
    
  void imprime()
  {
  System.out.print("Nome: " + nome);
  System.out.print( " Peso: " + peso);
  System.out.println(" Pre�o: " + preco);
  }
}