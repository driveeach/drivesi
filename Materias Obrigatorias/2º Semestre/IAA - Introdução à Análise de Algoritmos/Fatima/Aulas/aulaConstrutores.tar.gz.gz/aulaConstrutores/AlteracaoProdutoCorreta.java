class AlteracaoProdutoCorreta
{
  void alteraProduto()
  {
    Produto p = new Produto(67.9,34, 900);
    p.subtraiEstoque(800);
    p.imprimeDados();
    p.adicionaEstoque(153);
    p.imprimeDados();
  }
}