class Produto
{
  private double _preco;
  private int _codigo;
  private int _quantidade;
  
  Produto (double p, int c, int q)
  {
     _preco = p;
     _codigo = c;
     _quantidade = q;
  } 

  Produto (int c, int q)
  {
     _codigo =c;
     _quantidade = q;
  }
  
  Produto (int c)
  {
     this (10,c,100);
  }

  void imprimeDados()
  {
    System.out.println("Pre�o = " + _preco);
    System.out.println("C�digo = " + _codigo);
    System.out.println("Quantidade = " + _quantidade); 
  }

  void subtraiEstoque(int qtde)
  {
     if (qtde > _quantidade)
     {
       System.out.println("Quantidade em estoque insuficiente.");
       imprimeDados();
     }
     else
     {
        _quantidade = _quantidade - qtde;
        System.out.println("Atualiza��o realizada");
     }
  }

  void adicionaEstoque(int qtde)
  {
    _quantidade = _quantidade + qtde;
     imprimeDados();
  }

}