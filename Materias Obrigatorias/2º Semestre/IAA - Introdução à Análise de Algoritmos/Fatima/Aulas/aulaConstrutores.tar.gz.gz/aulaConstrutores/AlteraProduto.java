class AlteracaoProduto
{
  void alteraProduto()
  {
    Produto p = new Produto(67.9,34, 900);
    p._quantidade = p_quantidade - 800;
  }
}