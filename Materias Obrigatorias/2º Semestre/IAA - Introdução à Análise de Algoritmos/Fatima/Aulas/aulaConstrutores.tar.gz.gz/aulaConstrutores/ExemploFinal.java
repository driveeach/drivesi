class ExemploFinal2
{
  static final double PI;
  static void imprimeValor()
  {
    PI = 21;
    System.out.println("Valor de PI:" + PI);     
  }
}