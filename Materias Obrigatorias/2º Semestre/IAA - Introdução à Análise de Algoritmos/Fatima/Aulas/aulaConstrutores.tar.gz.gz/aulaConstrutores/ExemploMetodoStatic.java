class ExemploMetodoStatic
{
   static int _quantidade = 768;
   static void imprimeValor()
   {
     System.out.println("Valor do atributo _quantidade:" + _quantidade); 
   }
}