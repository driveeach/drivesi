package ep1.so;

import java.util.Collections;
import java.util.LinkedList;

//recebem uma lista de eventos, realizam as operacoes conforme a pol�tica e retornam um log
class PoliticasDeEscalonamento
{
	
	
	static Log FCFS(LinkedList<Processo> listaDeProcessos)
	{
		int relogio = 0,
			tempoTotalDeEspera= 0,
			numeroDeProcessos = listaDeProcessos.size();
		LinkedList<Evento> listaDeEventos = new LinkedList<Evento>();
		LinkedList<Processo> filaDeProntos = new LinkedList<Processo>();
		boolean cpulivre = true;
			
		while(!listaDeProcessos.isEmpty() || !filaDeProntos.isEmpty())
		{
			while (!listaDeProcessos.isEmpty() && listaDeProcessos.element().getInstanteDeChegada() == relogio) //processo chegou
			{
				Processo pronto = listaDeProcessos.remove();
				filaDeProntos.add(pronto);
				listaDeEventos.add(new Evento(pronto, 0)); //chegada de processo
			}//end while
			if (!filaDeProntos.isEmpty())
			{
				Processo executando = filaDeProntos.element();
				executando.consumirBurst();
				
				if (cpulivre)
				{
					listaDeEventos.add(new Evento(executando, 1, relogio)); //processo obtem CPU
					cpulivre = false;
				}//end if
				
				relogio++;
				tempoTotalDeEspera += filaDeProntos.size()-1;
				
				if (executando.isConcluido())
				{
					filaDeProntos.remove();
					listaDeEventos.add(new Evento(executando, 2, relogio)); //processo devolve CPU
					cpulivre = true;
				}//end if
				continue; //segue para a proxima itera��o
			}//end if
			
			//tratamento da situa��o de CPU idle
			relogio++;
		}//end while
		
		//gera��o do log
		return new Log("FCFS", listaDeEventos, (double) tempoTotalDeEspera/numeroDeProcessos);
	}//end FCFS()
	
	static Log SJF (LinkedList<Processo> listaDeProcessos)
	{
		int relogio = 0,
			tempoTotalDeEspera = 0,
			numeroDeProcessos = listaDeProcessos.size();
		LinkedList<Evento> listaDeEventos = new LinkedList<Evento>();
		LinkedList<Processo> filaDeProntos = new LinkedList<Processo>();
		boolean cpulivre = true;
		
		
		while(!listaDeProcessos.isEmpty() || !filaDeProntos.isEmpty())
		{
			while (!listaDeProcessos.isEmpty() && listaDeProcessos.element().getInstanteDeChegada() == relogio) //processo chegou
			{
				Processo pronto = listaDeProcessos.remove();
				filaDeProntos.add(pronto);
				listaDeEventos.add(new Evento(pronto, 0)); //chegada de processo
				Collections.sort(filaDeProntos, new OrdenadorSJF()); //ordena��o dos prontos pelo burst //s� mudou essa linha!!!!!
			}//end while
			if (!filaDeProntos.isEmpty())
			{
				Processo executando = filaDeProntos.element();
				executando.consumirBurst();
				if (cpulivre)
				{
					listaDeEventos.add(new Evento(executando, 1, relogio)); //processo obtem CPU
					cpulivre = false;
				}//end if
				relogio++;
				tempoTotalDeEspera += filaDeProntos.size()-1;
				if (executando.isConcluido())
				{
					filaDeProntos.remove();
					listaDeEventos.add(new Evento(executando, 2, relogio)); //processo devolve CPU
					cpulivre = true;
				}//end if
				continue; //segue para a proxima itera��o
			}//end if
			//tratamento da situa��o de CPU idle
			relogio++;
		}//end while

		//gera��o do log
		return new Log("SJF", listaDeEventos, (double) tempoTotalDeEspera/numeroDeProcessos);
	}//end SJF()
	
	static Log SRTF (LinkedList<Processo> listaDeProcessos)
	{
		int relogio = 0,
			tempoTotalDeEspera= 0,
			numeroDeProcessos = listaDeProcessos.size();
		LinkedList<Evento> listaDeEventos = new LinkedList<Evento>();
		LinkedList<Processo> filaDeProntos = new LinkedList<Processo>();
		boolean cpulivre = true;
	
		while(!listaDeProcessos.isEmpty() || !filaDeProntos.isEmpty())
		{	
			while (!listaDeProcessos.isEmpty() && listaDeProcessos.element().getInstanteDeChegada() == relogio)
			{
				Processo pronto = listaDeProcessos.remove();
				if (!filaDeProntos.isEmpty() && pronto.getBurst() < filaDeProntos.element().getBurst())
				{
					listaDeEventos.add(new Evento(filaDeProntos.element(), 3, relogio));  //evento anterior preemptado
					filaDeProntos.addFirst(pronto); //novo processo entra no inicio da fila
					listaDeEventos.add(new Evento(pronto, 0)); //registra evento chegada de processo
					cpulivre = true;
				}//end if
				else
				{
					filaDeProntos.add(pronto); //adiciona o processo � fila de prontos
					listaDeEventos.add(new Evento(pronto, 0));  //registra evento chegada de processo
					Collections.sort(filaDeProntos, new OrdemDeBurst()); //manter ordena��o dos demais, verificar se � possivel inserir ordenado
				}//end else
			}//end while
			if (!filaDeProntos.isEmpty())
			{
				Processo executando = filaDeProntos.element();
				//bloco para o processo que obtem CPU
				if (cpulivre)
				{
					listaDeEventos.add(new Evento(executando, 1, relogio)); //processo obtem CPU
					cpulivre = false;
				}//end if
				executando.consumirBurst();
				relogio++;
				tempoTotalDeEspera += filaDeProntos.size()-1;
				//bloco para tratar processo concluido
				if (executando.isConcluido())
				{
					filaDeProntos.remove();
					listaDeEventos.add(new Evento(executando, 2, relogio)); //processo devolve CPU
					cpulivre = true;
				}//end if
				continue; //segue para a proxima itera��o
			}//end if
			//tratamento da situa��o de CPU idle
			relogio++;
		}//end while
		
		//gera��o do log
		return new Log("SRTF", listaDeEventos, (double) tempoTotalDeEspera/numeroDeProcessos);
	}//end SRTF()


	
	static Log RR (LinkedList<Processo> listaDeProcessos, int quantum) //recebe o quantum de tempo para a preemp��o
	{
		int relogio = 0,
			tempoTotalDeEspera= 0,
			quantumRestante = quantum,
			numeroDeProcessos = listaDeProcessos.size();
		LinkedList<Evento> listaDeEventos = new LinkedList<Evento>();
		LinkedList<Processo> filaDeProntos = new LinkedList<Processo>();
		boolean cpulivre = true;
		
		while(!listaDeProcessos.isEmpty() || !filaDeProntos.isEmpty())
		{
			
			//agendador
			while (!listaDeProcessos.isEmpty() && listaDeProcessos.element().getInstanteDeChegada() == relogio)
			{
				Processo pronto = listaDeProcessos.remove();
				filaDeProntos.add(pronto);
				listaDeEventos.add(new Evento(pronto, 0)); //chegada de processo
			}//end while
			
			if (!filaDeProntos.isEmpty())
			{
				//bloco para o caso do processo que ser� preemptado
				if (quantumRestante == 0)
				{
					Processo preemptado = filaDeProntos.remove();
					filaDeProntos.addLast(preemptado);//coloca o elemento no final da lista
					listaDeEventos.add(new Evento(preemptado, 3, relogio));//processo preemptado
					cpulivre = true;
				}//end if
				
				Processo executando = filaDeProntos.element();//obter o primeiro processo da fila
				
				//bloco para o registrar evento processo que obtem CPU
				if (cpulivre)
				{
					quantumRestante = quantum; //conceder quantidade de quantum
					listaDeEventos.add(new Evento(executando, 1, relogio)); //registrar evento
					cpulivre = false;
				}//end if

				relogio++;
				tempoTotalDeEspera += filaDeProntos.size()-1;
				executando.consumirBurst();
				quantumRestante--;
				
				//bloco para o caso do processo ter sido concluido
				if (executando.isConcluido())
				{
					executando = filaDeProntos.remove();
					listaDeEventos.add(new Evento(executando, 2, relogio)); 	//processo devolveu CPU
					cpulivre = true;
				}//end if
				
				continue;//segue para a proxima itera��o
			}//end if
			
			relogio++; //tratamento da situa��o de CPU idle
		}//end while
		
		//calculo do tempo m�dio de espera
		double tempoMedioDeEspera = (double) tempoTotalDeEspera/numeroDeProcessos;
		//gera��o do log
		return new Log("RR", listaDeEventos, tempoMedioDeEspera);
	}//end RR
	
	static Log P (LinkedList<Processo> listaDeProcessos)
	{
		int relogio = 0,
			tempoTotalDeEspera = 0,
			numeroDeProcessos = listaDeProcessos.size();
		LinkedList<Evento> listaDeEventos = new LinkedList<Evento>();
		LinkedList<Processo> filaDeProntos = new LinkedList<Processo>();
		boolean cpulivre = true;
		
		
		while(!listaDeProcessos.isEmpty() || !filaDeProntos.isEmpty())
		{
			while (!listaDeProcessos.isEmpty() && listaDeProcessos.element().getInstanteDeChegada() == relogio) //processo chegou
			{
				Processo pronto = listaDeProcessos.remove();
				if (!filaDeProntos.isEmpty() && pronto.getPrioridade() < filaDeProntos.element().getPrioridade())
				{
					filaDeProntos.addFirst(pronto);
					listaDeEventos.add(new Evento(pronto, 0)); //chegada de processo
				}
				else
				{
					filaDeProntos.add(pronto);
					listaDeEventos.add(new Evento(pronto, 0)); //chegada de processo
					Collections.sort(filaDeProntos, new OrdemDePrioridade());
				}
			}//end while
			if (!filaDeProntos.isEmpty())
			{
				Processo executando = filaDeProntos.element();
				executando.consumirBurst();
				if (cpulivre)
				{
					listaDeEventos.add(new Evento(executando, 1, relogio)); //processo obtem CPU
					cpulivre = false;
				}//end if
				relogio++;
				tempoTotalDeEspera += filaDeProntos.size()-1;
				if (executando.isConcluido())
				{
					filaDeProntos.remove();
					listaDeEventos.add(new Evento(executando, 2, relogio)); //processo devolve CPU
					cpulivre = true;
				}//end if
				continue; //segue para a proxima itera��o
			}//end if
			//tratamento da situa��o de CPU idle
			relogio++;
		}//end while

		//gera��o do log
		return new Log("P", listaDeEventos, (double) tempoTotalDeEspera/numeroDeProcessos);
	}//end P
	
	
	static Log PP (LinkedList<Processo> listaDeProcessos)
	{
		int relogio = 0,
			tempoTotalDeEspera= 0,
			numeroDeProcessos = listaDeProcessos.size();
		LinkedList<Evento> listaDeEventos = new LinkedList<Evento>();
		LinkedList<Processo> filaDeProntos = new LinkedList<Processo>();
		boolean cpulivre = true;
	
		while(!listaDeProcessos.isEmpty() || !filaDeProntos.isEmpty())
		{	
			while (!listaDeProcessos.isEmpty() && listaDeProcessos.element().getInstanteDeChegada() == relogio)
			{
				Processo pronto = listaDeProcessos.remove();
				if (!filaDeProntos.isEmpty() && pronto.getPrioridade() < filaDeProntos.element().getPrioridade())
				{
					listaDeEventos.add(new Evento(filaDeProntos.element(), 3, relogio));  //evento anterior preemptado
					filaDeProntos.addFirst(pronto); //novo processo entra no inicio da fila
					listaDeEventos.add(new Evento(pronto, 0)); //registra evento chegada de processo
					cpulivre = true;
				}//end if
				else
				{
					filaDeProntos.add(pronto); //adiciona o processo � fila de prontos
					listaDeEventos.add(new Evento(pronto, 0));  //registra evento chegada de processo
					Collections.sort(filaDeProntos, new OrdemDePrioridade()); //manter ordena��o dos demais, verificar se � possivel inserir ordenado
				}//end else
			}//end while
			if (!filaDeProntos.isEmpty())
			{
				Processo executando = filaDeProntos.element();
				//bloco para o processo que obtem CPU
				if (cpulivre)
				{
					listaDeEventos.add(new Evento(executando, 1, relogio)); //processo obtem CPU
					cpulivre = false;
				}//end if
				executando.consumirBurst();
				relogio++;
				tempoTotalDeEspera += filaDeProntos.size()-1;
				//bloco para tratar processo concluido
				if (executando.isConcluido())
				{
					filaDeProntos.remove();
					listaDeEventos.add(new Evento(executando, 2, relogio)); //processo devolve CPU
					cpulivre = true;
				}//end if
				continue; //segue para a proxima itera��o
			}//end if
			//tratamento da situa��o de CPU idle
			relogio++;
		}//end while

		//gera��o do log
		return new Log("PP", listaDeEventos, (double) tempoTotalDeEspera/numeroDeProcessos);
	}//end PP
	
	
	//nesse trecho me enrolei, talvez volte se der tempo!
	/*

	static double MQ (LinkedList<Processo> listaDeProcessos, int quantum, int porcentagemPP) //multiplas filas
	{
		int relogio = 0,
			turno = 0,
			tempoTotalDeEspera= 0;
		LinkedList<Evento> listaDeEventos = new LinkedList<Evento>();
		LinkedList<Processo> filaDePrimeiroPlano = new LinkedList<Processo>(),
						filaDeSegundoPlano = new LinkedList<Processo>();
		boolean cpulivre = true;
		
		while(!listaDeProcessos.isEmpty() || !filaDePrimeiroPlano.isEmpty() || !filaDeSegundoPlano.isEmpty())
		{
			
			while (!listaDeProcessos.isEmpty() && listaDeProcessos.element().getInstanteDeChegada() == relogio)
			{
				//selecionar a fila segundo crit�rio tamanho do burst
				Processo pronto = listaDeProcessos.remove();
				
				if (pronto.getBurst() < 10)
				{
					filaDePrimeiroPlano.add(pronto);
					listaDeEventos.add(new Evento(pronto, 0, "primeiro plano")); //chegada de processo na primeira fila
				}//end if
				else
				{
					filaDeSegundoPlano.add(pronto);
					listaDeEventos.add(new Evento(pronto, 0, "segundo plano")); //chegada de processo na segunda fila
				}//end else
			}//end while
			
			
			//executa o primeiro plano
			if (!filaDePrimeiroPlano.isEmpty())
			{
				Processo executando = filaDePrimeiroPlano.remove(); //obter o primeiro processo da fila
				
				//bloco para o processo que obtem CPU
				if (cpulivre)
				{
					listaDeEventos.add(new Evento(executando, 1, relogio));
					cpulivre = false;
				}//end if
				//armazenar o tempo restante da fila
				int tempoRestante = (porcentagemPP-turno%10);
				//bloco para o caso do processo que ser� preemptado
				if (tempoRestante < quantum)
				{
					//consome o tempo restante
					if (tempoRestante < executando.getBurst())
					{
						relogio += tempoRestante;
						turno += tempoRestante;
						tempoTotalDeEspera += tempoRestante*filaDePrimeiroPlano.size();
						executando.consumirBurst(tempoRestante);
						filaDePrimeiroPlano.addLast(executando);//coloca o elemento no final da lista
						listaDeEventos.add(new Evento(executando, 3, relogio));//processo preemptado
						cpulivre = true;
					}
					//conclui o processo
					else
					{
						relogio += executando.getBurst();
						turno += executando.getBurst();
						tempoTotalDeEspera += executando.getBurst()*filaDePrimeiroPlano.size();
						executando.consumirBurst(executando.getBurst());
						listaDeEventos.add(new Evento(executando, 2, relogio)); 	//processo devolveu CPU
						cpulivre = true;
					}
				}
				else
				{
					//consome o quantum
					if (tempoRestante >= quantum)
					{
						relogio += quantum;
						turno += quantum;
						tempoTotalDeEspera += quantum*filaDePrimeiroPlano.size();
						executando.consumirBurst(quantum);
						filaDePrimeiroPlano.addLast(executando);//coloca o elemento no final da lista
						listaDeEventos.add(new Evento(executando, 3, relogio));//processo preemptado
						cpulivre = true;
					}
					//consome o tempo restante
					else
					{
						relogio += tempoRestante;
						turno += tempoRestante;
						tempoTotalDeEspera += tempoRestante*filaDePrimeiroPlano.size();
						executando.consumirBurst(tempoRestante);
						filaDePrimeiroPlano.addLast(executando);//coloca o elemento no final da lista
						listaDeEventos.add(new Evento(executando, 3, relogio));//processo preemptado
						cpulivre = true;
					}
				}
				continue;//segue para a proxima itera��o
			}//end if
			
			listaDeEventos.add(new Evento(4, relogio)); //troca de filas
			
			if (!filaDeSegundoPlano.isEmpty() && (turno%10 > porcentagemPP || filaDePrimeiroPlano.isEmpty()))
			{
				Processo executando = filaDeSegundoPlano.element();
				executando.consumirBurst();
				turno++;
				if (cpulivre)
				{
					listaDeEventos.add(new Evento(executando, 1, relogio, "segundo plano")); //processo obtem CPU
					cpulivre = false;
				}//end if
				relogio++;
				turno++;
				tempoTotalDeEspera += filaDeSegundoPlano.size()-1;
				if (executando.isConcluido())
				{
					filaDeSegundoPlano.remove();
					listaDeEventos.add(new Evento(executando, 2, relogio, "segundo plano")); //processo devolve CPU
					cpulivre = true;
				}//end if
				if (!filaDePrimeiroPlano.isEmpty() && turno%10 == 0)
					listaDeEventos.add(new Evento(executando, 3, relogio, "segundo plano")); //processo preemptado
				continue; //segue para a proxima itera��o
			}//end if
			
			
			//tratamento da situa��o de CPU idle
			turno++;
			relogio++;
		}//end while
		imprimirLOG(listaDeEventos);
		return tempoTotalDeEspera;
	}//end MQ
	
	static void MFQ (LinkedList<Processo> processo) //fila multinivel com realimentacao
	{
		
	}
	
	*/
}
