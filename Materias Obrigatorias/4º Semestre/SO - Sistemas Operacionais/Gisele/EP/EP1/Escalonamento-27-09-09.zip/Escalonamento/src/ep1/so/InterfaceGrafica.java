package ep1.so;


import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class InterfaceGrafica extends JFrame
{
	public InterfaceGrafica()
	{
		super("Escolha o algoritmo desejado!");
		setLayout(new FlowLayout());
		
		JTextField j = new JTextField("Autores: Leila Chan & Murilo Honorio");
		j.setEditable(false);
		add(j, BorderLayout.NORTH);
		
		//cria os bot�es para cada algoritmo
		JButton FCFS = new JButton("FCFS");
		JButton SJF = new JButton("SJF");
		JButton SRTF = new JButton("SRTF");
		JButton RR = new JButton("RR");
		JButton P = new JButton("P");
		JButton PP = new JButton("PP");
		
		//adiciona os bot�es ao frame
		add(FCFS);
		add(SJF);
		add(SRTF);
		add(RR);
		add(P);
		add(PP);
		
		//cria o tratador de eventos
		TratamentoDosBotoes tb = new TratamentoDosBotoes();
		FCFS.addActionListener(tb);
		SJF.addActionListener(tb);
		SRTF.addActionListener(tb);
		RR.addActionListener(tb);
		P.addActionListener(tb);
		PP.addActionListener(tb);
	}
	
	//classe interna que trata os bot�es
	class TratamentoDosBotoes implements ActionListener
	{
		public void actionPerformed(ActionEvent a)
		{
			
			try 
			{
				String opcao = a.getActionCommand();
				
				//abre uma janela solicitando o nome do arquivo que cont�m o cen�rio
				String arquivo = JOptionPane.showInputDialog(null, "Digite o nome do arquivo desejado!", "arquivo que contenha cen�rio");
				
				// executa um cen�rio, de acordo com o algoritmo escolhido, chamando o leitor de processos para ler o arquivo e guarda num objeto log
				Log log = null;
				
				if (opcao.compareTo("FCFS") == 0)
				{
					log = PoliticasDeEscalonamento.FCFS(LeitorDeProcessos.lerEventosDoArquivo(arquivo));
				}
				if (opcao.compareTo("SJF") == 0)
				{
					log = PoliticasDeEscalonamento.SJF(LeitorDeProcessos.lerEventosDoArquivo(arquivo));
				}
				if (opcao.compareTo("SRTF") == 0)
				{
					log = PoliticasDeEscalonamento.SRTF(LeitorDeProcessos.lerEventosDoArquivo(arquivo));
				}
				if (opcao.compareTo("RR") == 0)
				{
					//abre uma janela solicitando o tamanho do quantum, converte de String para int
					int quantum = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do quantum.", ""));
				
					if (quantum > 0)
						log = PoliticasDeEscalonamento.RR(LeitorDeProcessos.lerEventosDoArquivo(arquivo), quantum);
					else
						JOptionPane.showMessageDialog(null, "Quantum com tamanho inadequado.","Erro", 0);	
				}
				if (opcao.compareTo("P") == 0)
				{
					log = PoliticasDeEscalonamento.P(LeitorDeProcessos.lerEventosDoArquivo(arquivo));
				}
				if (opcao.compareTo("PP") == 0)
				{
					log = PoliticasDeEscalonamento.PP(LeitorDeProcessos.lerEventosDoArquivo(arquivo));
				}
				
				if (log != null)
				{
					arquivo = JOptionPane.showInputDialog(null, "Digite o nome do arquivo de log!", "aten��o para a extens�o e local");
					
					//gravar no disco
					log.gravarLog(arquivo);
					// cria o painel que cont�m o diagrama de Gantt, passando a lista de eventos contida no log
					DiagramaGantt d = new DiagramaGantt(log.getListaDeEventos());
					
					// cria o frame que armazena o painel, apresentando algoritmo e
					// tempo m�dio de espera no t�tulo
					JFrame simulador = new JFrame("Algoritmo: " + log.getNomeDoAlgoritmo() + "; Tempo M�dio de Espera: " + log.getTempoDeEspera());

					// adiciona o painel ao frame
					simulador.add(d);

					// configura o frame para ser encerrado quando for fechado
					simulador.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					// configura o tamanho da janela largura, altura
					simulador.setSize(640, 200);
					// colocar a janela no centro da tela, em Java 1.4 ou superior
					simulador.setLocationRelativeTo(null);
					// torna a janela vis�vel
					simulador.setVisible(true);
				}
				
				

			} 
			catch (FileNotFoundException e) 
			{
				JOptionPane.showMessageDialog(null, "Arquivo n�o encontrado.","Erro", 0);
			}
			catch (NullPointerException e) 
			{
				JOptionPane.showMessageDialog(null, "Opera��o cancelada.","Informa��o", 1);
			}
			catch (Exception e) 
			{
				JOptionPane.showMessageDialog(null, "Opera��o cancelada.","Informa��o", 1);
			}
		}
		
	}
}