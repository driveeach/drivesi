package ep1.so;
import java.util.Comparator;

//a negative integer, zero, or a positive integer as the first argument is less than, equal to, or greater than the second. 
class OrdenadorSJF implements Comparator<Processo>
{
		public int compare(Processo arg0, Processo arg1) 
		{
			if (arg0.getInstanteDeChegada() == arg1.getInstanteDeChegada()) //caso ambos tenham o mesmo tempo de entrada, escolhe o menor burst
				return arg0.getBurst()-arg1.getBurst();
			else
				return arg0.getInstanteDeChegada()-arg1.getInstanteDeChegada();
		}
}
