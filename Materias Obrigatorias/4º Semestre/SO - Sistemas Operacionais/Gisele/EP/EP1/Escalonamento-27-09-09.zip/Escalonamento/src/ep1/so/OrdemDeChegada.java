package ep1.so;
import java.util.Comparator;

class OrdemDeChegada implements Comparator<Processo>
{
		public int compare(Processo arg0, Processo arg1) 
		{ 
			return arg0.getInstanteDeChegada()-arg1.getInstanteDeChegada();
		}
}