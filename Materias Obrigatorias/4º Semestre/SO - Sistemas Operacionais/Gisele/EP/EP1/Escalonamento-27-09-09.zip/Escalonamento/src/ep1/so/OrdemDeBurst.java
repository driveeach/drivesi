package ep1.so;
import java.util.Comparator;

class OrdemDeBurst implements Comparator<Processo>
{
		public int compare(Processo arg0, Processo arg1) 
		{
			if (arg0.getBurst() == arg1.getBurst())
				return arg0.getInstanteDeChegada()-arg1.getInstanteDeChegada();
			else
				return arg0.getBurst()-arg1.getBurst();
		}
}