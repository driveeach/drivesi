package ep1.so;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.JPanel;

@SuppressWarnings("serial")
class DiagramaGantt extends JPanel
{
	LinkedList<Evento> listaDeEventos;
	
	//construtor recebe uma lista de eventos e gera o diagrama
	DiagramaGantt(LinkedList<Evento> listaDeEventos)
	{
		this.listaDeEventos = listaDeEventos;
	}

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		//tempo do ultimo evento da lista
		int tempoTotal = listaDeEventos.getLast().getTempo();
		//sinaliza se mais de um evento chegou ao mesmo tempo
		boolean chegou = false;
		
		//cria iterador que desenhar� o gr�fico
		Iterator<Evento> it = listaDeEventos.listIterator();
		
		//pinta o fundo de branco
		g.setColor(Color.white);
		g.fillRect(0, 0, getWidth(), getHeight());
		
		g.setColor(Color.black);
		
		//desenha linhas horizontais mais grossas
		g.drawLine(0, 30, getWidth(), 30);
		g.drawLine(0, 31, getWidth(), 31);
		g.drawLine(0, 32, getWidth(), 32);
		g.drawLine(0, getHeight()-30, getWidth(), getHeight()-30);
		g.drawLine(0, getHeight()-31, getWidth(), getHeight()-31);
		g.drawLine(0, getHeight()-32, getWidth(), getHeight()-32);

		
		while(it.hasNext())
		{
			Evento e = it.next(); //obtem primeiro evento da lista
			int posicaoX = (getWidth()*e.getTempo())/tempoTotal; //calcula a posicao relativa
			String pid = e.getPID();//obtem o pid 
			String tempo = String.valueOf(e.getTempo());//converte o tempo em formato de String
			
			
			//marcador evento chega no sistema
			if (e.getTipo() == 0)
			{
				//s� imprime o primeiro, no caso de processos que chegam ao mesmo tempo
				if (!chegou)
				{
					//linha vertical
					g.drawLine(posicaoX, 15, posicaoX, 30);
					//identificador na posicao
					g.drawString(pid, posicaoX+5, 20);
				}
				chegou = true;
			}//end if
			
			
			//marcador do evento: processo ganha cpu
			if (e.getTipo() == 1)
			{
				chegou = false;
				
				//linha vertical no tempo indicado
				g.drawLine(posicaoX, 30, posicaoX, getHeight()-30);
				//g.drawLine(posicaoX+1, 30, posicaoX+1, getHeight()-30);
				//coloca o identificador no meio
				g.drawString(pid, posicaoX+5, getHeight()/2);
				//coloca o tempo em baixo
				g.drawString(tempo, posicaoX, getHeight()-10);
			}//end if
			
			
			//marcador do evento: processo perde cpu
			if (e.getTipo() == 2)
			{
				chegou = false;
				
				
				//linha vertical
				//g.drawLine(posicaoX-1, 30, posicaoX-1, getHeight()-30);
				g.drawLine(posicaoX, 30, posicaoX, getHeight()-30);
				//coloca o identificador no meio
				g.drawString(pid, posicaoX-20, getHeight()/2);
				//coloca o tempo em baixo
				g.drawString(tempo, posicaoX, getHeight()-10);
				
				//ultimo evento
				if (!it.hasNext())
				{
					//coloca o tempo final no diagrama
					g.drawString(String.valueOf(tempoTotal), getWidth()-15, getHeight()-10);
				}
			}//end if
		}//end while
	}//end paintComponent
}
