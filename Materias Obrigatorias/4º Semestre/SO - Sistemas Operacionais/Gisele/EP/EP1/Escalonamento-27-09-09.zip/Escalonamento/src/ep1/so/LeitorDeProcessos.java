package ep1.so;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

class LeitorDeProcessos
{
	//m�todo que l� os eventos contidos em uma arquivo testo tabulado com as caracteristicas dos processos
	//e retorna uma lista de processos
	static LinkedList<Processo> lerEventosDoArquivo(String nomeDoArquivo) throws FileNotFoundException
	{
		
		LinkedList<Processo> listaDeProcessos = new LinkedList<Processo>();
		File cenario = new File(nomeDoArquivo);
		Scanner leitor = new Scanner(cenario);
		String PID;
		int instanteDeOcorrencia, 
			burst, 
			prioridade;
		
		//ignorar cabe�alho
		leitor.nextLine();
		leitor.nextLine();
		
		//ler os par�metros do cen�rio e criar os jobs
		while(leitor.hasNext())
		{
			PID = leitor.next();
			instanteDeOcorrencia = leitor.nextInt();
			burst = leitor.nextInt(); 
			prioridade = leitor.nextInt(); 
			
			Processo atual = new Processo(PID, instanteDeOcorrencia, burst, prioridade);
			listaDeProcessos.add(atual);
		}
		
		//ordenar os processos lidos pelo instante 
		Collections.sort(listaDeProcessos, new OrdemDeChegada());
		return listaDeProcessos;
	}
}
