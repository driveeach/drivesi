package ep1.so;

public class Processo
{

	private String PID;
	private int instanteDeChegada,
				burst, 
				prioridade;
	private boolean completado = false;
	
	Processo(String PID, int instanteDeChegada, int burst, int prioridade)
	{
		this.PID = PID;
		this.instanteDeChegada = instanteDeChegada;
		this.burst = burst;
		this.prioridade = prioridade;
	}
	
	public String getPID()
	{
		return PID;
	}

	public int getInstanteDeChegada()
	{
		return instanteDeChegada;
	}

	public int getBurst()
	{
		return burst;
	}	
	
	public int getPrioridade()
	{
		return prioridade;
	}
	
	public boolean isConcluido()
	{
		return completado;
	}
	
	public void consumirBurst()
	{
		if (this.burst > 0)
			this.burst--;
		if (this.burst == 0)
			this.completado = true;
	}

	public void envelhecer()
	{
		if (this.prioridade > 0)
			this.prioridade = prioridade--;
	}
}
