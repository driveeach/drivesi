package ep1.so;

import javax.swing.JFrame;

public class Main 
{
	public static void main(String args[])
	{      
		InterfaceGrafica i = new InterfaceGrafica();
		// configura o frame para ser encerrado quando for fechado
		i.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// configura o tamanho da janela largura, altura
		i.setSize(640, 100);
		// colocar a janela no centro da tela, em Java 1.4 ou superior
		i.setLocationRelativeTo(null);
		// torna a janela vis�vel
		i.setVisible(true);
	}
	
}