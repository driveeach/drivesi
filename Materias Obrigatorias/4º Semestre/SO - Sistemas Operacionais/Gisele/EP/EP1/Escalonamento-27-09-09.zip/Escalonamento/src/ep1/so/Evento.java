package ep1.so;

class Evento implements Comparable<Evento>

{
	private int tempo,			//representa a momento de ocorrencia do evento
				tipoDeEvento;				//representa o tipo de evento que ocorreu
	private String PID;			//identificador �nico do processo		
	
	//construtor para evento: chegada de processo ao sistema
	Evento(Processo j, int tipoDeEvento)
	{
		this.PID = j.getPID();
		this.tipoDeEvento = tipoDeEvento;
		if (tipoDeEvento == 0)
			this.tempo = j.getInstanteDeChegada();
		else
			System.out.println("Construtor com par�metro inadequado.");
	}
	
	//construtor para eventos: processo obtem tempo de CPU, processo devolve CPU, processo preemptado
	Evento(Processo j, int tipoDeEvento, int tempoDeExecucao)
	{
		this.PID = j.getPID();
		this.tipoDeEvento = tipoDeEvento;
		if (tipoDeEvento != 0)
			this.tempo = tempoDeExecucao;
		else
			System.out.println("Construtor com par�metro inadequado.");
	}
	
	//retorna o PID do processo na forma de vetor de chars
	String getPID()
	{
		return this.PID;
	}
	//informa o instante em que o evento ocorreu
	int getTempo()
	{
		return this.tempo;
	}
	
	//informa o tipo de evento
	int getTipo()
	{
		return this.tipoDeEvento;
	}
	
	//imprime informa��es referentes ao evento
	String gerarLOG()
	{
		switch(this.tipoDeEvento)
		{
			case 0: return new String("Processo " + this.PID + " chegou no instante " + this.tempo + ".");
			case 1: return new String("Processo " + this.PID + " obteve a CPU no instante " + this.tempo + ".");
			case 2: return new String("Processo " + this.PID + " devolveu a CPU no instante " + this.tempo + ".");
			case 3: return new String("Processo " + this.PID + " preemptado no instante " + this.tempo + ".");
			case 4: return new String("Processo " + this.PID + " envelheceu no instante " + this.tempo + ".");
			case 5: return new String("Troca de filas.");
			default: return new String("");
		}
	}

	public int compareTo(Evento outroEvento) throws ClassCastException
	{
		if (!(outroEvento instanceof Evento))
			throw new ClassCastException("Um objeto Evento era esperado.");
		int tempoDoOutroEvento = (outroEvento).getTempo();
		return this.tempo - tempoDoOutroEvento;
	}
}


