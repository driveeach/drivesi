package ep1.so;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

//armazena uma lista de eventos, o nome do algoritmo utilizado, o tempo m�dio de espera
class Log 
{
	private String algoritmo,					//algoritmo de escalonamento utilizado
				   arquivo;						//arquivo do cen�rio selecionado
				    				//tempo m�dio de espera 
	private LinkedList<Evento> listaDeEventos;
	private double tempoDeEspera;
	
	
	Log(String nomeDoAlgoritmo, LinkedList<Evento> listaDeEventos, double tempoDeEspera)
	{
		this.algoritmo = nomeDoAlgoritmo;
		this.listaDeEventos = listaDeEventos;
		this.tempoDeEspera = tempoDeEspera;
	}
	
	public void imprimirLOG()
	{
		Collections.sort(this.listaDeEventos);
		Iterator<Evento> log = this.listaDeEventos.listIterator();
		
		while (log.hasNext())
		{
			log.next().gerarLOG();
		}//end while
	}//end imprimirLOG()
	
	public void gravarLog(String nomeDoArquivo) 
	{
		File cenario = new File(nomeDoArquivo);
		
		try 
		{
			DataOutputStream fos = new DataOutputStream(new FileOutputStream(cenario));
			
			Collections.sort(this.listaDeEventos);
			Iterator<Evento> log = this.listaDeEventos.listIterator();
			
			while (log.hasNext())
			{
				String x = log.next().gerarLOG();
				char[] c = x.toCharArray();
				
				for (int i = 0; i < c.length; i++)
					fos.write(c[i]);
				
				//nova linha
				fos.writeChars("\n");
			}
		} 
		catch (Exception e)
		{
			//erro
		}
		
	}


	public String getNomeDoAlgoritmo()
	{
		return this.algoritmo;
	}//end getNomeDoAlgoritmo()
	
	public String getArquivo()
	{
		return this.arquivo;
	}//end getNomeDoAlgoritmo()
	
	
	//retorna o tempo de espera formatado com duas casas decimais
	public String getTempoDeEspera()
	{
		//cria um objeto que formata a sa�da em duas casas decimais, arredondando para cima
		DecimalFormat aproximarDuasCasas = new DecimalFormat("0.00");
		
		return aproximarDuasCasas.format(this.tempoDeEspera);
	}//end getTempoDeEspera()
	
	public LinkedList<Evento> getListaDeEventos()
	{
		return this.listaDeEventos;
	}//end getListaDeEventos()
}
