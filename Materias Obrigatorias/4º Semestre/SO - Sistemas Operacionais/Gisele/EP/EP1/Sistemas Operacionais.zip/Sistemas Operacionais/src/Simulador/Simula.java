package Simulador;

import java.util.*;

public class Simula {
	List< Processo > list = new ArrayList< Processo >();
	
	void firstComeFirstOut (ArrayList<Processo> processo){
		
	}
	
	void jobMaisCurto (ArrayList<Processo> processo){
		
	}
	
	void porPrioridade (ArrayList<Processo> processo){
		
	}
	
	void roundRobin (ArrayList<Processo> processo){
		
	}
	
	void multiplasFilas (ArrayList<Processo> processo){
		
	}
	
	void multiplasFilasComRealimentacao (ArrayList<Processo> processo){
		
	}	
}
