
public class RealAttribute extends Attribute {

	public RealAttribute() {
		super("", 0);
	}
	
	public RealAttribute(String name, double value) {
		super(name, value);
	}
	
	public RealAttribute(String name, String value) {
		super(name, value);
	}

}
