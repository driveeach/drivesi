package model;

import java.util.ArrayList;
import java.util.List;

public class Atributo {
	
	String nome;
	private List<String> dominioDeValores;	//os valores possiveis
	boolean continuo = true;
	
	public Atributo(String nome) 
	{
		this.nome = nome;
		this.dominioDeValores = new ArrayList<String>();
	}
	
	public Atributo(String nome, boolean continuo) 
	{
		this.nome = nome;
		this.dominioDeValores = new ArrayList<String>();
		this.continuo = continuo;
	}
	
	public void adicionarValorAoDominio(String valor)
	{
		this.dominioDeValores.add(valor);
	}
	
	public boolean valorExiste(String valor)
	{
		if (this.dominioDeValores.contains(valor)) return true;
		else return false;
	}

	public String nome() 
	{
		return this.nome;
	}

	public List<String> dominio() {
		return dominioDeValores;
	}

	public boolean ehContinuo() {
		return this.continuo;
	}
}
