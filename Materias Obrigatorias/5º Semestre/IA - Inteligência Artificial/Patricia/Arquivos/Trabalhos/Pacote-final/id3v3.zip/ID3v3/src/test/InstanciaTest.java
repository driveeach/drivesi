package test;

import model.Instancia;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class InstanciaTest {

	String[] valores = {"old", "swr", "up"};
	Instancia i;
	@Before
	public void setUp() throws Exception {
		i = new Instancia(valores);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testInstancia() {
		Instancia x = new Instancia(valores);
		System.out.println(x.imprimir());
	}

	@Test
	public void testClasse() {
		System.out.println(i.classe());
	}

	@Test
	public void testImprimir() {
		System.out.println("i > " + i.imprimir());
	}

}
