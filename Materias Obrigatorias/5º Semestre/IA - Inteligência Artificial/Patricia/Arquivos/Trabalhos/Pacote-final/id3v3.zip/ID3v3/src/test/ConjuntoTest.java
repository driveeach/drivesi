package test;

import model.Atributo;
import model.Conjunto;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import util.EP;

public class ConjuntoTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	
	public void test() throws Exception {
		Conjunto c = EP.leitura("./dataset/playtennis.data");
		Conjunto d = c.clone();

		c.removerExemplo(0);
		d.removerExemplo(3);
		d.removerExemplo(11);
		//System.out.println(c.imprimir());
		//System.out.println(d.imprimir());

		Conjunto p = EP.leitura("./dataset/adult2.data");
		System.out.println(p.imprimir());
	}

	
	public void testParticao() throws Exception
	{
		Conjunto c = EP.leitura("./dataset/playtennis.data");

		Atributo a = c.atributos().get(0);
		String val = a.dominio().get(0);
		Conjunto d = EP.particao(c, a, val);

		System.out.println("Parti��o: \n" + d.imprimir());

		a = c.atributos().get(1);
		val = a.dominio().get(1);
		//System.out.println(c.imprimir());
		d = EP.particao(c, a, val);
		//System.out.println("Parti��o: \n" + d.imprimir());

		Conjunto p = EP.leitura("./dataset/adult2.data");
		a = p.atributos().get(14);
		val = a.dominio().get(0);
		d = EP.particao(p, a, val);
		//System.out.println(d.imprimir());
	}

	
	public void testParticoes() throws Exception
	{
		Conjunto c = EP.leitura("./dataset/vaiesperar.data");
		System.out.println("Entropia total: " + EP.calcularEntropia(7, 17));
		Atributo a = c.atributos().get(0);
		Conjunto []sub = EP.particao(c, a);

		for (Conjunto x : sub) 
		{
			System.out.println("\n" + x.imprimir());
			a = x.atributos().get(1);
			System.out.println("Ganho de " + a.nome() + ":" + EP.ganho(x, a));
		}
	}
	
	@Test
	public void testArvore() throws Exception
	{
		Conjunto c = EP.leitura("./dataset/vaiesperar.data");
		System.out.println("Entropia total: " + EP.calcularEntropia(7, 17));
		Atributo a = EP.maiorGanho(c);
		System.out.println("Maior ganho: " + a.nome());
		Conjunto []sub = EP.particao(c, a);

		int i = 0;
		for (Conjunto x : sub) 
		{
			System.out.println(a.dominio().get(i) + ":" + x.imprimir());
			i++;
		}
		
		a = EP.maiorGanho(sub[1]);
		System.out.println("Maior ganho: " + a.nome());
		Conjunto []sub2 = EP.particao(sub[1], a);
		i = 0;
		for (Conjunto x : sub2) 
		{
			System.out.println(a.dominio().get(i) + ":" + x.imprimir());
			i++;
		}
		
		a = EP.maiorGanho(sub2[0]);
		Conjunto []sub3 = EP.particao(sub2[0], a);
		i = 0;
		for (Conjunto x : sub3) 
		{
			System.out.println(a.dominio().get(i) + ":" + x.imprimir());
			i++;
		}
	}
	
	
	public void testEntropia() throws Exception
	{
		Conjunto c = EP.leitura("./dataset/playtennis.data");
		Atributo a = c.atributos().get(3);
		
		double entropia = EP.entropia(c, a, a.dominio().get(0));
		System.out.println(a.nome() + ": " + entropia);
		entropia = EP.entropia(c, a, a.dominio().get(1));
		System.out.println(a.nome() + ": " + entropia);
	}
	
	
	public void testGanho() throws Exception
	{
		Conjunto c = EP.leitura("./dataset/playtennis.data");
		Atributo a = c.atributos().get(3);
		double ganho = EP.ganho(c, a);
		
		System.out.println("Ganho " + a.nome() + ": " + ganho);
		
		Atributo m = EP.maiorGanho(c);
		System.out.println("Maior ganho: " + m.nome());
		
		Conjunto []sub = EP.particao(c, EP.maiorGanho(c));

		for (Conjunto x : sub)
		{
			a = EP.maiorGanho(x);
			System.out.println(">Maior ganho: " + a.nome());
		}
	}
	
	
	public void testDiscretizar() throws Exception
	{
		Conjunto c = EP.leitura("./dataset/adult-04101112.data");
		Atributo a = c.atributos().get(2);
		EP.discretizar(c, a);
		EP.gravar(c, "./dataset/adult-discrete.data");
	}
	
	
	public void testGravar() throws Exception
	{
		Conjunto c = EP.leitura("./dataset/playtennis.data");
		Atributo a = c.atributos().get(0);
		Conjunto []sub = EP.particao(c, a);
		EP.gravar(sub[1], "./dataset/novo.data");
	}
}
