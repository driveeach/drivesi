package test;

import java.util.List;

import model.Atributo;
import model.Conjunto;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import util.EP;

public class AtributoTest {

	Conjunto c;
	@Before
	public void setUp() throws Exception {
		c = EP.leitura("./dataset/playtennis.data");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		for (Atributo a : c.atributos())
		{
			System.out.print(a.nome() + ">");
			List<String> valores = a.dominio();
			System.out.println(valores.toString());
		}
	}

}
