package util;

/*
 * Copyright (c) 1995, 2008, Oracle and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Oracle or the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

/**
 * This application that requires the following additional files:
 *   TreeDemoHelp.html
 *    arnold.html
 *    bloch.html
 *    chan.html
 *    jls.html
 *    swingtutorial.html
 *    tutorial.html
 *    tutorialcont.html
 *    vm.html
 */
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeSelectionModel;

import model.Atributo;
import model.Conjunto;
import model.No;

@SuppressWarnings("serial")
public class TreeDemo extends JPanel
implements TreeSelectionListener {
	private JTree tree;
	private static boolean DEBUG = false;
	public No raiz;
	//Optionally play with line styles.  Possible values are
	//"Angled" (the default), "Horizontal", and "None".
	private static boolean playWithLineStyle = false;
	private static String lineStyle = "Horizontal";

	//Optionally set the look and feel.
	private static boolean useSystemLookAndFeel = true;

	private static Conjunto conjunto;
	
	public TreeDemo() {
		super(new GridLayout(1,0));
		
		try 
		{
			conjunto = EP.leitura("./dataset/adult-discrete.data");
		} 
		catch (Exception e) 
		{
			System.out.println("Erro de leitura de arquivo.");
		}

		//criar os n�s
		DefaultMutableTreeNode pai = new DefaultMutableTreeNode(conjunto.classe().nome());

		No raiz = new No(null, -1, false); //ponteiro para a arvore

		//Constru��o da �rvore
		String valorDaMaioria = EP.valorDaMaioria(conjunto);
		//int total = criarNos(raiz, 0, pai, conjunto, valorDaMaioria);
		int total = criarNos2(pai, conjunto, valorDaMaioria);
		System.out.println(total);

		//Create a tree that allows one selection at a time.
		tree = new JTree(pai);
		tree.getSelectionModel().setSelectionMode
		(TreeSelectionModel.SINGLE_TREE_SELECTION);

		//Listen for when the selection changes.
		tree.addTreeSelectionListener(this);

		if (playWithLineStyle) {
			System.out.println("line style = " + lineStyle);
			tree.putClientProperty("JTree.lineStyle", lineStyle);
		}

		//Create the scroll pane and add the tree to it. 
		JScrollPane treeView = new JScrollPane(tree);

		Dimension minimumSize = new Dimension(300, 300);
		treeView.setMinimumSize(minimumSize);
		add(treeView);
	}

	/** Required by TreeSelectionListener interface. */
	public void valueChanged(TreeSelectionEvent e) {
		DefaultMutableTreeNode node = (DefaultMutableTreeNode)
				tree.getLastSelectedPathComponent();

		if (node == null) return;

		Object nodeInfo = node.getUserObject();
		if (node.isLeaf()) {
			String book = (String)nodeInfo;
			//displayURL(book);
			if (DEBUG) {
				System.out.print(book + ":  \n    ");
			}
		} else {
			//displayURL(helpURL); 
		}
		if (DEBUG) {
			System.out.println(nodeInfo.toString());
		}
	}

	private static int criarNos2(DefaultMutableTreeNode pai, Conjunto c, String padrao) 
	{
		int total = 1;
		DefaultMutableTreeNode folha;
		//verificar se todos os exemplos s�o da mesma classe, 
		//caso afirmativo retorna string que representa a classe, por exempo 'sim' ou 'n�o'
		//caso negativo retorna uma string vazia
		String classe = EP.todosDaMesmaClasse(c); 
		//se n�o h� exemplos retornar padr�o
		if (c.exemplos().size() == 0) 
		{
			//visualizacao
			folha = new DefaultMutableTreeNode(padrao);
			pai.add(folha);
		}
		//se n�o h� atributos retornar o valor da maioria, padrao
		else if (c.atributos().size() < 2)
		{
			folha = new DefaultMutableTreeNode(padrao);
			pai.add(folha);
			return 0;
		}
		//retorna a classe ou "" caso haja exemplos de ambas as classes
		else if (!classe.equals(""))
		{
			folha = new DefaultMutableTreeNode(classe);
			pai.add(folha);
			return 0;
		}
		else
		{
			//escolher o atributo que melhor divide o conjunto
			Atributo melhor = EP.maiorGanho(c);
			//adiciona o atributo � arvore - essa parte s� serve para visualiza��o
			//AQUI � SOMENTE A REPRESENTA��O DO ATRIBUTO ESCOLHIDO - SERIA O NOME QUE VAI NA ARESTA
			DefaultMutableTreeNode atributo;
			atributo = new DefaultMutableTreeNode(melhor.nome() + "(" + melhor.dominio().size() + ")");
			pai.add(atributo);

			//define o valor padrao como sendo a classe da maioria
			String valorDaMaioria = EP.valorDaMaioria(c);
			//particiona o conjunto em subconjuntos dos valores do melhor atributo
			Conjunto []sub = EP.particao(c, melhor);
			//percorre cada um dos ramos
			for (int i = 0; i < sub.length; i++)
			{
				String valor = melhor.dominio().get(i);
				//adiciona o ramo � arvore
				//AQUI DEVE SER COLOCADO O NOVO N�
				DefaultMutableTreeNode ramo;
				ramo = new DefaultMutableTreeNode(valor);
				atributo.add(ramo);
				//avan�a recursivamente
				total += criarNos2(ramo, sub[i], valorDaMaioria); 
			}
		}
		return total;
	}

	private int criarNos(No raiz, int nivel, DefaultMutableTreeNode pai, Conjunto c, String padrao) 
	{
		int total = 1;
		DefaultMutableTreeNode folha;
		//verificar se todos os exemplos s�o da mesma classe, 
		//caso afirmativo retorna string que representa a classe, por exempo 'sim' ou 'n�o'
		//caso negativo retorna uma string vazia
		String classe = EP.todosDaMesmaClasse(c); 
		//se n�o h� exemplos retornar padr�o
		if (c.exemplos().size() == 0) 
		{
			//visualizacao
			folha = new DefaultMutableTreeNode(padrao);
			pai.add(folha);

			//representacao da regra
			No leaf = new No(raiz, nivel, true);
			raiz.adicionar(leaf);
			return 0;
		}
		//se n�o h� atributos retornar o valor da maioria, padrao
		else if (c.atributos().size() < 2)
		{
			folha = new DefaultMutableTreeNode(padrao);
			pai.add(folha);
			return 0;
		}
		//retorna a classe ou "" caso haja exemplos de ambas as classes
		else if (!classe.equals(""))
		{
			folha = new DefaultMutableTreeNode(classe);
			pai.add(folha);
			return 0;
		}
		else
		{
			//escolher o atributo que melhor divide o conjunto
			Atributo melhor = EP.maiorGanho(c);
			//adicionar � arvore
			DefaultMutableTreeNode atributo;
			atributo = new DefaultMutableTreeNode(melhor.nome() + "(" + melhor.dominio().size() + ")");
			pai.add(atributo);

			//define o valor padrao como sendo a classe da maioria
			String valorDaMaioria = EP.valorDaMaioria(c);
			//particiona o conjunto em subconjuntos dos valores do melhor atributo
			Conjunto []sub = EP.particao(c, melhor);
			//percorre cada um dos ramos
			for (int i = 0; i < sub.length; i++)
			{
				//adiciona o ramo � arvore
				DefaultMutableTreeNode ramo;
				ramo = new DefaultMutableTreeNode(melhor.dominio().get(i));
				atributo.add(ramo);
				//avan�a recursivamente
				total += criarNos(raiz, nivel, pai, sub[i], valorDaMaioria); 
			}
		}
		return total;
	}

	/**
	 * Create the GUI and show it.  For thread safety,
	 * this method should be invoked from the
	 * event dispatch thread.
	 */
	private static void createAndShowGUI() {
		if (useSystemLookAndFeel) {
			try {
				UIManager.setLookAndFeel(
						UIManager.getSystemLookAndFeelClassName());
			} catch (Exception e) {
				System.err.println("Couldn't use system look and feel.");
			}
		}

		//Create and set up the window.
		JFrame frame = new JFrame("ID3: Visualiza��o da Arvore");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Add content to the window.
		frame.add(new TreeDemo());

		//Display the window.
		frame.pack();
		frame.setSize(640, 480);		
		frame.setLocation(janelaCentralizada(frame));
		frame.setVisible(true);
	}

	//comandos para centralizar a janela
	public static Point janelaCentralizada(Component c)
	{
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		return new Point(
				(int)((dim.getWidth() - c.getWidth()) / 2),
				(int)((dim.getHeight() - c.getHeight()) / 2)
				);
	}

	public static void main(String[] args) {
		//Schedule a job for the event dispatch thread:
		//creating and showing this application's GUI.
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}
}