package util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import model.Atributo;
import model.Conjunto;
import model.Instancia;
import model.No;

public class EP 
{
	
	public static int folds = 3;

	//M�todo de leitura mais flex�vel, recebe como parametro o nome do arquivo, remove missing values e inclui os possiveis valores 'automagicamente' 
	public static Conjunto leitura(String nome_arquivo) throws Exception {

		long tempoInicio = System.currentTimeMillis();	//  tempo para ler e processar os dados


		//Abertura do arquivo
		FileInputStream in = null;
		try 
		{
			File inputFile = new File(nome_arquivo);
			in = new FileInputStream(inputFile);
		} 
		catch (Exception e) 
		{
			System.err.println( "N�o foi poss�vel abrir o arquivo: " + nome_arquivo + "\n" + e);
			return null;
		}

		BufferedReader bin = new BufferedReader(new InputStreamReader(in) );
		String entrada;

		//leitura dos atributos (cabecalho)
		while(true) 
		{
			entrada = bin.readLine();
			if (entrada == null) {
				System.err.println( "No data found in the data file: " + nome_arquivo + "\n");
				return null;
			}
			if (entrada.startsWith("//")) continue;
			if (entrada.equals("")) continue;
			break;
		}

		String[] atributos = entrada.split(", ");
		int numeroAtributos = atributos.length;
		ArrayList<Atributo> atributosConjunto = new ArrayList<Atributo>(); 

		if (numeroAtributos <= 1) 
		{
			System.err.println( "Read line: " + entrada);
			System.err.println( "Could not obtain the names of attributes in the line");
			System.err.println( "Expecting at least one input attribute and one output attribute");
			return null;
		}
		for (String nome : atributos)
		{
			atributosConjunto.add(new Atributo(nome));
		}

		int numero_exemplos = 0;
		int numero_excluidos = 0;

		ArrayList<Instancia> exemplosConjunto = new ArrayList<Instancia>();

		while(true)
		{
			entrada = bin.readLine();
			if (entrada == null) break;
			if (entrada.startsWith("//")) continue;
			if (entrada.equals("")) continue;

			// A express�o regular ' *, *' d� conta de encurtar todas as strings removendo espa�os, tabula��es, etc.
			String[] valores = entrada.split(" *, *");
			if (valores.length != numeroAtributos) 
			{
				System.err.println( "Read " + "" + " data");
				System.err.println( "Last line read: " + entrada);
				System.err.println( "Expecting " + numeroAtributos  + " attributes");
				return null;
			}

			//Verificar se h� missing values: percorre todos os valores do exemplo procurando pelo s�mbolo '?'
			boolean missing_value = false;

			for (String s : valores)
			{
				if (s.equals("?"))
				{
					missing_value = true;
					break;
				}
			}

			if (!missing_value)
			{
				exemplosConjunto.add(new Instancia(valores));
				for (int i = 0; i < valores.length; i++)
				{
					if (!atributosConjunto.get(i).valorExiste(valores[i])) //valor ainda desconhecido do dom�nio
						atributosConjunto.get(i).adicionarValorAoDominio(valores[i]);
				}
			}
			else ++numero_excluidos;

			++numero_exemplos;
		}

		System.err.println("Total de exemplos: " + numero_exemplos);
		System.err.println("Total de exemplos descartados: " + numero_excluidos);
		long tempoFim = System.currentTimeMillis();
		System.err.println("Tempo de processamento: " + (tempoFim-tempoInicio)/1000);

		bin.close();

		Conjunto c = new Conjunto(atributosConjunto, exemplosConjunto);
		return c;
	}

	/*backup - m�todos movidos pra classe Arvore
	//Separar em 10 conjuntos diferentes - 10-fold-cross-validation
		public static void separar(Conjunto c){

			int tamanho = c.exemplos().size();
			Random r = new Random();
			int linha = 0;
			int i;

			for(int j = 1; j<=folds; j++){
				i = 0;
				while(i<(tamanho/folds)){
					linha = r.nextInt(tamanho); // gera um linha randomicamente

					if(c.exemplos().get(linha).getFold()==0){ // se ainda n�o atualizou o fold do exemplo, ent�o atualiza
						c.exemplos().get(linha).setFold(j);
						i++;
					}
				}
			}
		}
		
		public static int rodarTeste(No raiz, Conjunto teste){
			int acertos = 0;
			Instancia ins;
			
			for(int i=0; i<teste.exemplos().size(); i++){	
				System.out.println("Rodando teste numero " + i);
				ins = teste.exemplos().get(i);
				
				if(raiz.isFolha()){
					System.out.println("entrou isFolha");
					if(ins.classe().equals("sim") && raiz.isDecisao()) acertos++;
					else if(ins.classe().equals("n�o") && !raiz.isDecisao()) acertos++;
				}
				else{
					for(int j =0; j<teste.atributos().size(); j++){
						if(teste.atributos().get(j).nome().equals(raiz.atributo)){
							for(int k = 0; k<raiz.dominioDevalores.size(); k++){
								if(raiz.dominioDevalores.get(k).equals(teste.exemplos().get(j))){
									System.out.println(raiz.dominioDevalores.get(k));
								}
								acertos += rodarTeste(raiz.filhos.get(k), teste);
							}
						}
						else{}
					}
				}
			}			
			return acertos;
		}

		public static double rodarExemplos(No raiz, Conjunto c, int total){
			double proporcao = 0;
			int acerto = 0;
			
			Conjunto treinamento = new Conjunto();
			treinamento.setAtributos(c.atributos());
			Conjunto teste = new Conjunto();
			treinamento.setAtributos(c.atributos());
			
			List<Instancia> insTreino = new ArrayList<Instancia>();
			List<Instancia> insTeste = new ArrayList<Instancia>();

			for(int f=1; f<=folds; f++){
				System.out.println("Entrei no fold " + f);
				for(int i=0; i<c.exemplos().size(); i++){
					if(c.exemplos().get(i).getFold() != f){
						insTreino.add(c.exemplos().get(i));
					}
					else{
						insTeste.add(c.exemplos().get(i));
					}					
					treinamento.setExemplos(insTreino);
					teste.setExemplos(insTeste);				
				}
				acerto = rodarTeste(raiz, teste);
			}
			
			proporcao = acerto/total;
			System.out.println(proporcao);
			
			return proporcao;
		}
		*/

	public static Conjunto particao(Conjunto c, Atributo atributo, String valorAlvo)
	{
		List<Instancia> exemplos = new ArrayList<Instancia>();
		int posicao = c.atributos().indexOf(atributo);	//indice do atributo 'a'

		for (Instancia i : c.exemplos())
		{
			if (i.valor(posicao).equals(valorAlvo)) exemplos.add(i.clone());
		}

		Conjunto saida = new Conjunto(c.atributos(), exemplos);
		saida.remover(atributo);
		return saida;
	}

	//particiona o conjunto em cima do dominio um atributo, retornando n conjuntos, onde n = tamanho do dominio do atributo
	public static Conjunto []particao(Conjunto conjunto, Atributo atributo)
	{
		List<String> dominio = atributo.dominio(); //possiveis valores de 'a'
		int posicao = conjunto.atributos().indexOf(atributo); //indice do atributo 'a' no conjunto

		Conjunto []saida = new Conjunto[dominio.size()]; //subconjuntos
		for (int i = 0; i < dominio.size(); i++) 
			saida[i] = new Conjunto(conjunto.atributos()); //inicializar subconjuntos

		for (Instancia exemplo : conjunto.exemplos())
		{
			for (int i = 0; i < dominio.size(); i++) //adicionar a instancia ao subconjunto correto 
				if (exemplo.valor(posicao).equals(dominio.get(i))) saida[i].instancia(exemplo.clone());
		}

		for (int i = 0; i < dominio.size(); i++)
			saida[i].remover(atributo); //descartar o atributo j� utilizado
		return saida;
	}

	public static double entropia(Conjunto c) //calcula entropia total do conjunto
	{
		if (c.exemplos().size() == 0) return 0;
		double positivos = 0;
		double negativos = 0;
		for (Instancia e : c.exemplos()) //contar exemplos
		{
			if (e.classe().equals(c.positivo())) ++positivos;
			else ++negativos;
		}
		return calcularEntropia(positivos, negativos);
	}

	public static double entropia(Conjunto c, Atributo a, String v)
	{
		//verificar se o atributo 'a' est� no conjunto
		int indice_atributo = c.atributos().indexOf(a);
		if (indice_atributo == -1) return -1; //erro

		//verificar se 'v' existe no dominio de valores de 'a'
		int indice_valor = a.dominio().indexOf(v);
		if (indice_valor == -1) return -1;

		//contar exemplos positivos e negativos de 'v'
		int positivos = 0;
		int negativos = 0;
		for (Instancia e : c.exemplos())
		{
			//contar exemplos que contem valor 'v' no atributo 'a'
			if (e.valor(indice_atributo).equals(v))
			{
				if (e.classe().equals(c.positivo())) positivos++;
				else negativos++;
			}
		}
		//calcular a entropia
		return calcularEntropia(positivos, negativos);
	}

	public static double calcularEntropia (double numPositivo, double numNegativo) {
		double probPositivo = numPositivo/(numPositivo + numNegativo);
		double probNegativo = numNegativo/(numPositivo + numNegativo);
		double entropia;

		if ((numPositivo==0)||(numNegativo==0))
			entropia = 0.0;
		else if (numPositivo==numNegativo)
			entropia = 1.0;
		else 
			entropia = -(probPositivo)*(Math.log(probPositivo)/Math.log(2))-(probNegativo)*(Math.log(probNegativo)/Math.log(2));

		return entropia;
	}

	public static double ganho(Conjunto c, Atributo a)
	{
		//verificar se o atributo 'a' est� no conjunto
		int indice_atributo = c.atributos().indexOf(a);
		if (indice_atributo == -1) return -1; //erro

		//ganho � a entropia do total do conjunto - as entropias para cada valor ponderada pelas suas probabilidades
		double ganho = entropia(c); 
		//calcular e subtrair da entropia total a entropia de cada valor do dominio de 'a', ponderado por sua probabilidade
		double numero_exemplos = c.exemplos().size();
		for (String v : a.dominio())
		{
			//calcular a probabilidade
			double exemplos = c.contarExemplos(a, v);
			double probabilidade = exemplos/numero_exemplos;

			ganho -= (entropia(c, a, v)*probabilidade); //precisa colocar entre parenteses
		}
		return ganho;
	}

	public static double ganho(Conjunto c, ArrayList<Instancia> valores, Double d)
	{
		int positivos = 0;
		int negativos = 0;
		//ganho � a entropia do total do conjunto - as entropias para cada valor ponderada pelas suas probabilidades
		for (Instancia e : valores) //contar exemplos
		{
			if (e.classe().equals(c.positivo())) ++positivos;
			else ++negativos;
		}
		double ganho = calcularEntropia(positivos, negativos);


		//calcular e subtrair da entropia total a entropia de cada valor do dominio de 'a', ponderado por sua probabilidade
		double numero_exemplos = valores.size();
		int menores_positivos = 0;
		int menores_negativos = 0;
		int maiores_positivos = 0;
		int maiores_negativos = 0;
		double exemplos_menores = 0;
		double exemplos_maiores = 0;
		String classe_positiva = c.positivo();

		for (Instancia i : valores)
		{
			//contar os exemplos
			if (Double.parseDouble(i.valor(0)) <= d)
			{
				if (i.classe().equals(classe_positiva)) menores_positivos++;
				else menores_negativos++;
				exemplos_menores++;
			}
			else
			{
				if (i.classe().equals(classe_positiva)) maiores_positivos++;
				else maiores_negativos++;
				exemplos_maiores++;
			}
		}
		double prob_menores = (exemplos_menores/numero_exemplos);
		double prob_maiores = (exemplos_maiores/numero_exemplos);
		//precisa colocar entre parenteses
		ganho = ((ganho)-(calcularEntropia(menores_positivos, menores_negativos)*prob_menores)-(calcularEntropia(maiores_positivos, maiores_negativos)*prob_maiores));
		return ganho;
	}

	//calcular o atributo com maior ganho em um conjunto
	public static Atributo maiorGanhoX(Conjunto c) {
		double maior = -1.0;
		Atributo resposta = c.atributos().get(0);
		//conjunto s� tem um atributo ??
		if (c.atributos().size()-1 == 1) return resposta;
		for (int i = 0; i < c.atributos().size()-1; i++) 
		{
			Atributo a = c.atributos().get(i);
			double ganho = ganho(c, a);
			ganho = EP.arredondar(ganho, 3); //para garantir a ordem em Java
			if (ganho > maior)
			{
				maior = ganho;
				resposta = a;
			}
		}
		return resposta;
	}

	//calcular o atributo com maior ganho em um conjunto
	public static Atributo maiorGanho(Conjunto c) {
		double maior = -1.0;
		Atributo resposta = new Atributo("Estranho");
		//conjunto s� tem um atributo ??

		for (int i = 0; i < c.atributos().size()-1; i++) 
		{
			Atributo a = c.atributos().get(i);
			double ganho = ganho(c, a);
			ganho = EP.arredondar(ganho, 3); //para garantir a ordem em Java
			if (ganho > maior)
			{
				maior = ganho;
				resposta = a;
			}
		}
		return resposta;
	}

	public static boolean discretizar(Conjunto c, Atributo a)
	{
		long tempoInicio = System.currentTimeMillis();
		//verificar se o atributo 'a' est� no conjunto
		int indice_atributo = c.atributos().indexOf(a);
		if (indice_atributo == -1) return false; //erro

		//verificar se 'a' � continuo
		if (!a.ehContinuo()) return false;

		//copiar valores do atributo 'a' e suas respectivas classes
		ArrayList<Instancia> valores = new ArrayList<Instancia>();
		for (Instancia e : c.exemplos())
		{
			String []val = {e.valor(indice_atributo), e.classe()};
			valores.add(new Instancia(val));
		}

		//ordenar por valor
		Collections.sort(valores, new ComparadorAtributo());
		//for (Instancia i : valores) System.out.println(i.imprimir());

		ArrayList<Double> candidatos = new ArrayList<Double>();
		//percorrer a lista buscando candidatos
		for (int i = 0; i < valores.size()-1; i++)
		{
			String classe_a = valores.get(i).classe();
			String classe_b = valores.get(i+1).classe();
			//se a classe de dois valores adjacentes � diferente, a m�dia � um novo candidato
			if (classe_a.equals(classe_b) == false)
			{
				double valor_A = Double.parseDouble(valores.get(i).valor(0));
				double valor_B = Double.parseDouble(valores.get(i+1).valor(0));
				double candidato = (valor_A+valor_B)/2;
				candidatos.add(candidato);
			}
		}

		//for (Double d : candidatos) System.out.println(d); //imprimir candidatos
		//calcular o ganho para cada um dos candidatos e selecionar o maior
		double maior = -1;
		double resposta = 0;
		for (Double d : candidatos)
		{
			double ganho = ganho(c, valores, d);
			if (ganho > maior)
			{
				maior = ganho;
				resposta = d;
			}
		}
		System.err.println("Candidatos: " + candidatos.size());

		//System.out.println(c.imprimir());
		//alterar o atributo com base na decisao
		Atributo discreto = new Atributo(a.nome(), false); //mesmo nome, continuo = false
		discreto.adicionarValorAoDominio("<="+resposta);
		discreto.adicionarValorAoDominio(">"+resposta);
		c.atributos().remove(indice_atributo);
		c.atributos().add(indice_atributo, discreto);

		//modificar as instancias
		for (Instancia i : c.exemplos())
		{
			double valor = Double.parseDouble(i.valor(indice_atributo)); 
			if (valor <= resposta) i.setvalor(indice_atributo, "<="+resposta);
			else i.setvalor(indice_atributo, ">"+resposta);
		}

		System.out.println("Resposta: " + resposta);


		//System.out.println(c.imprimir());

		long tempoFim = System.currentTimeMillis();
		System.err.println("Tempo de processamento: " + (tempoFim-tempoInicio)/1000);
		return true;
	}

	public static void gravar(Conjunto c, String nome_arquivo) throws IOException
	{
		long tempoInicio = System.currentTimeMillis();	//  tempo para ler e processar os dados

		//Abertura do arquivo
		FileOutputStream out = null;
		try 
		{
			File arquivoSaida = new File(nome_arquivo);
			out = new FileOutputStream(arquivoSaida);
		} 
		catch (Exception e) 
		{
			System.err.println( "N�o foi poss�vel abrir o arquivo: " + nome_arquivo + "\n" + e);
			return;
		}

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));

		//imprimir cabe�alho
		bw.write(c.imprimirAtributos());
		for (Instancia i : c.exemplos())
		{
			bw.write("\n" + i.imprimir());
		}
		bw.close();

		long tempoFim = System.currentTimeMillis();
		System.err.println("Tempo de grava��o: " + (tempoFim-tempoInicio)/1000);
	}

	public static String valorDaMaioria(Conjunto c)
	{
		//contar o numero de instancias de cada classe
		String a = c.classe().dominio().get(0);
		String b = c.classe().dominio().get(1);
		int n_a = 0;
		int n_b = 0;
		for (int i = 0; i < c.exemplos().size(); i++)
		{
			if (c.exemplos().get(i).classe().equals(a)) n_a++;
			else n_b++;
		}
		if (n_a >= n_b) return a;
		else return b;
	}

	public static String todosDaMesmaClasse(Conjunto c)
	{
		int nroExemplos = c.exemplos().size();
		if (nroExemplos == 0) return "";
		//pega o alvo do primeiro exemplo, se algum for diferente sai
		String classe = c.exemplos().get(0).classe();
		if (nroExemplos == 1) return classe;
		else
		{
			for (int i = 1; i < nroExemplos; i ++)
				if (!c.exemplos().get(i).classe().equals(classe)) return "";
		}
		return classe;
	}

	public static double arredondar(double valor, double casas)
	{
		int fator = (int) Math.pow(10, casas); //Ex.: 3 casas = 1000
		valor = valor*fator; //desloca o valor 3 casas para a frente
		valor = Math.round(valor); //arredonda a 4a. casa
		return valor/fator; //retorna o numero com n casas
	}
}