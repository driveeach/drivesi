/**
 * 
 */
package dsd.transport4you.dao.factories;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.impl.WebApplicationDAOImpl;
import dsd.transport4you.dao.interfaces.IWebApplicationDAO;

/**
 * Class is Web Application DAO Factory. Allows for easy
 * creation and access to DAO.
 * 
 * @author Dajan, Toni
 */
public class WebApplicationDAOFactory extends GeneralDAOFactory{

	public static final Log log = LogFactory.getLog(WebApplicationDAOFactory.class);
	
	/**
	 * Creates object that implements IWebApplicationDao.
	 * 
	 * @return Object that implements IWebApplicationDao.
	 */
	public static IWebApplicationDAO createIWebApplicationDao() {
		return new WebApplicationDAOImpl(emf);
	}

}
