package dsd.transport4you.model.route.standard;

import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.user.User;

/**
 * @author toni, dajan
 */
@Entity
@Table(name="TRANSPORT_STANDARD_ROUTE_SECTION")
public class TransportStandardRouteSection {
	
	@Id
	@GeneratedValue
	private Integer id;
	

	@ManyToOne(optional=false)
	private TransportLineStation fromStation;

	@ManyToOne(optional=false)
	private TransportLineStation toStation;
	
	/**
	 * Time when user has entered transport unit.
	 */
	@Column(name="fromStationDayTime",unique=false,nullable=false)
	private Time fromStationDayTime;
	/**
	 * Time when user has exited transport unit.
	 */
	@Column(name="toStationDayTime",unique=false,nullable=true)
	private Time toStationDayTime;
	
	@Column(name="dayOfWeek",unique=false,nullable=true)
	private Integer dayOfWeek;
	
	@ManyToOne(optional=false)
	private User user;
	
	public TransportStandardRouteSection(){
		
	}
	

	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public TransportLineStation getFromStation() {
		return fromStation;
	}
	public void setFromStation(TransportLineStation fromStation) {
		this.fromStation = fromStation;
	}
	public TransportLineStation getToStation() {
		return toStation;
	}
	public void setToStation(TransportLineStation toStation) {
		this.toStation = toStation;
	}

	public Time getFromStationDayTime() {
		return fromStationDayTime;
	}
	public Time getToStationDayTime() {
		return toStationDayTime;
	}
	public void setFromStationDayTime(Time fromStationDayTime) {
		this.fromStationDayTime = fromStationDayTime;
	}
	public void setToStationDayTime(Time toStationDayTime) {
		this.toStationDayTime = toStationDayTime;
	}
	public Integer getDayOfWeek() {
		return dayOfWeek;
	}
	public void setDayOfWeek(Integer dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
}
