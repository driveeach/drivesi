/**
 * 
 */
package dsd.transport4you.model.factories;

import java.util.Date;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.route.TransportRoute;
import dsd.transport4you.model.route.TransportRouteSection;
import dsd.transport4you.model.user.User;

/**
 * @author Dajan
 *
 */
public class TransportRouteSectionFactory {

	public static TransportRouteSection createUsersTransportRouteSection(User user, TransportLineStation fromStation, TransportLineStation toStation, Date fromStationTime, Date toStationTime, TransportRoute transportRoute){
		
		
		//create and set root section
		TransportRouteSection routeSection = new TransportRouteSection();
		routeSection.setFromStation(fromStation);
		routeSection.setToStation(toStation);
		routeSection.setFromStationTime(fromStationTime);
		routeSection.setToStationTime(toStationTime);
		routeSection.setRoute(transportRoute);
	
		return routeSection;
	}
	
	
}
