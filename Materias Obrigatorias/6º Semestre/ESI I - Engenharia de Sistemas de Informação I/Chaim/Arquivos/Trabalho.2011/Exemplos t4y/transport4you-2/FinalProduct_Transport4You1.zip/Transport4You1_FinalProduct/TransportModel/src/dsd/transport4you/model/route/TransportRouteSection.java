package dsd.transport4you.model.route;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import dsd.transport4you.model.network.TransportLineStation;

/**
 * A single journey performed by a user on the transport network, using only one transport lines.
 * Class is an entity object.
 * @author toni, dajan
 */
@Entity
@Table(name="TRANSPORT_ROUTE_SECTION")
public class TransportRouteSection {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	/**
	 * Route this route sections belongs to.
	 */
	@ManyToOne(optional=false)
	private TransportRoute route;
	/**
	 * Transport Station where user has entered transport unit.
	 */
	@ManyToOne(optional=false)
	private TransportLineStation fromStation;
	/**
	 * Transport Station where user has exited transport unit.
	 */
	@ManyToOne(optional=true)
	private TransportLineStation toStation;
	
	/**
	 * Time when user has entered transport unit.
	 */
	@Column(name="fromStationTime",unique=false,nullable=false)
	private Date fromStationTime;
	/**
	 * Time when user has exited transport unit.
	 */
	@Column(name="toStationTime",unique=false,nullable=true)
	private Date toStationTime;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public TransportRoute getRoute() {
		return route;
	}
	public void setRoute(TransportRoute route) {
		this.route = route;
	}
	public TransportLineStation getFromStation() {
		return fromStation;
	}
	public void setFromStation(TransportLineStation fromStation) {
		this.fromStation = fromStation;
	}
	public TransportLineStation getToStation() {
		return toStation;
	}
	public void setToStation(TransportLineStation toStation) {
		this.toStation = toStation;
	}
	public Date getFromStationTime() {
		return fromStationTime;
	}
	public void setFromStationTime(Date fromStationTime) {
		this.fromStationTime = fromStationTime;
	}
	public Date getToStationTime() {
		return toStationTime;
	}
	public void setToStationTime(Date toStationTime) {
		this.toStationTime = toStationTime;
	}
	
	public Boolean isActive(){
		return toStation == null;
	}
	
	@Override
	public String toString() {
		
		return "fromStation: " + fromStation + "toStation: " + toStation;
	}
	
}
