package dsd.transport4you.main.factories;

import dsd.transport4you.main.handlers.TransportUserDataHandlerImpl;
import dsd.transport4you.settings.ITransportUserDataHandler;
import dsd.transport4you.settings.ITransportUserDataHandlerFactory;


public class TransportUserDataHandlerFactory implements ITransportUserDataHandlerFactory{


	public ITransportUserDataHandler createTransportUserDataHandler(){
		return new TransportUserDataHandlerImpl();
	}
}
