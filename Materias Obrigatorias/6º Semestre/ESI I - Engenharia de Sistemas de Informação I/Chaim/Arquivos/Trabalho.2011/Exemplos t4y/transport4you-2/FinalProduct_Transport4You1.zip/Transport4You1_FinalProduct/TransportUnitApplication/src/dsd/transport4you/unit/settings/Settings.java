package dsd.transport4you.unit.settings;

public class Settings {

	/**
	 * TMA server port
	 */
	public static final int TMA_PORT = 3000;

	/**
	 * TMA server IP address
	 */
	public static final String TMA_IP = "192.168.1.159";
	
	/**
	 * Doors open event sleep time in seconds
	 */
	public static final int DOORS_OPEN_SLEEP_TIME = 70;
	/**
	 * Detection has to do minimal MIN_LOCATION_SCANS scans
	 */
	public static final int MIN_LOCATION_SCANS = 0;
	/**
	 * Detection has to do minimal MIN_TIME_SCANS scans
	 */
	public static final int MIN_TIME_SCANS = 1;
	/**
	 * Period between time scans in seconds
	 */
	public static final int TIME_SCAN_PERIOD = 10;
	/**
	 * Distance between location scans in meters
	 */
	public static final int LOCATION_SCAN_DISTANCE = 10;
	/**
	 * Max number of trying to get GPS location
	 */
	public static final int GPS_MAX_TRY_COUNT = 3;

	public static final int WLAN_SCAN_DURATION = 15;
}
