package dsd.transport4you.commprot.rpc;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;

import com.google.gson.Gson;

public class RPCClient {
	
	public static int METHOD_HTTP_GET=0;
	public static int METHOD_HTTP_POST=1;

	private String rpcServerIP;
	private Integer rpcServerPort;
	private String rpcString;
	
	private String queryString;

	private HttpClient httpClient;
	private int httpMethodDisc;
	private HttpMethod httpMethod;
	
	protected Map<String,String> parameters = new HashMap<String, String>();
	
	protected Gson gson = new Gson();
	
	public RPCClient(String rpcServerIP, Integer rpcServerPort, String rpcStr,int httpMethodDisc) {
		this.rpcServerIP = rpcServerIP;
		this.rpcServerPort = rpcServerPort;		
		this.rpcString = rpcStr;
		this.httpClient = new HttpClient();
		this.httpMethodDisc=httpMethodDisc;
	}
	
	private NameValuePair[] getParametersAsNameValuePairArray(){
		
		NameValuePair[] pairs = new NameValuePair[this.parameters.size()];
		int i=0;
		for(Map.Entry<String,String> entry : this.parameters.entrySet()){
			pairs[i++]=new NameValuePair(entry.getKey(),entry.getValue());
		}
		return pairs;
	}
	
	private void createGetMethod() throws IOException{
		httpMethod = new GetMethod("http://"+this.rpcServerIP+":"+this.rpcServerPort+this.rpcString);
		if(!parameters.isEmpty()){
			((GetMethod)httpMethod).setQueryString(getParametersAsNameValuePairArray());
		}
	}
	
	private void createPostMethod() throws IOException{
        httpMethod = new PostMethod("http://"+this.rpcServerIP+":"+this.rpcServerPort+this.rpcString);
        if(!parameters.isEmpty()){
        	((PostMethod)httpMethod).setRequestBody(getParametersAsNameValuePairArray());
        }
	}
	
	private void connect() throws RPCException, HttpException, IOException{
		
		if(this.httpMethodDisc==METHOD_HTTP_GET){
			createGetMethod();
		}else if(this.httpMethodDisc==METHOD_HTTP_POST){
			createPostMethod();
		}else{
			throw new UnsupportedOperationException("must be get or post method");
		}
		
		int httpStatus = this.httpClient.executeMethod(httpMethod);
		
		if (httpStatus != HttpStatus.SC_OK) {
			System.out.println("status: "+httpStatus+", sc: "+HttpStatus.SC_OK);
			throw new RPCException("http status:"+httpStatus);
		}
	}
	
	public InputStreamReader getReader() throws IOException{
	    return new InputStreamReader(httpMethod.getResponseBodyAsStream());
	}
	
	private void disconnect(){
		if(httpMethod!=null){
			httpMethod.releaseConnection();
		}
	}
	
	public String execute() throws RPCException{
		
		try {
			connect();
			StringBuffer sb = new StringBuffer();
			BufferedReader bf = new BufferedReader(getReader());
			String line;
			while ((line = bf.readLine()) != null) {
				sb.append(line);
			}
			bf.close();
			return sb.toString();
		
		} catch (Exception e) {
			throw new RPCException(e);
		}finally{
			disconnect();
		}
	}
	
	protected void setQueryString(String queryString) {
		this.queryString=queryString;
	}
}
