package dsd.transport4you.main.notification;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.ApplicationSettings;

public abstract class UserNotifier {
	
	protected ResourceBundle notificationBundle;
	
	protected SimpleDateFormat dateFormat=new SimpleDateFormat();
	
	protected UserNotifier(){
		this.notificationBundle = ResourceBundle.getBundle("notifications",new Locale(ApplicationSettings.LOCALE));
	}
	
	public abstract void notifyStandardRouteInterruption(User user, Date timeToSend,String transportLineName,String fromStation,String toStation,Date fromTime,Date toTime);
	public abstract void notifyStandardRouteModification(User user, Date timeToSend,String transportLineName,String fromStation,String toStation,String modifiedStationList,Date fromTime,Date toTime);
	
	public abstract void notifyTicketCheck(User user,Date validTo,Date timeToSend);
	public abstract void notifyTicketExpired(User user,Date timeToSend);
	public abstract void notifyTicketRemainder(User user,Date timeToSend);
	public abstract void notifyLowPrepaidTicketWarning(User user,Integer ticketRemainingCount,Date timeToSend);

}
