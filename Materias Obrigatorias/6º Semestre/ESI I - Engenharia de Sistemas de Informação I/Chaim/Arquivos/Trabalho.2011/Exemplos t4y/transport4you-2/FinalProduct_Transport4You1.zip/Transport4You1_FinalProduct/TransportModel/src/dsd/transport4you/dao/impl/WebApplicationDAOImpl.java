/**
 * 
 */
package dsd.transport4you.dao.impl;

import java.util.Collection;

import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;

import dsd.transport4you.dao.interfaces.IWebApplicationDAO;
import dsd.transport4you.model.network.TransportLayer;
import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.news.News;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.ApplicationSettings;
import dsd.transport4you.util.StringUtil;

/**
 * @author toni
 *
 */
public class WebApplicationDAOImpl extends GeneralDAO implements IWebApplicationDAO {

	public WebApplicationDAOImpl(EntityManagerFactory emf) {
		super(emf);
	}

	@Override
	public User getUserByAuthorization(String username, String password) {
		if(username == null || password == null){
			return null;
		}

		String encodedPassword = StringUtil.encodePassword(password, ApplicationSettings.PASSWORD_HASH_ALGORITHM);
		User user;
		try {
			user = (User) em.createNamedQuery("userByAuthorization")
					.setParameter(1, username).setParameter(2, encodedPassword)
					.getSingleResult();
		} catch (NoResultException e) {
			user=null;
		}
		
		return user;
	}

	@Override
	public User getUserByUserName(String userName) {
		return (User) em.createNamedQuery("userByUserName").setParameter("username", userName).getSingleResult();
		
	}

	@Override
	public Collection<TransportLine> getAllTransportLines() {
		try{
			return em.createNamedQuery("allTransportLines").getResultList();
		}
		catch(Exception e){
			return null;
		}
	}
	
	@Override
	public Collection<News> getAllNews() {
		return (Collection<News>) em.createNamedQuery("allNews").getResultList();
	}

	@Override
	public TransportLine getTransportLineById(Integer id) {
		try {
			return (TransportLine) em.createNamedQuery("transportLineById")
					.setParameter(1, id).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	@Override
	public TransportLineStation getTransportLineStationById(Integer id) {
		try {
			return (TransportLineStation) em.createNamedQuery("transportLineStationById")
					.setParameter(1, id).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	@Override
	public News getNewsById(Integer id) {
		try {
			return (News) em.createNamedQuery("newsByID").setParameter(1, id).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	@Override
	public User getUserBySessionData(Long sessionToken, Integer sessionHash) {
		try {
			return (User) em.createNamedQuery("userBySessionData")
							.setParameter(1,sessionToken)
							.setParameter(2,sessionHash)
							.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	@Override
	public Collection<TransportLayer> getAllTranportLayers() {
		try{
			return em.createNamedQuery("allTransportLayers").getResultList();
		}
		catch(Exception e){
			return null;
		}
	}
}
