package dsd.transport4you.actions.admin.routes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.actions.AjaxActionSupport;
import dsd.transport4you.actions.interfaces.IAdminAction;
import dsd.transport4you.bean.GpsLocationBean;
import dsd.transport4you.bean.TransportLineBean;
import dsd.transport4you.bean.TransportLineStationBean;
import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;

public class FetchTransportLineDataAjax extends AjaxActionSupport implements IAdminAction {

	private static Log log = LogFactory.getLog(FetchTransportLineDataAjax.class);

	private static final long serialVersionUID = -3656238945342942912L;
	private Map<String,Object> result = new HashMap<String, Object>();
	
	private Integer transportLineId;

	@Override
	public String execute() throws Exception {
		log.info("Fetch transport line");

		TransportLine transportLine = webDAO.getTransportLineById(transportLineId);

		List<TransportLineStation> forwardTrip = new ArrayList<TransportLineStation>(transportLine.getTransportLineStationsForwardTrip());
		List<TransportLineStation> backwardTrip = new ArrayList<TransportLineStation>(transportLine.getTransportLineStationsBackwardTrip());

		List<TransportLineStationBean> forwardTripBean = prepareTrip(forwardTrip);
		List<TransportLineStationBean> backwardTripBean = prepareTrip(backwardTrip);
		
		TransportLineBean transportLineBean = 
			new TransportLineBean(transportLine.getName(), forwardTripBean, backwardTripBean);
		
		result.put("line", transportLineBean);


		System.out.println("Line: "+transportLine.getName());
		System.out.println("Forward: "+transportLineBean.getForwardTrip());
		
		System.out.println("postavljam");

		setResultJSON(result);
		
		System.out.println("postavio sam");
		return SUCCESS;
	}

	
	private List<TransportLineStationBean> prepareTrip(List<TransportLineStation> tripData) {
		
		List<TransportLineStationBean> trip = new ArrayList<TransportLineStationBean>();
		
		for (TransportLineStation transportLineStation : tripData) {
			GpsLocationBean location  = new GpsLocationBean();
			location.setLatitude(transportLineStation.getTransportStation().getGpsLocation().getLatitude());
			location.setLongitude(transportLineStation.getTransportStation().getGpsLocation().getLongitude());

			String stationName = transportLineStation.getTransportStation().getDisplayName();
			Integer lineStationId = transportLineStation.getId();
			
			TransportLineStationBean lineStatioBean = new TransportLineStationBean(location, stationName, lineStationId);
			
			trip.add(lineStatioBean);
		}
		
		return trip;
	}


	public void setTransportLineId(Integer transportLineId) {
		this.transportLineId = transportLineId;
	}	
}
