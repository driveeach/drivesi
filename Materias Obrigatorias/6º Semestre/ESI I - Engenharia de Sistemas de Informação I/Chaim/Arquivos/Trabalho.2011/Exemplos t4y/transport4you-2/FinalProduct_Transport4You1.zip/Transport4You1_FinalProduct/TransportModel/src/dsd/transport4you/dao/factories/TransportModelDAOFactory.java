/**
 * 
 */
package dsd.transport4you.dao.factories;

import dsd.transport4you.dao.impl.TransportModelDAOImpl;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;

/**
 * Class is Web Application DAO Factory. Allows for easy
 * creation and access to DAO.
 * 
 * @author Dajan, Toni
 */
public class TransportModelDAOFactory extends GeneralDAOFactory{

	/**
	 * Creates implementation of ITransportModelDAO.
	 * 
	 * @return implementation of ITransportModelDAO.
	 */
	public static ITransportModelDAO createITransportModelDAO() {
		return new TransportModelDAOImpl(emf);
	}

}
