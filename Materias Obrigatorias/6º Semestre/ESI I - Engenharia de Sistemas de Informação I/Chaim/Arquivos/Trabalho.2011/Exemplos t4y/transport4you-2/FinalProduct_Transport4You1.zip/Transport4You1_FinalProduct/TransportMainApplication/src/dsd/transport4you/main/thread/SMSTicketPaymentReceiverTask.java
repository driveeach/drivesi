package dsd.transport4you.main.thread;

import java.util.Date;
import java.util.TimerTask;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.commprot.sms.SMSMessage;
import dsd.transport4you.commprot.sms.SMSModule;
import dsd.transport4you.commprot.sms.SMSModuleFactory;
import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.main.notification.SMSUserNotifier;
import dsd.transport4you.main.notification.UserNotifier;
import dsd.transport4you.model.Payment;
import dsd.transport4you.model.PaymentType;
import dsd.transport4you.model.Ticket;
import dsd.transport4you.model.Ticket.TicketType;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.ApplicationSettings;

public class SMSTicketPaymentReceiverTask extends TimerTask{

	public static final Log log = LogFactory.getLog(SMSTicketPaymentReceiverTask.class);
	
	private SMSModule smsModule;
	private UserNotifier notifier;
	
	public SMSTicketPaymentReceiverTask() {
		smsModule = SMSModuleFactory.createSMSModule();
		notifier = SMSUserNotifier.getInstance();
	}
	
	@Override
	public void run() {
		
		log.info("started task");
		
		Date now = new Date();
		
		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		dao.getEntityManager().getTransaction().begin();
		
		for(SMSMessage sms : smsModule.getNewMessages()){
	
			log.info("new msg received:"+sms);
			
			if(isValid(sms)){
				
				User user = dao.getUserByPhoneNumber(sms.getFrom());
				log.info(user);
				
				Payment payment = new Payment(user, PaymentType.SMS);
				
				Ticket ticket = new Ticket(TicketType.T_VALUE,user);
				ticket.setPayment(payment);
				
				dao.save(payment);
				dao.save(ticket);
				
				log.info("created payment "+payment);
				log.info("created ticket "+ticket);
				
				if(user.getActiveTicket()==null){
					ticket.check(now);
					log.info(ticket+" checked now!");
					
					dao.update(ticket);
					
					user.setActiveTicket(ticket);
					dao.update(user);
					log.info(ticket+" set as users active ticket!");
					
					//TODO: move out of transaction
					notifier.notifyTicketCheck(user, ticket.getTimeValidTo(),now);
				}else{
					
					//TODO: notify added to prepaid
					log.info(ticket+" added to prepaid!");
				}
				
			}
		}
		
		
		
//		dao.getEntityManager().getTransaction().begin();
//		
//		for(TransportRoute route : dao.getTransportRoutesToInactivate(ApplicationSettings.TRANSPORT_ROUTE_INACTIVATION_TIME)){
//			route.setActive(false);
//			dao.update(route);
//			log.info("route #"+route.getId()+" inactivated");
//		}
//		
		
		dao.getEntityManager().getTransaction().commit();
		dao.close();
		log.info("finished task");
	}

	private boolean isValid(SMSMessage sms) {
		return sms.getMessage().trim().toLowerCase().equals(ApplicationSettings.SMS_PAYMENT_MSG.toLowerCase());
	}

}
