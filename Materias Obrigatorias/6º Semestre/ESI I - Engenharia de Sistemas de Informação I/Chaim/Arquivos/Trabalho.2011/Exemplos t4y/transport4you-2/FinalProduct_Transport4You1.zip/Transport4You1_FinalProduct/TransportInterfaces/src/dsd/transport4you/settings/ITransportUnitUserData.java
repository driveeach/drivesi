/**
 * 
 */
package dsd.transport4you.settings;

import java.util.Date;
import java.util.List;

import dsd.transport4you.interfaces.model.GpsLocation;
import dsd.transport4you.interfaces.model.MacAddress;
import dsd.transport4you.interfaces.model.TransportUnitLineData;



/**
 * 
 * @author dajan
 *
 */
public interface ITransportUnitUserData {

	public List<MacAddress> getNewUsers();
	public List<MacAddress> getMissingUsers();
	public GpsLocation getGpsLocation();
	public TransportUnitLineData getTransportLine();
	public String getTransportUnitUniqueIdentifier();
	public Date getTimeStamp();
	
	@Override
	public boolean equals(Object obj);
	
}
