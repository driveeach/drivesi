package dsd.transport4you.factories;

import java.util.ArrayList;
import java.util.List;

import dsd.transport4you.bean.UserBean;
import dsd.transport4you.model.user.User;
import dsd.transport4you.model.user.authorization.Role;

public class UserBeanFactory {

	public static UserBean createUserBean(User user){
		List<Role> roles = new ArrayList<Role>(user.getRoles());
		
		//List<Role> roles = new ArrayList<Role>();
		
		//roles.add(new Role(RoleType.USER));	
		
		return new UserBean(user.getId(),user.getAuthorizationInfo().getUsername(), user.getAuthorizationInfo().getPassword(), user.getPersonalUserInfo().getFirstName(),user.getPersonalUserInfo().getLastName(),roles);
	
	}
	
}
