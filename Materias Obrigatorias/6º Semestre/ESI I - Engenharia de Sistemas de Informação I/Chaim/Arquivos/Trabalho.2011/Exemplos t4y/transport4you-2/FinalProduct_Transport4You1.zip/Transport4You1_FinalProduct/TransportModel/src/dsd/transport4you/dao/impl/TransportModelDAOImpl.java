package dsd.transport4you.dao.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.TemporalType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.interfaces.model.TransportLineDirection;
import dsd.transport4you.interfaces.util.GPSUtil;
import dsd.transport4you.model.Ticket;
import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.network.TransportUnit;
import dsd.transport4you.model.network.changes.TransportRouteInterruption;
import dsd.transport4you.model.network.changes.TransportRouteModification;
import dsd.transport4you.model.route.TransportRoute;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.ApplicationSettings;
import dsd.transport4you.util.DateUtil;

public class TransportModelDAOImpl extends GeneralDAO implements ITransportModelDAO {

	private static Log log = LogFactory.getLog(TransportModelDAOImpl.class);
	
	public TransportModelDAOImpl(EntityManagerFactory emf) {
		super(emf);
	}

	@Override
	public TransportLineStation getNearestTransportLineStation(double longitude,
			double latitude, String transportLineName,
			TransportLineDirection direction) {

		String query;

		if (direction == TransportLineDirection.FORWARD) {
			query = "select tls from TransportLineStation tls where tls.transportLineForward.name=?1";
		} else {
			query = "select tls from TransportLineStation tls where tls.transportLineBackward.name=?1";
		}

		List<TransportLineStation> lineStations = (List<TransportLineStation>) em
				.createQuery(query).setParameter(1, transportLineName)
				.getResultList();

		TransportLineStation nearestTransportLineStation = null;
		int minDistance = Integer.MAX_VALUE;

		for (TransportLineStation ls : lineStations) {
			int thisDistance = GPSUtil.getDistance2(ls.getTransportStation()
					.getGpsLocation().getLatitude(), ls.getTransportStation()
					.getGpsLocation().getLongitude(), latitude,longitude);

			
			log.info("distance to "+ls+" "+thisDistance+"m");
			
			if (thisDistance < minDistance) {
				minDistance = thisDistance;
				nearestTransportLineStation = ls;
			}
		}

		return minDistance < ApplicationSettings.GPS_LOCATION_RADIUS ? nearestTransportLineStation
				: null;
	}

	public User getUserByBluetoothMacAddress(String macAddress) {
		try {
			return (User) em.createNamedQuery("userByBluetoothMacAddress")
					.setParameter(1, macAddress).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	public User getUserByWiFiMacAddress(String macAddress) {
		try {
			return (User) em.createNamedQuery("userByWifiMacAddress")
					.setParameter(1, macAddress).getSingleResult();
		} catch (Exception e) {
			return null;
		}
	}
	
	public List<Ticket> getUncheckedTickets(Integer userId){
		return (List<Ticket>) em.createNamedQuery("uncheckedTicketsByUser").setParameter(1,userId).getResultList();
	}

	@Override
	public List<TransportRoute> getTransportRoutesToInactivate(Integer inactivationTime) {
		return (List<TransportRoute>) em.createNamedQuery("routesToInactivate")
										.setParameter(1, DateUtil.add(Calendar.SECOND, -1*inactivationTime, new Date()), TemporalType.TIMESTAMP)
										.getResultList();
	}

	public List<User> getUsersWithExpiredTicket() {
		return (List<User>)em.createNamedQuery("usersWithExpiredTicket")
							 .setParameter(1, new Date())
							 .getResultList();
	}

	@Override
	public List<TransportLine> getAllTransportLines() {
		return (List<TransportLine>)em.createNamedQuery("allTransportLines").getResultList();
	}

	@Override
	public List<TransportUnit> getAllTransportUnits() {
		return (List<TransportUnit>)em.createNamedQuery("allTransportUnits").getResultList();
	}

	@Override
	public User getUserByPhoneNumber(String phoneNumber) {
		try {
			return (User) em.createNamedQuery("userByPhoneNumber")
					.setParameter(1, phoneNumber).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	@Override
	public List<TransportRouteInterruption> getTransportRouteInterruptions() {
		return (List<TransportRouteInterruption>)em.createNamedQuery("allRouteInterruptions").getResultList();
	}

	@Override
	public List<TransportRouteModification> getTransportRouteModifications() {
		return (List<TransportRouteModification>)em.createNamedQuery("allRouteModifications").getResultList();
	}

	@Override
	public List<User> getUsersWithStandardRouteSections() {
		return (List<User>)em.createNamedQuery("usersWithStandardRouteSections").getResultList();
	}
}
