package dsd.transport4you.main;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import dsd.transport4you.commprot.TcpServer;
import dsd.transport4you.commprot.util.threads.TransportUnitUserDataHandler;
import dsd.transport4you.dao.PersistenceUtil;
import dsd.transport4you.main.factories.TransportUserDataHandlerFactory;
import dsd.transport4you.main.thread.AllModificationInterruptionNotificationTask;
import dsd.transport4you.main.thread.RouteInactivationTask;
import dsd.transport4you.main.thread.SMSSenderTask;
import dsd.transport4you.main.thread.SMSTicketPaymentReceiverTask;
import dsd.transport4you.main.thread.StandardRouteModificationInterruptionNotificationTask;
import dsd.transport4you.main.thread.TicketExpirationTask;
import dsd.transport4you.settings.ApplicationSettings;

public class TransportMainApplication {

	
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		
		PersistenceUtil.initialize();
		startSecondaryTasks();
		startPrimaryThread();
	}

	private static void startPrimaryThread() throws IOException {
		new Thread(new TcpServer(ApplicationSettings.SERVER_SOCKET, 
									   ApplicationSettings.SERVER_TASK_QUEUE_SIZE, 
									   TransportUnitUserDataHandler.class, 
									   new TransportUserDataHandlerFactory(),
									   ApplicationSettings.SERVER_HANDLER_COUNT)).start();
	}

	private static void startSecondaryTasks() {
		new Timer().scheduleAtFixedRate(new RouteInactivationTask(), 0, ApplicationSettings.TASK_ROUTE_INACTIVATION_PERIOD*1000);
		new Timer().scheduleAtFixedRate(new TicketExpirationTask(), 30*1000, ApplicationSettings.TASK_TICKET_EXPIRATION_PERIOD*1000);
		
//		new Timer().scheduleAtFixedRate(new SMSTicketPaymentReceiverTask(), 120*60*1000, ApplicationSettings.TASK_SMS_TICKET_RECEIVER_PERIOD*1000);
		new Timer().scheduleAtFixedRate(new SMSSenderTask(), 0, ApplicationSettings.TASK_SMS_TICKET_SENDER_PERIOD*1000);
		
		//TODO: make factory
		TimerTask notifier=null;
		
		switch(ApplicationSettings.MODIFICATION_INTERRUPTION_NOTIFICATION_STRATEGY){
			case ApplicationSettings.NOTIFY_ALL:
				notifier=new AllModificationInterruptionNotificationTask();
				break;
			case ApplicationSettings.NOTIFY_STANDARD_ROUTES:
				notifier=new StandardRouteModificationInterruptionNotificationTask();
				break;
			default:
				notifier=null;
		}
		
		new Timer().scheduleAtFixedRate(notifier,0, ApplicationSettings.TASK_MODIFICATION_NOTIFICATION_PERIOD*1000);
	}

}
