package dsd.transport4you.dao.interfaces;

import javax.persistence.EntityManager;

import dsd.transport4you.dao.impl.GeneralDAO;
import dsd.transport4you.model.user.User;
import dsd.transport4you.model.user.authorization.Role;
import dsd.transport4you.model.user.authorization.Role.RoleType;

/**
 * Interface of GeneralDAO.
 * @author toni
 */
public interface IGeneralDAO {

	/**
	 * Creates new entity manager (hibernate session).
	 * 
	 * @return Entity Manager.
	 */
	public EntityManager getEntityManager();
	
	public void createEntityManager();
	
	/**
	 * @see GeneralDAO#save(Object, EntityManager)
	 */
	public void save(Object obj);

	/**
	 * @see GeneralDAO#update(Object, EntityManager)
	 */
	public void update(Object obj);

	/**
	 * @see GeneralDAO#delete(Object, EntityManager)
	 */
	public void delete(Object obj);
	
	public void beginTransaction();
	public void commitTransaction();
	public void rollbackTransaction();
	
	/**
	 * Close DAO object.
	 */
	public void close();
	
	/**
	 * Get user by id from database.
	 * 
	 * @param id
	 *            User id.
	 * @param session
	 *            Entity Manager session.
	 * @return User.
	 */
	public User getUserById(Integer id);
	public Role getRoleByType(RoleType roleType);

}
