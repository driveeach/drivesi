/**
 * 
 */
package dsd.transport4you.test.communication;

import java.io.IOException;

import dsd.transport4you.commprot.TcpServer;
import dsd.transport4you.commprot.util.threads.TransportUnitUserDataHandler;
import dsd.transport4you.main.factories.TransportUserDataHandlerFactory;

/**
 * @author Dajan
 *
 */
public class Server {
	public static void main(String[] args) {
		TcpServer server;
		try {
			server = new TcpServer(3000, 10, TransportUnitUserDataHandler.class, new TransportUserDataHandlerFactory(), 10);
			new Thread(server).start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
