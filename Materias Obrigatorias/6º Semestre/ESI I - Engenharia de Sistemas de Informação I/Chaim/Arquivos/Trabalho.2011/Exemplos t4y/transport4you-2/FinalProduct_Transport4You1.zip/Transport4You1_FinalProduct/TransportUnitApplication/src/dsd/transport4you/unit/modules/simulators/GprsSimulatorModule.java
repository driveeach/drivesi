/**
 * 
 */
package dsd.transport4you.unit.modules.simulators;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.commprot.TcpClient;
import dsd.transport4you.settings.ITransportUnitUserData;
import dsd.transport4you.unit.modules.GprsModule;
import dsd.transport4you.unit.settings.Settings;

/**
 * Module that sends information over GPRS protocol to the main application
 * 
 * @author Dino
 *
 */
public class GprsSimulatorModule  extends GprsModule{

	private static Log log = LogFactory.getLog(GprsSimulatorModule.class);

	public void sendData(ITransportUnitUserData userData ){

		TcpClient client = new TcpClient(Settings.TMA_IP, Settings.TMA_PORT, userData);
		client.sendData();	

//				System.out.println("Sending data: ");
//				System.out.println("NEW: "+userData.getNewUsers());
//				System.out.println("MIS: "+userData.getMissingUsers());
//				log.info("TU: "+userData.getTransportUnitUniqueIdentifier());
//				log.info("LINE: "+userData.getTransportLine());
//				log.info("GPS: "+userData.getGpsLocation());

	}
}
