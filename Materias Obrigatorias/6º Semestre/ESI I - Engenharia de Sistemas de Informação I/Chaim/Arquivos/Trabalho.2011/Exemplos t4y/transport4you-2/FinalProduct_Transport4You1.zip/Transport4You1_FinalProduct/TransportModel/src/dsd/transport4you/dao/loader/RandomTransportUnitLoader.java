/**
 * 
 */
package dsd.transport4you.dao.loader;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.model.network.TransportLayer;
import dsd.transport4you.model.network.TransportNetwork;
import dsd.transport4you.model.network.TransportUnit;
import dsd.transport4you.settings.ApplicationSettings;

/**
 * @author Toni
 *
 */
public class RandomTransportUnitLoader {
	
	public static Log log = LogFactory.getLog(RandomTransportUnitLoader.class);

	public static void main(String[] args) {
		
//		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
//		
//		generateRandomTransportUnits(dao);
//		
//		dao.getEntityManager().getTransaction().commit();
//		dao.close();
		throw new RuntimeException("don't run as main");
		
	}

	public static void generateRandomTransportUnits(ITransportModelDAO dao,TransportNetwork network) {
		
		Random rand = new Random();
		
		List<TransportLayer> layers = new ArrayList<TransportLayer>(network.getTransportLayers());
		
		for(int i = 0; i < ApplicationSettings.DB_LOADER_TRANSPORT_UNIT_COUNT; i++){
			TransportUnit unit = new TransportUnit("unique"+i,layers.get(rand.nextInt(layers.size())));
			dao.save(unit);
			log.info("created "+unit);	
		}
	}
	
}
