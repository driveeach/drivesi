package dsd.transport4you.interceptors;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;

import com.google.gson.reflect.TypeToken;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

import dsd.transport4you.actions.ExtendedActionSupport;
import dsd.transport4you.actions.authorization.LoginAction;
import dsd.transport4you.actions.authorization.LogoutAction;
import dsd.transport4you.actions.interfaces.IAdminAction;
import dsd.transport4you.actions.interfaces.IAuthorizationAction;
import dsd.transport4you.actions.interfaces.IUserAction;
import dsd.transport4you.bean.UserBean;
import dsd.transport4you.dao.interfaces.IWebApplicationDAO;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.Constants;

public class AuthorizationInterceptor implements Interceptor  {

	private static final long serialVersionUID = 1L;
	private static Log log = LogFactory.getLog(AuthorizationInterceptor.class);
	
	public void init() {

	}
	public void destroy() {

	}

	public String intercept(ActionInvocation invocation) throws Exception {
		
		ExtendedActionSupport action = (ExtendedActionSupport) invocation.getAction();
		Map<String,Object> sessionMap = invocation.getInvocationContext().getSession();
		Map<String, String> cookieMap = action.getCookieMap();
		HttpServletResponse httpReponse = ServletActionContext.getResponse();
		
		IWebApplicationDAO webDAO = action.getWebDAO();
		log.info("AuthorizationInterceptor authorization for "+action.getClass().getCanonicalName());
		
		UserBean userBean = (UserBean) sessionMap.get(Constants.USER_BEAN);
		log.info("userBean:"+userBean);
		
		if(userBean==null){
			log.info("cookies:"+cookieMap);
			String value = cookieMap.get(Constants.SESSION_COOKIE_NAME);
			
			if(value!=null){
				Map<String,String> cookieData = ExtendedActionSupport.gson.fromJson(value,new TypeToken<Map<String, String>>() {}.getType());
				Long sessionToken = Long.valueOf(cookieData.get(Constants.SESSION_TOKEN));
				Integer sessionHash = Integer.valueOf(cookieData.get(Constants.SESSION_HASH));
				
				User user = webDAO.getUserBySessionData(sessionToken,sessionHash);
				log.info("userBySessionData:"+user);
				
				if(user!=null){
					userBean = LoginAction.loginUser(user, sessionMap, httpReponse, webDAO,true);
				}else{
					LogoutAction.clearSessionCookie(null,httpReponse);
				}
			}
		}
		
		
		if(action instanceof IAuthorizationAction){
			//no authorization necessary
		}else if(action instanceof IUserAction && !(action instanceof IAdminAction)){
			
			if(userBean==null){
				log.info("user not logged in");
				return ExtendedActionSupport.NOT_LOGGED_IN;
			}else if(!userBean.isUser()){
				log.info("user "+userBean.getUsername()+" without permission (user role) for "+action.getClass().getCanonicalName());
				return ExtendedActionSupport.NO_PERMISSION;
			}
		}else if(action instanceof IAdminAction && !(action instanceof IUserAction)){
	
			if(userBean==null){
				log.info("user not logged in");
				return ExtendedActionSupport.NOT_LOGGED_IN;
			}else if(!userBean.isAdmin()){
				log.info("user "+userBean.getUsername()+" without permission (user admin) for "+action.getClass().getCanonicalName());
				return ExtendedActionSupport.NO_PERMISSION;
			}
		}else if(action instanceof IUserAction && action instanceof IAdminAction){
			if(userBean==null){
				log.info("user not logged in");
				return ExtendedActionSupport.NOT_LOGGED_IN;
			}else if(!userBean.isUser() && !userBean.isAdmin()){
				log.info("user "+userBean.getUsername()+" without permission (user or admin role) for "+action.getClass().getCanonicalName());
				return ExtendedActionSupport.NO_PERMISSION;
			}
		
		}else{
			log.info("AuthorizationInterceptor authorization open");
		}
		
		log.info("AuthorizationInterceptor authorization successfull");
		
		return invocation.invoke();
	}
}
