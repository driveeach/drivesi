package dsd.transport4you.util.exceptions;

public class TransportModelValidationException extends TransportModelException{

	private static final long serialVersionUID = 1L;

	public TransportModelValidationException(Exception e) {
		super(e);
	}

	public TransportModelValidationException(String string) {
		super(string);
	}
}
