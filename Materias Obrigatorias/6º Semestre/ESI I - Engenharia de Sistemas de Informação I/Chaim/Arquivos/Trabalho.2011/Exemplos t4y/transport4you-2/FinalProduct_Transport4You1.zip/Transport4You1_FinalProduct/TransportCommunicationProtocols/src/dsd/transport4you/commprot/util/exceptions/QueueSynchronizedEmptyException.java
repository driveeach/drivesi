/**
 * 
 */
package dsd.transport4you.commprot.util.exceptions;

/**
 * Empty queue exception.
 * 
 * @author dajan
 *
 */
public class QueueSynchronizedEmptyException extends
		QueueSynchronizedException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public QueueSynchronizedEmptyException(String message) {
		super(message);
		
	}

}
