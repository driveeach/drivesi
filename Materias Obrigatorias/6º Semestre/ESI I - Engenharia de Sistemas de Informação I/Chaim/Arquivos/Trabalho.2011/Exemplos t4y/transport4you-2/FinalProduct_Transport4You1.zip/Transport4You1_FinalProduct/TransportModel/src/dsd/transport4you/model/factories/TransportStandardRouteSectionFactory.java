/**
 * 
 */
package dsd.transport4you.model.factories;

import java.sql.Time;
import java.util.Calendar;

import java.util.GregorianCalendar;


import dsd.transport4you.model.route.TransportRouteSectionWrapper;
import dsd.transport4you.model.route.standard.TransportStandardRouteSection;
import dsd.transport4you.model.user.User;

/**
 * @author Dajan
 * 
 */
public class TransportStandardRouteSectionFactory {

	public static TransportStandardRouteSection createTransportStandardRouteSection(
			TransportRouteSectionWrapper wrapper, User user) {

		TransportStandardRouteSection standardRouteSection = new TransportStandardRouteSection();

		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(wrapper.getFromStationTime());

		standardRouteSection.setFromStation(wrapper.getFromStation());
		standardRouteSection.setFromStationDayTime(new Time(wrapper
				.getFromStationTime().getTime()));
		standardRouteSection.setToStation(wrapper.getToStation());
		standardRouteSection.setToStationDayTime(new Time(wrapper
				.getToStationTime().getTime()));
		standardRouteSection.setUser(user);
		standardRouteSection.setDayOfWeek(cal.get(Calendar.DAY_OF_WEEK));

		return standardRouteSection;

	}

}
