import xls2list
import re

STATION_FILE='data/br. stajalista.xls'
GPS_FILE='data/gps.xls'
TRAM_LINE_DEFINITION_FILE='data/Stajalista s pozicijama - Tramvaj.xls'
BUS_LINE_DEFINITION_FILE='data/Stajalista s pozicijama - Autobus.xls'

OUTPUT_FILE='network.xml'

xmltemplate='''<?xml version="1.0" encoding="UTF-8"?>

<transport-network name="MyTransportNetwork">

    <transport-stations>
        {{stations}}
    </transport-stations>
    
    <transport-layers>

        <transport-layer type="tram">
            <transport-lines>
                {{tramlines}}
            </transport-lines>
        </transport-layer>

        <transport-layer type="bus">
            <transport-lines>
                {{buslines}}
            </transport-lines>
        </transport-layer>

    </transport-layers>

</transport-network>'''

stationtemplate='''
        <transport-station name="{{name}}" index="{{index}}">
            <display-name>{{display-name}}</display-name>
            <gps-location>
                <latitude>{{latitude}}</latitude>
                <longitude>{{longitude}}</longitude>
            </gps-location>
        </transport-station>'''

linetemplate='''
                <transport-line name="{{name}}">
                    <forward-transport-stations>
{{forwardstations}}
                    </forward-transport-stations>
                    <backward-transport-stations>
{{backwardstations}}
                    </backward-transport-stations>
                </transport-line>'''

def getgpsdata():
    gpsrows=xls2list.xls2list(GPS_FILE)
    gpsrows=gpsrows[1:]

    gpsdata={}
    for row in gpsrows:
        gpsdata[(int(row[0]),int(row[1]))]=row
    
    return gpsdata

def getstationdata():    
    stationrows=xls2list.xls2list(STATION_FILE)
    stationrows=stationrows[2:]
    
    stationdata={}
    for row in stationrows:
        stationdata[row[4]]=row
    return stationdata

def getlinedata(file):
    list=xls2list.xls2list(file)
    
    lines={}
    
    current=None
    
    for row in list:
        if row[0] is not None:
            mat=re.match('^Linija:\s*(\d+)\s+Trasa:\s*(\d+)\s+Smjer:\s*([AB])$',row[0])
            if mat is not None:
                if mat.group(2)=='0':
                    current=[]
                    lines[(int(mat.group(1)),mat.group(3))]=current
                else:
                    current=None
        elif row[2] is not None and current is not None:
            current.append((row[2],int(row[3])))
            
        
    for stationname in set([k[0] for k in lines.keys()]):
        if (stationname,'B') not in lines:
            data=lines[(stationname,'A')]
            newdata=[]
            newdata.extend(data)
            newdata.reverse()
            lines[(stationname,'B')]=newdata
        elif (stationname,'A') not in lines:
            data=lines[(stationname,'B')]
            newdata=[]
            newdata.extend(data)
            newdata.reverse()
            lines[(stationname,'A')]=newdata
    
#    print len(lines)
#    print len(set([k[0] for k in lines.keys()]))
    
    return lines

def generatelinedefs(linedata):
    
    linedefs=[]
    
    lines=list(set([int(line_dir[0]) for line_dir in linedata.keys()]))
    lines.sort()
    for line in lines:
        
        forwarddata=linedata[(line,'A')]
        backwarddata=linedata[(line,'B')]

        fwdlinestationdefs=[]
        for fd in forwarddata:
            keyname=fd[0]
            index=fd[1]
            stationname=stationdata[keyname][2]
            stationno=int(stationdata[keyname][1])
            fwdlinestationdefs.append('\t\t\t\t\t\t\t<transport-station name="%s" index="%d" />'%(keyname,index))
            usedstations.add((keyname,stationname,stationno,index))

        bkwlinestationdefs=[]
        for bd in backwarddata:
            keyname=bd[0]
            index=bd[1]
            stationname=stationdata[keyname][2]
            stationno=int(stationdata[keyname][1])
            bkwlinestationdefs.append('\t\t\t\t\t\t\t<transport-station name="%s" index="%d" />'%(keyname,index))
            usedstations.add((keyname,stationname,stationno,index))
    
        linedef=linetemplate.replace('{{name}}',str(line))
        linedef=linedef.replace('{{forwardstations}}',"\n".join(fwdlinestationdefs))
        linedef=linedef.replace('{{backwardstations}}',"\n".join(bkwlinestationdefs))
        linedefs.append(linedef)
        
    return linedefs

def generatestationdefs(usedstations):
    
    stationdefs=[]
    
    for usedstation in usedstations:
        (keyname,stationname,stationno,index)=usedstation
        gpsrow=gpsdata[(stationno,index)]
        
        latitude=gpsrow[6] and gpsrow[6] or 0.0
        longitude=gpsrow[7] and gpsrow[7] or 0.0
        
        stationdef=stationtemplate.replace("{{name}}",str(keyname))
        stationdef=stationdef.replace("{{display-name}}",stationname)
        stationdef=stationdef.replace("{{index}}",str(index))
        stationdef=stationdef.replace("{{latitude}}",str(latitude))
        stationdef=stationdef.replace("{{longitude}}",str(longitude))
        stationdefs.append(stationdef)
    
    return stationdefs

if __name__ == '__main__':
    
    gpsdata=getgpsdata()
    stationdata=getstationdata()
    tramdata=getlinedata(TRAM_LINE_DEFINITION_FILE)
    busdata=getlinedata(BUS_LINE_DEFINITION_FILE)
    
    usedstations=set()
    
    xml=xmltemplate
    
    tramlinedefs=generatelinedefs(tramdata)
    xml=xml.replace("{{tramlines}}", "\n".join(tramlinedefs))

    buslinedefs=generatelinedefs(busdata)
    xml=xml.replace("{{buslines}}", "\n".join(buslinedefs))

    stationdefs=generatestationdefs(usedstations)
    xml=xml.replace("{{stations}}", "\n".join(stationdefs))

    f=open(OUTPUT_FILE,'w')
    f.write(xml)
    f.close()