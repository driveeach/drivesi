///**
// * 
// */
//package dsd.transport4you.commprot.tests.unit;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import dsd.transport4you.interfaces.ITransportUnitUserData;
//import dsd.transport4you.interfaces.model.GpsLocation;
//import dsd.transport4you.interfaces.model.UserMacAddress;
//import dsd.transport4you.interfaces.model.WiFiAddress;
//
//import junit.framework.TestCase;
//
//import dsd.transport4you.commprot.factories.UserDataFactory;
//
///**
// * @author Dajan
// * 
// */
//public class FactoriesTest extends TestCase {
//
//	private List<UserMacAddress> newUsers;
//	private List<UserMacAddress> missingUsers;
//	private double latitude;
//	private double longitude;
//	private int transportId;
//
//
//	@Override
//	protected void setUp() throws Exception {
//
//		newUsers = new ArrayList<UserMacAddress>();
//		missingUsers = new ArrayList<UserMacAddress>();
//
//		for (int i = 0; i < 10; i++) {
//
//			newUsers.add(new WiFiAddress(Integer.toHexString(i)));
//			missingUsers.add(new WiFiAddress(Integer.toHexString(i + 10)));
//
//		}
//
//		latitude = 50.2;
//		longitude = 24.4;
//		transportId = 5;
//
//	}
//
//	public void testCreatedUserDataNotNull() {
//		ITransportUnitUserData userData1 = UserDataFactory
//				.getTransportUserData(newUsers, missingUsers, latitude,
//						longitude, transportId);
//		ITransportUnitUserData userData2 = UserDataFactory
//				.getTransportUserData(newUsers, newUsers, latitude, latitude,
//						transportId);
//		ITransportUnitUserData userData3 = UserDataFactory
//				.getTransportUserData(missingUsers, missingUsers, longitude,
//						longitude, transportId);
//		ITransportUnitUserData userData4 = UserDataFactory
//				.getTransportUserData(missingUsers, newUsers, latitude,
//						longitude, transportId);
//
//		assertNotNull(userData1);
//		assertNotNull(userData2);
//		assertNotNull(userData3);
//		assertNotNull(userData4);
//	}
//
//	public void testEqualUserData() {
//		ITransportUnitUserData userData1 = UserDataFactory
//				.getTransportUserData(newUsers, missingUsers, latitude,
//						longitude, transportId);
//		// ITransportUnitUserData userData2 =
//		// UserDataFactory.getTransportUserData(newUsers, missingUsers,
//		// latitude, longitude, transportId);
//
//		assertEquals(userData1, userData1);
//
//	}
//
//	public void testDataValidation() {
//		ITransportUnitUserData userData1 = UserDataFactory
//				.getTransportUserData(newUsers, missingUsers, latitude,
//						longitude, transportId);
//		ITransportUnitUserData userData2 = UserDataFactory
//				.getTransportUserData(missingUsers, newUsers, latitude,
//						longitude, transportId);
//		assertEquals(userData1.getMissingUsers(), missingUsers);
//		assertEquals(userData1.getNewUsers(), newUsers);
//		// assertEquals(userData1.getGpsLocation(), gpsLocation);
//		assertEquals(userData1.getTransportLineId(), (Integer) transportId);
//
//		assertEquals(userData2.getMissingUsers(), newUsers);
//		assertEquals(userData2.getNewUsers(), missingUsers);
//		// assertEquals(userData2.getGpsLocation(), gpsLocation);
//		assertEquals(userData2.getTransportLineId(), (Integer) transportId);
//
//	}
//
//	public void testTypeValidation() {
//
//		ITransportUnitUserData userData1 = UserDataFactory
//				.getTransportUserData(newUsers, missingUsers, latitude,
//						longitude, transportId);
//		ITransportUnitUserData userData2 = UserDataFactory
//				.getTransportUserData(missingUsers, missingUsers, latitude,
//						longitude, transportId);
//		assertTrue(userData1 instanceof ITransportUnitUserData);
//		assertTrue(userData2 instanceof ITransportUnitUserData);
//		assertTrue(userData1.getGpsLocation() instanceof GpsLocation);
//		assertTrue(userData2.getGpsLocation() instanceof GpsLocation);
//
//	}
//
//}
