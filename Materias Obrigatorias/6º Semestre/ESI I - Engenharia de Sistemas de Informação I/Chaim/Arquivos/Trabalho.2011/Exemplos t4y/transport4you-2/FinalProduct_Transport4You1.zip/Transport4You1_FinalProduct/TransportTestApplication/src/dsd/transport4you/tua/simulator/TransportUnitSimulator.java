/**
 * 
 */
package dsd.transport4you.tua.simulator;



import java.util.ArrayList;
import java.util.List;

import dsd.transport4you.interfaces.model.GpsLocation;
import dsd.transport4you.interfaces.model.MacAddress;
import dsd.transport4you.interfaces.model.MacAddress.AddressType;
import dsd.transport4you.interfaces.model.TransportLineDirection;
import dsd.transport4you.interfaces.model.TransportUnitLineData;
import dsd.transport4you.interfaces.util.GPSUtil;
import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.unit.eventHandler.TransportUnitObserver;
import dsd.transport4you.unit.model.BluetoothAddress;
import dsd.transport4you.unit.model.WiFiAddress;
import dsd.transport4you.unit.modules.simulators.BluetoothSimulatorModule;
import dsd.transport4you.unit.modules.simulators.GpsSimulatorModule;
import dsd.transport4you.unit.modules.simulators.WiFiSimulatorModule;
import dsd.transport4you.unit.simulator.SimulationSettings;
import dsd.transport4you.unit.simulator.TransportUnit;


/**
 * Simulates behavior of one transport unit.
 * 
 * @author Dino
 *
 */
public class TransportUnitSimulator implements Runnable{

	private TransportUnit transportUnit;
	private TransportUnitObserver transportUnitObserver;

	private List<TransportLineStation> forwardTrip;
	private List<TransportLineStation> backwardTrip;
	private boolean isLast = true; //is station last?

	private String transportUnitId;
	private TransportUnitLineData transportUnitLineData;
	
	/**
	 * Location of GPS module simulator
	 */
	private GpsLocation location;
	/**
	 * Addresses that are in bluetooth module simulator
	 */
	private List<BluetoothAddress> bluetoothAddresses;
	/**
	 * Addresses that are in WiFi module simulator
	 */
	private List<WiFiAddress> wiFiAddresses;

	/**
	 * Constructor. Creates transport unit simulator that will simulate driving of transport unit on
	 * specific line.  
	 * @param transportUnitId Transport unit Id
	 * @param transportLine Line on which unit will be driving
	 */
	public TransportUnitSimulator(String transportUnitId, TransportLine transportLine) {

		this.transportUnitLineData = new TransportUnitLineData(transportLine.getName(), TransportLineDirection.FORWARD);
		this.transportUnitId = transportUnitId;

		initializeTrips(transportLine);

		this.transportUnit = new TransportUnit();
		this.transportUnitObserver = new TransportUnitObserver(transportUnitId, transportUnitLineData);
		this.transportUnit.addObserver(transportUnitObserver);

		if (SimulationSettings.GPS_MODULE_IMPL == SimulationSettings.SIMULATOR) {
			GpsSimulatorModule gpsSimMod = (GpsSimulatorModule) transportUnitObserver.getGpsModule();
			location = gpsSimMod.getCurrentLocation();
		}		
	}

	@Override
	public void run() {		
		//If I am simulating driving
		if (SimulationSettings.GPS_MODULE_IMPL == SimulationSettings.SIMULATOR) {
			while (true) {
				isLast = true;
				for (int i = 0; i < forwardTrip.size() - 1; i++) {
					transportUnit.openDoor();
					stayAtStation(forwardTrip.get(i));
					transportUnit.changeDirectionToForward();
					transportUnit.closeDoor();
					drive(forwardTrip.get(i), forwardTrip.get(i + 1));
					isLast = false;
				}
				isLast = true;
				for (int i = 0; i < backwardTrip.size() - 1; i++) {
					transportUnit.openDoor();
					stayAtStation(backwardTrip.get(i));
					transportUnit.changeDirectionToBackward();
					transportUnit.closeDoor();
					drive(backwardTrip.get(i), backwardTrip.get(i + 1));
					isLast = false;
				}
			}
		}
	}

	/**
	 * Simulates staying at this station
	 * @param transportLineStation
	 */
	private void stayAtStation(TransportLineStation transportLineStation) {

		//update GPS location
		location.setLatitude(transportLineStation.getTransportStation().getGpsLocation().getLatitude());
		location.setLongitude(transportLineStation.getTransportStation().getGpsLocation().getLongitude());

		//simulate staying at station
		long time = (long)SimulationSettings.getStopTime();
		System.out.println("Staying at station "+transportLineStation.getTransportStation().getId()+" for "+time+" seconds");
		try {
			Thread.sleep(time * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		//exchange passengers
		int passengersExcangeCount = SimulationSettings.getPassengerExcangeCount();
		if(isLast){
			passengersExcangeCount *= SimulationSettings.LAST_STATION_COEFFICIENT;
		}
		UsersLocationService.passengersExitUnit(transportUnitId, 
				transportLineStation.getTransportStation().getId(), passengersExcangeCount);

		UsersLocationService.passengersEnterUnit(transportUnitId, 
				transportLineStation.getTransportStation().getId(), passengersExcangeCount);

		//update modules with correct addresses
		List<MacAddress> macAddresses = UsersLocationService.getUserMacAddressesInUnit(transportUnitId);
		updateAddressesList(macAddresses);
	}

	/**
	 * Simulates driving from station1 to station2
	 * @param transportLineStation1
	 * @param transportLineStation2
	 */
	private void drive(TransportLineStation transportLineStation1, 
			TransportLineStation transportLineStation2) {
			
		GpsLocation start = new GpsLocation(transportLineStation1.getTransportStation().getGpsLocation().getLatitude(),
				transportLineStation1.getTransportStation().getGpsLocation().getLongitude());
		GpsLocation end = new GpsLocation(transportLineStation2.getTransportStation().getGpsLocation().getLatitude(),
				transportLineStation2.getTransportStation().getGpsLocation().getLongitude());

		//prepare parameters
		double latitudeStart = start.getLatitude(); // deg
		double latitudeEnd = end.getLatitude();
		double longitudeStart = start.getLongitude();
		double longitudeEnd = end.getLongitude();

		double D = Math.round(GPSUtil.getDistance(start, end)); // m
		double V = SimulationSettings.getAvgSpeed() * 10/36; // m/s
		double T = D / V; //sec

		double Vy = (latitudeEnd - latitudeStart) / T; //deg/s
		double Vx = (longitudeEnd - longitudeStart) / T; //deg/s

		//simulate driving
		System.out.println("Driving from station "+transportLineStation1.getTransportStation().getId()+" to station "+transportLineStation2.getTransportStation().getId()+" for "+T+" seconds");
		for (int i = 0; i < T; i++) {

			double t = 0.01; //sleepTime, 1 sec
			latitudeStart = latitudeStart + Vy * t; //deg * 1 sec
			longitudeStart = longitudeStart + Vx * t; //deg
			location.setLatitude(latitudeStart);
			location.setLongitude(longitudeStart);

			try {
				Thread.sleep((long) (t * 1000));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			//on 1/3 of the trip reduce addresses in range count (TU is driving), move passengers back to station 1
			if(i == T/3){
				UsersLocationService.reducePassengersCount(transportUnitId, 
						transportLineStation1.getTransportStation().getId(), (double)1/8);

				//update modules with correct addresses
				List<MacAddress> macAddresses = UsersLocationService.getUserMacAddressesInUnit(transportUnitId);
				updateAddressesList(macAddresses);
			}
		}
//		location.setLatitude(transportLineStation2.getTransportStation().getGpsLocation().getLatitude());
//		location.setLongitude(transportLineStation2.getTransportStation().getGpsLocation().getLongitude());
	}

	/**
	 * Initialize lines needed for simulation
	 * @param transportLine Line that has been simulated
	 */
	private void initializeTrips(TransportLine transportLine) {
		forwardTrip = new ArrayList<TransportLineStation>(transportLine.getTransportLineStationsForwardTrip());
		backwardTrip = new ArrayList<TransportLineStation>(transportLine.getTransportLineStationsBackwardTrip());
	}

	/**
	 * Updates bluetooth and WiFi addresses that will be used to set modules
	 * @param macAddresses All MAC addresses in unit
	 */
	private void updateAddressesList(List<MacAddress> macAddresses) {
	
		wiFiAddresses = new ArrayList<WiFiAddress>();
		bluetoothAddresses = new ArrayList<BluetoothAddress>();
		
		for (MacAddress macAddress : macAddresses) {
			if(macAddress.getAddressType().equals(AddressType.WIFI)){
				wiFiAddresses.add(new WiFiAddress(macAddress.getAddress()));

			} else if (macAddress.getAddressType().equals(AddressType.BLUETOOTH)) {
				bluetoothAddresses.add(new BluetoothAddress(macAddress.getAddress()));
			}
		}		
		
		if(SimulationSettings.WIFI_MODULE_IMPL == SimulationSettings.SIMULATOR){
			WiFiSimulatorModule wifiSimMod = (WiFiSimulatorModule) transportUnitObserver.getWiFiModule();
			wifiSimMod.setAddressesInRange(wiFiAddresses);
		}

		if(SimulationSettings.BT_MODULE_IMPL == SimulationSettings.SIMULATOR){
			BluetoothSimulatorModule btSimMod = (BluetoothSimulatorModule) transportUnitObserver.getBluetoothModule();
			btSimMod.setAddressesInRange(bluetoothAddresses);
		}
	}
}
