package dsd.transport4you.main.notification;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.EntityManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.commprot.sms.SMSMessage;
import dsd.transport4you.commprot.util.exceptions.SMSModuleException;
import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.ApplicationSettings;
import dsd.transport4you.util.DateUtil;

public class SMSUserNotifier extends UserNotifier {

	private static Log log = LogFactory.getLog(SMSUserNotifier.class);
	private static SMSUserNotifier instance;
	private static SimpleDateFormat dateFormat = new SimpleDateFormat(ApplicationSettings.SMS_DATE_FORMAT);
	
	private SMSUserNotificationBuffer notificationBuffer;
	
	public static synchronized SMSUserNotifier getInstance(){
		if(instance==null){
			instance = new SMSUserNotifier();
		}
		return instance;
	}
	
	private SMSUserNotifier(){
		this.notificationBuffer=SMSUserNotificationBuffer.getInstance();
	}
	
	private synchronized void addSMSMessageToBuffer(String to,String message,Date time) throws SMSModuleException{
		notificationBuffer.add(new SMSMessage(null,to, message,time));
	}

	public void notifyTicketCheck(User user,Date validTo,Date when) {
		
		String message = notificationBundle.getString("T4U.TICKET_CHECK_NOTIFICATION");
		message = loadParameters(message,validTo,null, null, null, null, null, null, null);
		try {
			addSMSMessageToBuffer(user.getMobileUserInfo().getPhoneNumber(), message,when);
		} catch (SMSModuleException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.info(message);
	}
	

	@Override
	public void notifyTicketExpired(User user,Date when){
		String message = notificationBundle.getString("T4U.TICKET_EXPIRED_NOTIFICATION");
		message = loadParameters(message,null,null, null, null, null, null, null, null);
		try {
			addSMSMessageToBuffer(user.getMobileUserInfo().getPhoneNumber(), message,when);
		} catch (SMSModuleException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.info(message);
	}
	
	@Override
	public void notifyTicketRemainder(User user, Date when) {
		String message = notificationBundle.getString("T4U.TICKET_REMAINDER_NOTIFICATION");
		message = loadParameters(message,null,null, null, null, null, null, null, null);
		try {
			addSMSMessageToBuffer(user.getMobileUserInfo().getPhoneNumber(), message,when);
		} catch (SMSModuleException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.info(message);
	}

	@Override
	public void notifyLowPrepaidTicketWarning(User user, Integer ticketRemainingCount, Date when) {
		
		String message = notificationBundle.getString("T4U.LOW_PREPAID_TICKET_WARNING_NOTIFICATION");
		message = loadParameters(message,null,ticketRemainingCount, null, null, null, null, null, null);
		try {
			addSMSMessageToBuffer(user.getMobileUserInfo().getPhoneNumber(), message,when);
		} catch (SMSModuleException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.info(message);
	}
	
	private String loadParameters(String message,Date validTo, Integer ticketRemainingCount, String transportLineName, String fromStation, String toStation, String modifiedStationList, Date fromTime, Date toTime) {
		
		if(validTo!=null){
			message=message.replace("{{timeValidTo}}", dateFormat.format(validTo));
		}
		
		if(ticketRemainingCount!=null){
			message=message.replace("{{prepaidTicketCount}}",String.valueOf(ticketRemainingCount));
		}
		
		if(transportLineName!=null){
			message=message.replace("{{transportLineName}}",transportLineName);
		}
		if(fromStation!=null){
			message=message.replace("{{fromStation}}",fromStation);
		}
		if(toStation!=null){
			message=message.replace("{{toStation}}",toStation);
		}
		if(modifiedStationList!=null){
			message=message.replace("{{modifiedStationList}}", modifiedStationList);
		}
		if(fromTime!=null){
			message=message.replace("{{fromTime}}",dateFormat.format(fromTime));
		}
		if(toTime!=null){
			message=message.replace("{{toTime}}",dateFormat.format(toTime));
		}
		
		message=message.replace("{{smsPaymentMsg}}", ApplicationSettings.SMS_PAYMENT_MSG);
		message=message.replace("{{smsPaymentNumber}}", ApplicationSettings.SMS_PAYMENT_NO);
		message=message.replace("{{t4uWebUrl}}", ApplicationSettings.T4U_WEB_URL);
		message=message.replace("{{t4uName}}", ApplicationSettings.T4U_NAME);

		return message;
	}
	
	@Override
	public void notifyStandardRouteInterruption(User user, Date timeToSend,
			String transportLineName, String fromStation, String toStation,
			Date fromTime, Date toTime) {
		
		String message = notificationBundle.getString("T4U.INTERRUPTION_NOTIFICATION");
		message = loadParameters(message,null,null,transportLineName,fromStation,toStation,null,fromTime,toTime);
		try {
			addSMSMessageToBuffer(user.getMobileUserInfo().getPhoneNumber(), message,timeToSend);
		} catch (SMSModuleException e) {
			e.printStackTrace();
		}
		log.info(message);
	}
	
	@Override
	public void notifyStandardRouteModification(User user, Date timeToSend,
			String transportLineName, String fromStation, String toStation,
			String modifiedStationList, Date fromTime, Date toTime) {
		
		String message = notificationBundle.getString("T4U.MODIFICATION_NOTIFICATION");
		message = loadParameters(message,null,null,transportLineName,fromStation,toStation,modifiedStationList,fromTime,toTime);
		try {
			addSMSMessageToBuffer(user.getMobileUserInfo().getPhoneNumber(), message,timeToSend);
		} catch (SMSModuleException e) {
			e.printStackTrace();
		}
		log.info(message);
		
	}
	
	public static void main(String[] args){
		
		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		EntityManager em = dao.getEntityManager();

		UserNotifier notifier = SMSUserNotifier.getInstance();
		
		Date now = new Date();
		
		User user = dao.getUserById(1);
		Date validTo = new Date();
		validTo=DateUtil.add(Calendar.SECOND, ApplicationSettings.T_VAL, validTo);
		
//		notifier.notifyTicketCheck(user,validTo);
//		notifier.notifyTicketExpired(user,now);
		
		notifier.notifyLowPrepaidTicketWarning(user, 3, now);
		
		dao.close();
	}
}
