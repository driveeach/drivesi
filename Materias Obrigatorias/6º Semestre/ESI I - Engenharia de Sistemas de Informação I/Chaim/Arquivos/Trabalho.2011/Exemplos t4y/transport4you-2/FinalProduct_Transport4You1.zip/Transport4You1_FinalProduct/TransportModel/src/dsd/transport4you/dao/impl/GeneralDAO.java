package dsd.transport4you.dao.impl;

import java.util.Collection;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.user.User;
import dsd.transport4you.model.user.authorization.Role;
import dsd.transport4you.model.user.authorization.Role.RoleType;

public class GeneralDAO {

	private EntityManagerFactory emf;
	protected EntityManager em;

	private static final Log log = LogFactory.getLog(GeneralDAO.class);

	public GeneralDAO(EntityManagerFactory emf) {
		this.emf = emf;
		createEntityManager();
	}
	
	public void createEntityManager() {
		if(this.em==null){
			this.em = this.emf.createEntityManager();
			log.info("em created");
		}
	}

	/**
	 * Get user by id from database.
	 * 
	 * @param id
	 *            User id.
	 * @param session
	 *            Entity Manager session.
	 * @return User.
	 */
	public User getUserById(Integer id) {
		return (User) em.createNamedQuery("userById").setParameter(1, 1)
				.getSingleResult();
	}

	/**
	 * Save entity object to database.
	 * 
	 * @param obj
	 *            Entity object.
	 */
	public void save(Object obj) {
		em.persist(obj);
	}

	/**
	 * Update entity object in database.
	 * 
	 * @param obj
	 *            Entity object.
	 */
	public void update(Object obj) {
		em.merge(obj);
	}

	/**
	 * Delete entity object from database.
	 * 
	 * @param obj
	 *            Entity object.
	 */
	public void delete(Object obj) {
		em.remove(obj);
	}

	public void beginTransaction(){
		getEntityManager().getTransaction().begin();
	}
	public void commitTransaction(){
		getEntityManager().getTransaction().commit();
	}
	public void rollbackTransaction(){
		getEntityManager().getTransaction().rollback();
	}
	
	public EntityManager getEntityManager() {
		return this.em;
	}

	public void close() {
		this.em.close();
		this.em=null;
		log.info("em closed");
	}

	public TransportLine getTransportLineByName(String name) {
		try {
			return (TransportLine) em.createNamedQuery("transportLineByName")
					.setParameter(1, name).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public Collection<User> getAllUsers() {
		return (Collection<User>)em.createNamedQuery("allUsers").getResultList();
	}
	
	public Role getRoleByType(RoleType roleType) {
		Role role;
		try{
			role = (Role)em.createNamedQuery("roleByName")
						   .setParameter(1,roleType.name())
						   .getSingleResult();
		}catch(NoResultException e){
			role=null;
		}
		return role;
	}
	
//	public Collection<User> getAdminUsers() {
//		Role adminRole = getRoleByName(RoleType.ADMIN);
//		System.out.println("adminRole:"+adminRole);
//		
//		Collection<User> users = new LinkedList<User>();
//		
//		System.out.println("uirs:"+adminRole.getUsersInRole());
//		
//		for(UserInRole uir : adminRole.getUsersInRole()){
//			users.add(uir.getUser());
//		}
//		return users;
//	}
}
