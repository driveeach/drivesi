package dsd.transport4you.actions;

import java.util.ArrayList;
import java.util.List;

import dsd.transport4you.model.news.News;

public class IndexAction extends ExtendedActionSupport {

	private static final long serialVersionUID = -4805972025849521694L;

	private List<News> allNews;
	
	private String errorMsg;

	@Override
	public String execute() throws Exception {
		allNews = new ArrayList<News>(webDAO.getAllNews());
		return SUCCESS;
	}
	
	
	public List<News> getAllNews() {
		return allNews;
	}

	public void setAllNews(List<News> allNews) {
		this.allNews = allNews;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
}
