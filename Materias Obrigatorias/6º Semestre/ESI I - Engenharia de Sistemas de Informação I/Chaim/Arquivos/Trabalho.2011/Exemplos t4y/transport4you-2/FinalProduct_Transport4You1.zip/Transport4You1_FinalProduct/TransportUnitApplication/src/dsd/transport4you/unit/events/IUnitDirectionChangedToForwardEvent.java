package dsd.transport4you.unit.events;

public class IUnitDirectionChangedToForwardEvent {

}
