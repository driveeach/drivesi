package dsd.transport4you.util;

import java.security.MessageDigest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.thoughtworks.xstream.core.util.Base64Encoder;


/**
 * String Utility Class This is used to encode passwords programmatically
 *
 * <p>
 * <a h
 * ref="StringUtil.java.html"><i>View Source</i></a>
 * </p>
 * 
 * @author <a href="mailto:matt@raibledesigns.com">Matt Raible</a>
 */
public class StringUtil {
    //~ Static fields/initializers =============================================

    private final static Log log = LogFactory.getLog(StringUtil.class);

    //~ Methods ================================================================

    /**
     * Encode a string using algorithm specified in web.xml and return the
     * resulting encrypted password. If exception, the plain credentials
     * string is returned
     *
     * @param password Password or other credentials to use in authenticating
     *        this username
     * @param algorithm Algorithm used to do the digest
     *
     * @return encypted password based on the algorithm.
     */
    public static String encodePassword(String password, String algorithm) {
        byte[] unencodedPassword = password.getBytes();

        MessageDigest md = null;

        try {
            // first create an instance, given the provider
            md = MessageDigest.getInstance(algorithm);
        } catch (Exception e) {
            log.error("Exception: " + e);

            return password;
        }

        md.reset();

        // call the update method one or more times
        // (useful when you don't know the size of your data, eg. stream)
        md.update(unencodedPassword);

        // now calculate the hash
        byte[] encodedPassword = md.digest();

        StringBuilder buf = new StringBuilder(encodedPassword.length << 1);

        for (int i = 0; i < encodedPassword.length; i++) {
            if ((encodedPassword[i] & 0xff) < 0x10) {
                buf.append("0");
            }

            buf.append(Integer.toString(encodedPassword[i] & 0xff, 16));
        }

        return buf.toString();
    }

    /**
     * Encode a string using Base64 encoding. Used when storing passwords
     * as cookies.
     *
     * This is weak encoding in that anyone can use the decodeString
     * routine to reverse the encoding.
     *
     * @param str
     * @return String
     */
    public static String encodeString(String str)  {
    	Base64Encoder encoder = new Base64Encoder();
        return encoder.encode(str.getBytes()).trim();
    }

    /**
     * Decode a string using Base64 encoding.
     *
     * @param str
     * @return String
     */
    public static String decodeString(String str) {
        Base64Encoder encoder = new Base64Encoder();
        try {
            return new String(encoder.decode(str));
        } catch (Exception io) {
        	throw new RuntimeException(io.getMessage(), io.getCause());
        }
    }
    
    public static String[] split(String s, char delimiter) {
    	int broj = 0;
    	for(int i = s.length()-1; i >= 0; i--) {
    		if(s.charAt(i)==delimiter) broj++;
    	}
    	String[] res = new String[broj+1];
    	int pos; int curr=0;
    	for(int i = 0; i < broj; i++) {
    		pos = s.indexOf(delimiter, curr);
    		res[i] = s.substring(curr, pos);
    		curr = pos+1;
    	}
    	res[broj] = s.substring(curr);
    	return res;
    }
    
    public static void main(String[] args) {
		
    	System.out.println("encoded:"+encodePassword("pass", "SHA"));
    	System.out.println("encoded:"+encodePassword("pass", "MD5"));
    	
	}
}
