package dsd.transport4you.settings;

/**
 * Transient class for application settings. Parameters will be read from file.
 * Not persistent in database.
 * 
 * @author toni, dajan
 * 
 */
public class ApplicationSettings {

	/**
	 * Ticket time validity (in seconds).
	 */
	public static final Integer T_VAL = 60 * 60;
	public static final Integer T_COST = 5;

	public static final Boolean NOTIFY_ON_SUCCESSFUL_PURCHASE_DEFAULT = true;
	public static final Boolean NOTIFY_ON_STANDARD_ROUTE_CHANGE_DEFAULT = true;
	public static final Boolean NOTIFY_ON_STANDARD_ROUTE_OPTIMIZATION_DEFAULT = true;
	public static final String DEFAULT_PAYMENT_MODE = "PREPAID";
	
	public static final Integer SERVER_SOCKET = 3000;
	public static final Integer SERVER_TASK_QUEUE_SIZE = 100;
	public static final Integer SERVER_HANDLER_COUNT = 10;
	
	public static final Double GPS_LOCATION_RADIUS = 50.0;
	
	public static final String PASSWORD_HASH_ALGORITHM="SHA1";
	public static final String HASH_SALT = "ThisIsT4USuperSecretSalt";
	
	public static final Integer TASK_ROUTE_INACTIVATION_PERIOD=1*60;
	public static final Integer TASK_TICKET_EXPIRATION_PERIOD = 1*60;
	public static final Integer TASK_SMS_TICKET_RECEIVER_PERIOD = 1*60;
	public static final Integer TASK_SMS_TICKET_SENDER_PERIOD = 10;
	public static final Integer TASK_MODIFICATION_NOTIFICATION_PERIOD = 10;

	public static final Integer TRANSPORT_ROUTE_INACTIVATION_TIME = 20*60;

	public static final Integer DB_LOADER_TRANSPORT_UNIT_COUNT = 1;
	public static final Integer DB_LOADER_USER_COUNT = 0;
	public static final Integer DB_LOADER_NEWS_COUNT = 20;
	public static final Integer DB_LOADER_ADMIN_COUNT = 1;
	public static final Integer DB_LOADER_PREPAID_TICKET_COUNT = 0;

	public static final String LOCALE = "en";

	public static final Integer SMS_DUMMY=0;
	public static final Integer SMS_GNOKII=1;
	public static final Integer SMS_MODULE_IMPL=SMS_GNOKII;
	
	public static final String SMS_PAYMENT_MSG="T4U";
	public static final String SMS_PAYMENT_NO="0955029950";
	public static final Integer LOW_TICKET_WARNING_COUNT = 3;
	public static final Integer SMS_PAYMENT_REMAINDER_TIME=20;
	public static final String SMS_DATE_FORMAT="H:mm";
	
	public static final Integer STANDARD_ROUTE_SECTION_TIME_FRAME =  30*60*1000; //miliseconds
	public static final Integer STANDARD_ROUTE_SECTION_STATION_FRAME = 2;
	public static final Integer STANDARD_ROUTE_SECTION_MIN_COUNTER = 5; //min counter for standard route
	public static final Integer STANDARD_ROUTE_SECTION_NOTIFICATION_NUMBER = 5; //number of identified standard routes for notification
	public static final Double STANDARD_ROUTE_SECTION_MATCH_RATIO = 0.8;

	public static final int NOTIFY_ALL = 0;
	public static final int NOTIFY_STANDARD_ROUTES = 1;
	public static final int MODIFICATION_INTERRUPTION_NOTIFICATION_STRATEGY = NOTIFY_ALL;
	
	public static final String T4U_WEB_URL = "www.t4u.com";
	public static final String T4U_NAME = "Transport4You d.o.o";

	public static final int SESSION_COOKIE_MAX_AGE = 60*60*24*14; //2 weeks

}
