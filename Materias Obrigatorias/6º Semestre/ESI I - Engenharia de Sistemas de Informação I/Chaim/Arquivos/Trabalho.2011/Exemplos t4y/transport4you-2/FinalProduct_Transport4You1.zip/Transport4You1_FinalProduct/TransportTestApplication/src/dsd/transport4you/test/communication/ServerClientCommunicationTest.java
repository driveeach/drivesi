/**
 * 
 */
package dsd.transport4you.test.communication;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import dsd.transport4you.commprot.TcpClient;
import dsd.transport4you.commprot.TcpServer;
import dsd.transport4you.commprot.util.threads.TransportUnitUserDataHandler;
import dsd.transport4you.interfaces.model.GpsLocation;
import dsd.transport4you.interfaces.model.MacAddress;
import dsd.transport4you.interfaces.model.MacAddress.AddressType;
import dsd.transport4you.interfaces.model.TransportLineDirection;
import dsd.transport4you.interfaces.model.TransportUnitLineData;
import dsd.transport4you.interfaces.model.UserData;
import dsd.transport4you.main.factories.TransportUserDataHandlerFactory;

/**
 * @author Dajan
 *
 */
public class ServerClientCommunicationTest{

public static void main(String[] args) {
	
	try {
		TcpServer server = new TcpServer(3000, 1000, TransportUnitUserDataHandler.class, new TransportUserDataHandlerFactory(), 4);
		new Thread(server).start();
		
		UserData userData = new UserData();
		//List<MacAddress> users = new ArrayList<MacAddress>();
		userData.setTransportLine(new TransportUnitLineData("15", TransportLineDirection.FORWARD));
		List<MacAddress> missingUsers = new ArrayList<MacAddress>();
		missingUsers.add(new MacAddress(AddressType.BLUETOOTH, "dino"));
		userData.setMissingUsers(missingUsers);
		List<MacAddress> newUsers = new ArrayList<MacAddress>();
		newUsers.add(new MacAddress(AddressType.BLUETOOTH, "dajan"));
		userData.setNewUsers(newUsers);
		userData.setGpsLocation(new GpsLocation(10,10));
		
		for(int i = 0; i < 50; i++){
			TcpClient client = new TcpClient("localhost",3000, userData);
			client.sendData();
		}
		
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
	
}
