/**
 * 
 */
package dsd.transport4you.unit.modules.simulators;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import dsd.transport4you.unit.model.WiFiAddress;
import dsd.transport4you.unit.modules.WiFiModule;
import dsd.transport4you.unit.simulator.SimulationSettings;

/**
 * Detects passengers inside the transport unit over WiFi
 * 
 * @author Dino
 *
 */
public class WiFiSimulatorModule extends WiFiModule {

	public List<WiFiAddress> wiFiAddresses;

	public WiFiSimulatorModule() {
		this.wiFiAddresses = Collections.synchronizedList(new ArrayList<WiFiAddress>());

	}

	@Override
	public Set<WiFiAddress> getAddressesInRange() {

		Set<WiFiAddress> addressesInRange;
		synchronized (wiFiAddresses) {
			addressesInRange = new TreeSet<WiFiAddress>(wiFiAddresses);
		}
	
		try {
			Thread.sleep((long)(SimulationSettings.getWifiDetectionTime() * 1000));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		return addressesInRange;
	}
	
	/**
	 * Sets addresses in range of this module
	 * @param addressesInRange Addresses that are in range of this module
	 */
	public void setAddressesInRange(List<WiFiAddress> addressesInRange){
		synchronized (wiFiAddresses) {
			wiFiAddresses.removeAll(wiFiAddresses);
			wiFiAddresses.addAll(addressesInRange);
		}
	}
}
