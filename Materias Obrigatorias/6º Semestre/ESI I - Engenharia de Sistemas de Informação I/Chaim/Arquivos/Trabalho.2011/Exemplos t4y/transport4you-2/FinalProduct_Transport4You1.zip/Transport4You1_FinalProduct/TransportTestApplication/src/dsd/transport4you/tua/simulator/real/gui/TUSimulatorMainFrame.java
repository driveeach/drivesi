package dsd.transport4you.tua.simulator.real.gui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import dsd.transport4you.unit.simulator.TransportUnit;

public class TUSimulatorMainFrame extends JFrame {

	private static final long serialVersionUID = 6433980167363957176L;

	volatile boolean terminateThread = false;

	private JLabel labelDoorsStatus;
	private JLabel labelLineStatus;
	
	private JButton buttonOpenDoors;
	private JButton buttonCloseDoors;
	private JButton buttonSelectLine;
	
	private JList listTransportLines;
	private JPanel panelButtons;
	private JPanel panelLabels;
	private JPanel panelLines;
	private JPanel panelRightContainer;

	private TransportUnit transportUnit;
	private List<String> transportLines;
	private String currentLine;

	/**
	 * Constructor
	 * @param linesForGUI 
	 * @param pso 
	 */
	public TUSimulatorMainFrame(TransportUnit transportUnit, List<String> transportLines) {
		this.transportUnit = transportUnit;
		this.transportLines = transportLines;
		
		createGUI();
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		//tell all threads to finish
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent e) {
				super.windowClosed(e);
				terminateThread = true;
			}
		});
	}

	/**
	 * Main window creation
	 */
	private void createGUI() {
		labelDoorsStatus = new JLabel();
		labelLineStatus = new JLabel();

		buttonOpenDoors = new JButton();
		buttonOpenDoors.setText(GUISettings.BUTTON_OPEN_DOORS_TEXT);
		buttonOpenDoors.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				transportUnit.openDoor();
				updateStatus();
			}
		});
		
		buttonCloseDoors = new JButton();
		buttonCloseDoors.setText(GUISettings.BUTTON_CLOSE_DOORS_TEXT);
		buttonCloseDoors.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				transportUnit.closeDoor();
				updateStatus();
			}

		});
		
		buttonSelectLine = new JButton();
		buttonSelectLine.setText(GUISettings.BUTTON_SELECT_LINE_TEXT);
		buttonSelectLine.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				currentLine = listTransportLines.getSelectedValue().toString();
				
				updateStatus();
			}

		});
		
		listTransportLines = new JList(transportLines.toArray());
		
		panelLabels = new JPanel();
		panelLabels.setLayout(new GridLayout(3,1));
		panelLabels.add(labelDoorsStatus);
		panelLabels.add(labelLineStatus);

		panelButtons = new JPanel();
		panelButtons.setLayout(new GridLayout(1,2));
		panelButtons.add(buttonOpenDoors);
		panelButtons.add(buttonCloseDoors);

		panelLines = new JPanel();
		panelLines.setLayout(new GridLayout(2,1));
		panelLines.add(listTransportLines);
		panelLines.add(buttonSelectLine);
		
		panelRightContainer = new JPanel();
		panelRightContainer.setLayout(new GridLayout(2, 1));
		panelRightContainer.add(panelButtons);
		panelRightContainer.add(panelLabels);
				
		this.getContentPane().setLayout(new GridLayout(1,2));
		this.getContentPane().add(panelLines);
		this.getContentPane().add(panelRightContainer);

		this.setPreferredSize(new Dimension(GUISettings.WINDOW_WIDTH, GUISettings.WINDOW_HEIGHT));
		pack();

	}
	
	private void updateStatus() {
		labelDoorsStatus.setText("Doors is "+transportUnit.getDoorsState());
		labelLineStatus.setText("Driving on "+currentLine+" line.");
	}
}
