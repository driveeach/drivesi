/**
 * 
 */
package dsd.transport4you.unit.modules.hardware;

import dsd.transport4you.settings.ITransportUnitUserData;
import dsd.transport4you.unit.modules.GprsModule;

/**
 * Class with GPS methods. Can get current GPS location.
 * 
 * @author Dino
 *
 */
public class GprsHardwareModule extends GprsModule{

	@Override
	public void sendData(ITransportUnitUserData userData) {
		// TODO Auto-generated method stub
		
	}



}
