/**
 * 
 */
package dsd.transport4you.model.route;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.settings.ApplicationSettings;

/**
 * @author Dajan
 * 
 */
public class TransportRouteSectionWrapper implements
		Comparable<TransportRouteSectionWrapper> {

	private Integer id;
	/**
	 * Route this route sections belongs to.
	 */
	private TransportRoute route;
	/**
	 * Transport Station where user has entered transport unit.
	 */
	private TransportLineStation fromStation;
	/**
	 * Transport Station where user has exited transport unit.
	 */
	private TransportLineStation toStation;
	/**
	 * Time when user has entered transport unit.
	 */
	private Date fromStationTime;
	/**
	 * Time when user has exited transport unit.
	 */
	private Date toStationTime;

	private Integer counter;

	public TransportRouteSectionWrapper(TransportRouteSection routeSection) {

		this.fromStation = routeSection.getFromStation();
		this.fromStationTime = routeSection.getFromStationTime();
		this.route = routeSection.getRoute();
		this.toStation = routeSection.getToStation();
		this.toStationTime = routeSection.getToStationTime();
		this.id = routeSection.getId();
		counter = 0;

	}

	public TransportLine getTransportLine() {

		if (fromStation.getTransportLineBackward() != null) {
			return fromStation.getTransportLineBackward();
		} else {
			return fromStation.getTransportLineForward();
		}
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TransportRoute getRoute() {
		return route;
	}

	public void setRoute(TransportRoute route) {
		this.route = route;
	}

	public TransportLineStation getFromStation() {
		return fromStation;
	}

	public void setFromStation(TransportLineStation fromStation) {
		this.fromStation = fromStation;
	}

	public TransportLineStation getToStation() {
		return toStation;
	}

	public void setToStation(TransportLineStation toStation) {
		this.toStation = toStation;
	}

	public Date getFromStationTime() {
		return fromStationTime;
	}

	public void setFromStationTime(Date fromStationTime) {
		this.fromStationTime = fromStationTime;
	}

	public Date getToStationTime() {
		return toStationTime;
	}

	public void setToStationTime(Date toStationTime) {
		this.toStationTime = toStationTime;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj) {
			return true;
		}
		if (!(obj instanceof TransportRouteSectionWrapper)) {
			return false;
		}

		TransportRouteSectionWrapper routeSectionWrapper = (TransportRouteSectionWrapper) obj;

		if (this == routeSectionWrapper) {
			return true;
		}
		GregorianCalendar cal1 = new GregorianCalendar();
		cal1.setTime(fromStationTime);

		GregorianCalendar cal2 = new GregorianCalendar();
		cal2.setTime(routeSectionWrapper.fromStationTime);

		if (cal1.get(Calendar.DAY_OF_WEEK) == cal2.get(Calendar.DAY_OF_WEEK)) {
			if (cal2.getTimeInMillis() >= cal1.getTimeInMillis()
					- ApplicationSettings.STANDARD_ROUTE_SECTION_TIME_FRAME
					|| cal2.getTimeInMillis() <= cal1.getTimeInMillis()
							+ ApplicationSettings.STANDARD_ROUTE_SECTION_TIME_FRAME) {
				if (this.fromStation.getTransportLineBackward() == null
						&& routeSectionWrapper.fromStation
								.getTransportLineBackward() == null) {
					if (this.fromStation.equals(routeSectionWrapper
							.getFromStation())) {
						return true;
					}
					TransportLine line1 = this.fromStation
							.getTransportLineForward();
					TransportLine line2 = this.fromStation
							.getTransportLineForward();

					if (line1.equals(line2)) {
						int stationNumber1 = this.fromStation
								.getStationNumber();
						int stationNumber2 = routeSectionWrapper
								.getFromStation().getStationNumber();
						if (stationNumber2 >= stationNumber1
								- ApplicationSettings.STANDARD_ROUTE_SECTION_STATION_FRAME
								&& stationNumber2 <= stationNumber1
										+ ApplicationSettings.STANDARD_ROUTE_SECTION_STATION_FRAME) {
							return true;
						}
					}

				}

				if (this.fromStation.getTransportLineForward() == null
						&& routeSectionWrapper.fromStation
								.getTransportLineForward() == null) {
					if (this.fromStation.equals(routeSectionWrapper
							.getFromStation())) {
						return true;
					}

					TransportLine line1 = this.fromStation
							.getTransportLineBackward();
					TransportLine line2 = this.fromStation
							.getTransportLineBackward();

					if (line1.equals(line2)) {
						int stationNumber1 = this.fromStation
								.getStationNumber();
						int stationNumber2 = routeSectionWrapper
								.getFromStation().getStationNumber();
						if (stationNumber2 >= stationNumber1
								- ApplicationSettings.STANDARD_ROUTE_SECTION_STATION_FRAME
								&& stationNumber2 <= stationNumber1
										+ ApplicationSettings.STANDARD_ROUTE_SECTION_STATION_FRAME) {
							return true;
						}
					}

				}

			}
		}

		return false;

	}

	public boolean compareAndCalculate(TransportRouteSectionWrapper wrapper) {
		if (wrapper.getTransportLine().equals(this.getTransportLine())) {
			return false;
		} else {

			TransportLine line1 = this.getTransportLine();
			TransportLine line2 = wrapper.getTransportLine();

			List<TransportLineStation> lineStations1 = null;
			List<TransportLineStation> lineStations2 = null;

			if (line1.getTransportLineStationsBackwardTrip() == null) {
				lineStations1 = new ArrayList<TransportLineStation>(
						line1.getTransportLineStationsForwardTrip());
			} else {
				lineStations1 = new ArrayList<TransportLineStation>(
						line1.getTransportLineStationsBackwardTrip());
			}

			if (line2.getTransportLineStationsBackwardTrip() == null) {
				lineStations2 = new ArrayList<TransportLineStation>(
						line2.getTransportLineStationsForwardTrip());
			} else {
				lineStations2 = new ArrayList<TransportLineStation>(
						line2.getTransportLineStationsBackwardTrip());
			}

			int stationFromNumber1 = this.fromStation.getStationNumber();
			int stationFromNumber2 = wrapper.fromStation.getStationNumber();

			int stationToNumber1 = this.toStation.getStationNumber();
			int stationToNumber2 = wrapper.toStation.getStationNumber();

			int equalStations = 0;

			for (int i = stationFromNumber1; i < stationToNumber1; i++) {
				for (int j = stationFromNumber2; j < stationToNumber2; j++) {
					if (lineStations1.get(i).equals(lineStations2.get(j))) {
						equalStations++;
					}
				}
			}

			Double matchRatio = (double) (equalStations / lineStations1.size());

			if (matchRatio <= ApplicationSettings.STANDARD_ROUTE_SECTION_MATCH_RATIO) {

				this.counter += wrapper.getCounter();
				wrapper.setCounter(wrapper.counter + this.counter);

				return true;
			}

			return false;

		}

	}

	public Integer getCounter() {
		return counter;
	}

	public void setCounter(Integer counter) {
		this.counter = counter;
	}

	public void increaseCounter(int i) {
		this.counter += i;
	}

	@Override
	public int compareTo(TransportRouteSectionWrapper o) {

		if (this.counter > o.counter) {
			return 1;
		}

		if (this.counter < o.counter) {
			return -1;
		}

		return 0;
	}

}
