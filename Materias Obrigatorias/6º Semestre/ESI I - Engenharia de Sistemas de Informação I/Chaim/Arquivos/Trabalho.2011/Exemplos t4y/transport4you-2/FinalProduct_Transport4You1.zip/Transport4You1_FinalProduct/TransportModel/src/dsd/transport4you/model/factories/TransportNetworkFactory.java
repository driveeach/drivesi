package dsd.transport4you.model.factories;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.model.factories.xml.TransportNetworkXMLDeserializer;
import dsd.transport4you.model.network.TransportLayer;
import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.network.TransportNetwork;
import dsd.transport4you.util.exceptions.InvalidNetworkXMLFile;
import dsd.transport4you.util.exceptions.TransportModelValidationException;

/**
 * Factory for creation of TransportNetwork objects.
 * @author toni
 */
public class TransportNetworkFactory {

	private static Log log = LogFactory.getLog(TransportNetworkFactory.class);
	
	/**
	 * Method creates TransportNetwork object with all its sub-hierarchy
	 * based on its definition in the given xml file.
	 * @param args path to transport network xml file.
	 * @return created transport network object.
	 * @throws InvalidNetworkXMLFile in case of any problem with the xml file.
	 */
	public static TransportNetwork fromXML(String path) throws InvalidNetworkXMLFile{
		log.info("creating network from "+path);
		TransportNetwork network =  new TransportNetworkXMLDeserializer(path).deserialize();
		printNetwork(network);
		try {
			network.validate();
		} catch (TransportModelValidationException e) {
			throw new InvalidNetworkXMLFile(e);
		}
		return network;
	}
	
	public static void main(String[] args) throws InvalidNetworkXMLFile{
		
		String filename = args[0];
		TransportNetwork network = TransportNetworkFactory.fromXML(filename);
	}

	private static void printNetwork(TransportNetwork network) {
		log.info("network: "+network);
		
		System.out.println(network);
		
		for(TransportLayer layer : network.getTransportLayers()){
			
			System.out.println("\t"+layer.toString());
			for(TransportLine line : layer.getTransportLines()){
				System.out.println("\t\t"+line.toString());
				
				System.out.println("\t\tforward");
				for(TransportLineStation ls : line.getTransportLineStationsForwardTrip()){
					System.out.println("\t\t\t#"+ls.getStationNumber()+" "+ls.getTransportStation());
				}
				
				System.out.println("\t\tbackward");
				for(TransportLineStation ls : line.getTransportLineStationsBackwardTrip()){
					System.out.println("\t\t\t#"+ls.getStationNumber()+" "+ls.getTransportStation());
				}
			}
		}
	}

}
