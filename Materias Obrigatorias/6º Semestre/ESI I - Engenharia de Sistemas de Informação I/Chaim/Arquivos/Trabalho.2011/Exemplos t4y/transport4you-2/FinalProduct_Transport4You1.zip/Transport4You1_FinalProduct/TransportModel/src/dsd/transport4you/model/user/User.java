package dsd.transport4you.model.user;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import dsd.transport4you.model.Payment;
import dsd.transport4you.model.Ticket;
import dsd.transport4you.model.route.TransportRoute;
import dsd.transport4you.model.route.standard.TransportStandardRouteSection;
import dsd.transport4you.model.user.authorization.Role;
import dsd.transport4you.model.user.authorization.UserInRole;
import dsd.transport4you.model.user.options.UserOptions;
import dsd.transport4you.settings.ApplicationSettings;
import dsd.transport4you.util.exceptions.NoActiveRoutesException;

/**
 * Class is an entity object. Class contains personal user informations, mobile
 * user informations, credit card user information and user options.
 * 
 * @author toni, dajan
 * 
 */
@Entity
@Table(name = "USER")
@NamedQueries({
		@NamedQuery(name = "userById", query = "SELECT u FROM User u WHERE u.id = ?1"),
		@NamedQuery(name = "userByWifiMacAddress", query = "SELECT u FROM User u WHERE u.mobileUserInfo.wifiMacAddress = ?1"),
		@NamedQuery(name = "userByBluetoothMacAddress", query = "SELECT u FROM User u WHERE u.mobileUserInfo.bluetoothMacAddress = ?1"),
		@NamedQuery(name = "userByPhoneNumber", query = "SELECT u FROM User u WHERE u.mobileUserInfo.phoneNumber = ?1"),
		@NamedQuery(name = "userByAuthorization", query = "SELECT u FROM User u WHERE u.authorizationInfo.username=?1 and u.authorizationInfo.password=?2"),
		@NamedQuery(name = "userBySessionData", query="SELECT u from User u WHERE u.authorizationInfo.sessionToken = ?1 and u.authorizationInfo.sessionHash = ?2"),
		@NamedQuery(name = "allUsers", query = "SELECT u FROM User u"),
		@NamedQuery(name = "usersByName", query ="SELECT u FROM User u WHERE u.personalUserInfo.firstName like :name"),
		@NamedQuery(name = "userByUserName", query ="SELECT u FROM User u WHERE u.authorizationInfo.username like :username"),
		@NamedQuery(name = "usersWithExpiredTicket", query="SELECT u from User u WHERE u.activeTicket.timeValidTo < ?1"),
		@NamedQuery(name = "usersWithStandardRouteSections", query="SELECT distinct u from User u join u.transportStandardRouteSections srs")
})
public class User implements Comparable<User> {

	@Id
	@GeneratedValue
	private Integer id;

	/**
	 * Personal user info.
	 */
	@Embedded
	private PersonalUserInfo personalUserInfo;
	/**
	 * Mobile user info.
	 */
	@Embedded
	private MobileUserInfo mobileUserInfo;
	/**
	 * Credit card user info.
	 */
	@Embedded
	private CreditCardUserInfo creditCardUserInfo;
	/**
	 * User options.
	 */
	@Embedded
	private UserOptions userOptions;

	@Embedded
	private AuthorizationInfo authorizationInfo;

	/**
	 * User roles.
	 */
	@OneToMany(mappedBy = "user")
	private Set<UserInRole> usersInRole;

	/**
	 * User used and unused tickets.
	 */
	@OneToMany(mappedBy = "user")
	private Set<Ticket> tickets;
	/**
	 * Activated ticket.
	 */
	@OneToOne(optional=true)
	private Ticket activeTicket;

	/**
	 * All user payments.
	 */
	@OneToMany(mappedBy = "user")
	private Set<Payment> payments;

	@OneToMany(mappedBy = "user",cascade=CascadeType.ALL)
	private Set<TransportRoute> transportRoutes;

	@OneToMany(mappedBy = "user")
	private Set<TransportStandardRouteSection> transportStandardRouteSections;

	@Override
	public String toString() {
		return getPersonalUserInfo().getFirstName() + " "
				+ getPersonalUserInfo().getLastName();
	}

	@Override
	public int hashCode() {
		
		PersonalUserInfo personal = getPersonalUserInfo();
		MobileUserInfo mobile = getMobileUserInfo();
		
		String value = personal.getFirstName()+personal.getLastName()+mobile.getPhoneNumber()+ApplicationSettings.HASH_SALT;
		
		final int prime = 31;
		int result = 1;
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	public boolean isAdmin() {

		for (UserInRole uir : getUsersInRole()) {
			if (uir.getRole().isAdminRole()) {
				return true;
			}
		}
		return false;
	}

	public boolean isUser() {
		for (UserInRole uir : getUsersInRole()) {
			if (uir.getRole().isUserRole()) {
				return true;
			}
		}
		return false;
	}

	public Set<Role> getRoles() {
		Set<Role> roles = new TreeSet<Role>();
		
		for (UserInRole userInRole : usersInRole) {
			roles.add(userInRole.getRole());
		}
		
		return roles;
	}
	
	public void refreshSessionTokens(){
		Random rand = new Random();
		AuthorizationInfo authInfo = getAuthorizationInfo();
		authInfo.setSessionToken(rand.nextLong());
		authInfo.setSessionHash(hashCode());
	}
	
	public void clearSessionTokens(){
		AuthorizationInfo authInfo = getAuthorizationInfo();
		authInfo.setSessionToken(null);
		authInfo.setSessionHash(null);
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public PersonalUserInfo getPersonalUserInfo() {
		return personalUserInfo;
	}

	public void setPersonalUserInfo(PersonalUserInfo personalUserInfo) {
		this.personalUserInfo = personalUserInfo;
	}

	public MobileUserInfo getMobileUserInfo() {
		return mobileUserInfo;
	}

	public void setMobileUserInfo(MobileUserInfo mobileUserInfo) {
		this.mobileUserInfo = mobileUserInfo;
	}

	public CreditCardUserInfo getCreditCardUserInfo() {
		return creditCardUserInfo;
	}

	public void setCreditCardUserInfo(CreditCardUserInfo creditCardUserInfo) {
		this.creditCardUserInfo = creditCardUserInfo;
	}

	public UserOptions getUserOptions() {
		return userOptions;
	}

	public void setUserOptions(UserOptions userOptions) {
		this.userOptions = userOptions;
	}

	public AuthorizationInfo getAuthorizationInfo() {
		return authorizationInfo;
	}

	public void setAuthorizationInfo(AuthorizationInfo authorizationInfo) {
		this.authorizationInfo = authorizationInfo;
	}

	public Set<UserInRole> getUsersInRole() {
		return usersInRole;
	}

	public void setUsersInRole(Set<UserInRole> usersInRole) {
		this.usersInRole = usersInRole;
	}

	public Set<Ticket> getTickets() {
		return tickets;
	}

	public void setTickets(Set<Ticket> tickets) {
		this.tickets = tickets;
	}

	public Ticket getActiveTicket() {
		return activeTicket;
	}

	public void setActiveTicket(Ticket activeTicket) {
		this.activeTicket = activeTicket;
	}

	public Set<Payment> getPayments() {
		return payments;
	}

	public void setPayments(Set<Payment> payments) {
		this.payments = payments;
	}

	public Set<TransportRoute> getTransportRoutes() {
		return transportRoutes;
	}

	public void setTransportRoutes(Set<TransportRoute> transportRoutes) {
		this.transportRoutes = transportRoutes;
	}
	
	public void addTransportRoute(TransportRoute transportRoute){
		
		if(transportRoutes != null){
			transportRoutes.add(transportRoute);
		}else{
			transportRoutes = new HashSet<TransportRoute>();
			transportRoutes.add(transportRoute);
		}
		
	}

	public Boolean hasActiveRoute() {
		for (TransportRoute route : transportRoutes) {
			if (route.getActive()) {
				return true;
			}
		}
		return false;
	}
	
	public TransportRoute getActiveRoute() throws NoActiveRoutesException{
		
		for(TransportRoute route : transportRoutes){
			if(route.getActive()){
				return route;
			}
		}
		throw new NoActiveRoutesException("Active route section has to be closed, but user has no active route");
		
	}

	@Override
	public int compareTo(User o) {
		return this.getId().compareTo(o.getId());
	}

	public Set<TransportStandardRouteSection> getTransportStandardRouteSections() {
		return transportStandardRouteSections;
	}

	public void setTransportStandardRouteSections(Set<TransportStandardRouteSection> transportStandardRouteSections) {
		this.transportStandardRouteSections = transportStandardRouteSections;
	}
}
