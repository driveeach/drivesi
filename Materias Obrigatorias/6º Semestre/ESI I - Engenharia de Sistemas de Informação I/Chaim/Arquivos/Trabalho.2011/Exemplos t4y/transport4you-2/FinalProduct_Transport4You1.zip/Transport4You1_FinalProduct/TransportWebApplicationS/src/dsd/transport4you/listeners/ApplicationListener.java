package dsd.transport4you.listeners;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import dsd.transport4you.dao.factories.WebApplicationDAOFactory;
import dsd.transport4you.dao.interfaces.IWebApplicationDAO;
import dsd.transport4you.settings.Constants;


public class ApplicationListener implements ServletContextListener {

    private static IWebApplicationDAO webDAO;

    @Override
    public void contextInitialized(ServletContextEvent event) {
    	ServletContext servletContext = event.getServletContext();
        webDAO = WebApplicationDAOFactory.createIWebApplicationDao();
        servletContext.setAttribute(Constants.WEB_DAO, webDAO);
    }

    @Override
    public void contextDestroyed(ServletContextEvent event) {
    }

    /**
     * Returns the current Config instance from the application scope.
     * @param servletContext The application scope to return current Config instance for.
     * @return The current Config instance from the application scope.
     */
    public static ApplicationListener getInstance(ServletContext servletContext) {
        return (ApplicationListener) servletContext.getAttribute(Constants.WEB_DAO);
    }

    /**
     * Returns the DAO Factory associated with this Config.
     * @return The DAO Factory associated with this Config
     */
    public static IWebApplicationDAO getDao() {
        return webDAO;
    }

}