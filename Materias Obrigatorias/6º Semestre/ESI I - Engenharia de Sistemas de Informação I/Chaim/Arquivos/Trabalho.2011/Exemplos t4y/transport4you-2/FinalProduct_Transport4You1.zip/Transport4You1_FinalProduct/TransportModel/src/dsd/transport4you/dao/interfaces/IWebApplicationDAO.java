package dsd.transport4you.dao.interfaces;

import java.util.Collection;

import dsd.transport4you.model.network.TransportLayer;
import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.news.News;
import dsd.transport4you.model.user.User;


/**
 * Interface contains all required methods for implementation of Transport Web
 * application. Interface connects persistence layer and web application.
 * 
 * @author Dajan, Toni
 * 
 */
public interface IWebApplicationDAO extends IGeneralDAO {

	// PLEASE ADD ALL NEEDED METHODS FOR WEB APPLICATION IMPLEMENTATION.
	
	public User getUserByAuthorization(String userName, String password);

	public User getUserByUserName(String userName);

	public TransportLine getTransportLineByName(String string);
	public TransportLine getTransportLineById(Integer id);
	public Collection<TransportLine> getAllTransportLines();
	public TransportLineStation getTransportLineStationById(Integer id);
	
	public Collection<News> getAllNews();
	public News getNewsById(Integer id);

	public User getUserBySessionData(Long sessionToken, Integer sessionHash);

	public Collection<TransportLayer> getAllTranportLayers();	
}
