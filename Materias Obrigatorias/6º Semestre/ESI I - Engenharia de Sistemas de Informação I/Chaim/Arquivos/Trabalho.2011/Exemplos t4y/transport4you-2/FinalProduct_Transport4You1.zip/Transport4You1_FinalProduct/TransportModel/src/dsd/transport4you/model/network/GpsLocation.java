/**
 * 
 */
package dsd.transport4you.model.network;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * A single GPS location.
 * Class is a value object.
 * @author toni, dajan
 */
@Embeddable
public class GpsLocation {
	
	/**
	 * Latitude (vertical) degrees.
	 */
	@Column(name="latitude",length=50,unique=false,nullable=false)
	private double latitude;
	/**
	 * Longitude (horizontal) degrees.
	 */
	@Column(name="longitude",length=50,unique=false,nullable=false)
	private double longitude;
	
	public GpsLocation() {
		// TODO Auto-generated constructor stub
	}
	
	public GpsLocation(double latitude, double longitude) {
		setLatitude(latitude);
		setLongitude(longitude);
	}

	@Override
	public String toString() {
		return "("+getLatitude()+","+getLongitude()+")";
	}
	
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
}
