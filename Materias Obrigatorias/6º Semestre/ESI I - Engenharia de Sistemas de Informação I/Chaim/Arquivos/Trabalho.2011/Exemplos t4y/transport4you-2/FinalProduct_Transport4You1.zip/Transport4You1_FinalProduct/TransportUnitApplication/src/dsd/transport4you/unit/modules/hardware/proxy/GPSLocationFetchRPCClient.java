package dsd.transport4you.unit.modules.hardware.proxy;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import dsd.transport4you.commprot.rpc.RPCClient;
import dsd.transport4you.commprot.rpc.RPCException;
import dsd.transport4you.interfaces.model.GpsLocation;

public class GPSLocationFetchRPCClient extends RPCClient {

	public GPSLocationFetchRPCClient(String rpcServerIP, Integer rpcServerPort) {
		super(rpcServerIP, rpcServerPort, "/GPSLocatorWebProxy/Fetch", METHOD_HTTP_GET);
	}

	public GpsLocation getGPSLocationByIP(String ip) throws RPCException{
		parameters.put("ip", ip);
		String ret = execute();
		
		Matcher mat = Pattern.compile("^latitude:(.*),longitude:(.*)$").matcher(ret);
		if(mat.matches()){
			double latitude=Double.valueOf(mat.group(1));
			double longitude=Double.valueOf(mat.group(2));
			return new GpsLocation(latitude,longitude);
		}
		return null;
	}
	
	public static void main(String[] args) throws RPCException {
		GPSLocationFetchRPCClient client = new GPSLocationFetchRPCClient("127.0.0.1", 8080);
		GpsLocation location = client.getGPSLocationByIP("0:0:0:0:0:0:0:1");
		System.out.println(location);
	}
}
