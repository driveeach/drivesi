/**
 * 
 */
package dsd.transport4you.commprot.util.threads;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.settings.ITransportUnitUserData;
import dsd.transport4you.settings.ITransportUserDataHandlerFactory;


/**
 * @author toni
 *
 */
public class TransportUnitUserDataHandler extends TransportServerHandler{

	private static Log log = LogFactory.getLog(TransportUnitUserDataHandler.class);
	
	private ITransportUnitUserData task = null;
	private ITransportUserDataHandlerFactory handlerFactory=null;
	
	public TransportUnitUserDataHandler() {
		// TODO Auto-generated constructor stub
	}
	
	public TransportUnitUserDataHandler(ITransportUserDataHandlerFactory handlerFactory) {
		this.handlerFactory=handlerFactory;
	}
	
	public void setHandlerFactory(
			ITransportUserDataHandlerFactory handlerFactory) {
		this.handlerFactory = handlerFactory;
	}
	
	public void setTask(ITransportUnitUserData task){
		this.task = task;
	}
	
	private void releaseTask(){
		this.task = null;
	}
	@Override
	public Boolean hasTask(){
		return task != null;
	}
	
	@Override
	public void run() {
		
		while(true){
			
			try {
				Thread.sleep(1000);
				//TODO: to ApplicationSettings.java
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(hasTask()){
				log.info("assigning task to ITransportUserDataHandler");
				this.handlerFactory.createTransportUserDataHandler().handle(this.task);
				releaseTask();
			}
			
		}
	}

//	@Override
//	public Boolean hasTask() {
//		// TODO Auto-generated method stub
//		return null;
//	}
	
}
