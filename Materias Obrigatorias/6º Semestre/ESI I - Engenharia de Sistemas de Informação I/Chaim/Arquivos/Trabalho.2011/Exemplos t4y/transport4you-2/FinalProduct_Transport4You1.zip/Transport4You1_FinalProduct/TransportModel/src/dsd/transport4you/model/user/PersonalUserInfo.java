package dsd.transport4you.model.user;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;

/**
 * Class is a value object. Class contains personal user data.
 * 
 * @author toni, dajan
 * 
 */
@Embeddable
public class PersonalUserInfo {

	/**
	 * First name.
	 */
	@Column(name="firstName",length=50,nullable=false)
	private String firstName;
	/**
	 * Middle name.
	 */
	@Column(name="middleName",length=50,nullable=true)
	private String middleName;
	/**
	 * Last name.
	 */
	@Column(name="lastName",length=50,nullable=false)
	private String lastName;

	/**
	 * Current address.
	 */
	@Embedded
	private Address address;
	/**
	 * Date of birth.
	 */
	@Column(name="dateOfBirth",length=50,nullable=false)
	private Date dateOfBirth;

	/**
	 * Perferred email address.
	 */
	@Column(name="email",length=50,nullable=false)
	private String email;

	
	public PersonalUserInfo() {
		// TODO Auto-generated constructor stub
	}
	
	public PersonalUserInfo(String firstName, String middleName,
			String lastName, Address address, Date dateOfBirth, String email) {
		super();
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.address = address;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
