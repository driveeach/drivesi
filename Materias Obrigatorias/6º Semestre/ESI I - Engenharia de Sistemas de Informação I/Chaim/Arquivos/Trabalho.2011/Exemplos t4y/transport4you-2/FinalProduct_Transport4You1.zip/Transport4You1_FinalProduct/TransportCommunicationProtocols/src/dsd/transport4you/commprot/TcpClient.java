/**
 * 
 */
package dsd.transport4you.commprot;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.commprot.util.CommunicationProtocolsService;
import dsd.transport4you.settings.ICommunicationProtocolClient;
import dsd.transport4you.settings.ITransportUnitUserData;

/**
 * Implementation of client for TCP protocol communication
 * 
 * @author dajan
 */
public class TcpClient implements ICommunicationProtocolClient{

	private static Log log = LogFactory.getLog(TcpClient.class);

	private ITransportUnitUserData userData;
	private Socket socket;
	private BufferedWriter tcpWriter;

	/**
	 * Client constructor. Initializes TCP communication protocol.
	 * 
	 * @param ip
	 * @param socketPortNumber
	 * @param userData
	 */
	public TcpClient(String ip, int socketPortNumber, ITransportUnitUserData userData) {
		this.userData = userData;
		try {
			this.socket = new Socket(ip, socketPortNumber);
		} catch (UnknownHostException e) {
			log.error("stacktrace starts here...");
			e.printStackTrace();
			log.error("stacktrace ends here...");
		} catch (IOException e) {
			log.error("stacktrace starts here...");
			e.printStackTrace();
			log.error("stacktrace ends here...");
		}
	}


	/* (non-Javadoc)
	 * @see dsd.transport4you.interfaces.ICommunicationProtocolClient#sendData()
	 */
	public Boolean sendData(){

		try {
			tcpWriter = new BufferedWriter(new OutputStreamWriter(
					socket.getOutputStream()));
			String userDataJSON = CommunicationProtocolsService
					.toJSON(userData);
			tcpWriter.write(userDataJSON);
			tcpWriter.flush();
			tcpWriter.close();
			return true;
			
		} catch (IOException e) {
			log.error("stacktrace starts here...");
			e.printStackTrace();
			log.error("stacktrace ends here...");
			return false;
		}
	}
}
