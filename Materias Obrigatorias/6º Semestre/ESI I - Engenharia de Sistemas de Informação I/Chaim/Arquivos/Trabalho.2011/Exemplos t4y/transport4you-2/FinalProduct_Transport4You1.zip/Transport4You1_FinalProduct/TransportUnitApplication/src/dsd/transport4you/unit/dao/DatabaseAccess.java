package dsd.transport4you.unit.dao;

import dsd.transport4you.unit.dao.interfaces.IOperations;

/**
 * Singleton pattern that gets an database implementation. For now it works with memory
 * implementation.
 * @author Dino
 *
 */
public class DatabaseAccess {

	private static DatabaseAccess instance;
    private static IOperations operations;

    private DatabaseAccess() {
        operations = new DatabaseMemoryImpl();
    }

    public static IOperations getInstance() {
        if(instance == null) {
            instance = new DatabaseAccess();
        }
        
       return operations;
    }
}
