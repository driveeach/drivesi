package dsd.transport4you.interfaces.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import dsd.transport4you.settings.ITransportUnitUserData;

public class UserData implements ITransportUnitUserData {

	private TransportUnitLineData transportUnitLineData;
	private Date timeStamp;
	private String transportUnitUniqueIdentifier;
	private GpsLocation gpsLocation;
	private List<MacAddress> missingUsers;
	private List<MacAddress> newUsers;
	
	public UserData(){
		missingUsers = new ArrayList<MacAddress>();
		newUsers = new ArrayList<MacAddress>();
	}
	
	public void setNewUsers(List<MacAddress> users) {
		newUsers = users;
	}

	
	public void setMissingUsers(List<MacAddress> users) {
		missingUsers = users;
	}

	
	public void setGpsLocation(GpsLocation location) {
		gpsLocation = location;
	}

	
	public void setTimeStamp(Date date) {
		timeStamp = date;
		
	}
	
	
	public void setTransportLine(TransportUnitLineData line) {
		transportUnitLineData = line;
	}

	
	public void setTransportUnitUniqueIdentifier(String identifier) {
		transportUnitUniqueIdentifier = identifier;
	}
	
	@Override
	public List<MacAddress> getNewUsers() {
		return newUsers;
	}

	@Override
	public List<MacAddress> getMissingUsers() {
		return missingUsers;
	}

	@Override
	public GpsLocation getGpsLocation() {
		return gpsLocation;
	}

	@Override
	public Date getTimeStamp() {
		return timeStamp;
	}

	@Override
	public TransportUnitLineData getTransportLine() {
		return transportUnitLineData;
	}

	@Override
	public String getTransportUnitUniqueIdentifier() {
		return transportUnitUniqueIdentifier;
	}
	
	@Override
	public String toString() {
		return "Line: "+transportUnitLineData+", Unit: "+transportUnitUniqueIdentifier+", New passengers: "+newUsers.size()+", Missing passengers: "+missingUsers.size();
	}
}
