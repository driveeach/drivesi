package dsd.transport4you.actions.admin.routes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opensymphony.xwork2.Preparable;

import dsd.transport4you.actions.ExtendedActionSupport;
import dsd.transport4you.actions.interfaces.IAdminAction;
import dsd.transport4you.bean.TransportLayerBean;
import dsd.transport4you.model.network.TransportLayer;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.network.changes.TransportRouteInterruption;
import dsd.transport4you.model.network.comparators.TransportLineComparator;

public class ConfigRouteInterruptionAction extends ExtendedActionSupport implements Preparable,IAdminAction {

	private static Log log = LogFactory.getLog(ConfigRouteInterruptionAction.class);
	
	private static final long serialVersionUID = 4866840012493320854L;

	public final static String ADD_ROUTE_INTERRUPTION_ATTEMPT = "addRouteInterruptionAttempt";
	
	private Integer transportLineId;
	private TransportLineStation fromStation;
	private TransportLineStation toStation;
	private Date fromDate;
	private Date toDate;
	
	private List<TransportLayer> transportLayers;
	private List<TransportLayerBean> transportLayersBean;
	
	private Integer fromStationId;
	private Integer toStationId;
	

	private String message;
		
	@Override
	public String execute() throws Exception {	
		if (ADD_ROUTE_INTERRUPTION_ATTEMPT.equals(getAttempt())) {
			log.info("Adding new route interruption...");

			fromStation = webDAO.getTransportLineStationById(fromStationId);
			toStation = webDAO.getTransportLineStationById(toStationId);
			
			System.out.println("from "+fromDate);
			
			TransportRouteInterruption interruption = new TransportRouteInterruption();
			interruption.setFromStation(fromStation);
			interruption.setToStation(toStation);
			interruption.setFromTime(fromDate);
			interruption.setToTime(toDate);
			
			webDAO.getEntityManager().getTransaction().begin();
			webDAO.save(interruption);
			webDAO.getEntityManager().getTransaction().commit();
			
			setMessage(getText("messages.routeInterruptionSuccess"));

			log.info("Adding new route inrerruption...");
			
			return SUCCESS;
			
		} else {
			return INPUT;
		}
	}
	
	@Override
	public void validate() {
		if(ADD_ROUTE_INTERRUPTION_ATTEMPT.equals(getAttempt())){	
			validateFromDate();
		}
	}
	
	private void validateFromDate() {
		if(fromDate == null){
			addFieldError("fromDate",getText("label.interruptionStart")+" "+getText("errors.required"));
		}			
	}

	public boolean isAttemptAddRouteInterruption(){
		if(ADD_ROUTE_INTERRUPTION_ATTEMPT.equals(getAttempt())){
			return true;
		} else {
			return false;
		}		
	}
	
	public Integer getFromStationId() {
		return fromStationId;
	}

	public void setFromStationId(Integer fromStationId) {
		this.fromStationId = fromStationId;
	}

	public Integer getToStationId() {
		return toStationId;
	}

	public void setToStationId(Integer toStationId) {
		this.toStationId = toStationId;
	}
	
	public void setTransportLayers(List<TransportLayer> transportLayers) {
		this.transportLayers = transportLayers;
	}

	public List<TransportLayer> getTransportLayers() {
		return transportLayers;
	}
	
	public Integer getTransportLineId() {
		return transportLineId;
	}

	public void setTransportLineId(Integer transportLineId) {
		this.transportLineId = transportLineId;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	
	public void setTransportLayersBean(List<TransportLayerBean> transportLayersBean) {
		this.transportLayersBean = transportLayersBean;
	}

	public List<TransportLayerBean> getTransportLayersBean() {
		return transportLayersBean;
	}

	@Override
	public void prepare() throws Exception {
		
		transportLayersBean = new ArrayList<TransportLayerBean>();
		
		setTransportLayers(new ArrayList<TransportLayer>(webDAO.getAllTranportLayers()));
		for (TransportLayer layer : transportLayers) {			
			transportLayersBean.add(new TransportLayerBean(layer.getTransportLines(), layer.getType()));
		}
			
		for (TransportLayerBean layerBean : transportLayersBean) {
			Collections.sort(layerBean.getTransportLines(), new TransportLineComparator());
		}
	}	
}
