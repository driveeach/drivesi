package dsd.transport4you.actions;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


public class AjaxActionSupport extends ExtendedActionSupport{

	private static final long serialVersionUID = 1L;
	private static Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss Z").create();
	
	private InputStream result;
	
	public void setResult(InputStream result) {
		this.result = result;
	}

	public InputStream getResult() {
		return result;
	}
	
	protected void setResultString(String str){
		this.result = new ByteArrayInputStream(str.getBytes());
	}
	
	protected void setResultJSON(Object obj){
		setResultString(gson.toJson(obj));
	}
}
