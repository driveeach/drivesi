package dsd.transport4you.main.thread;

import java.util.TimerTask;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.model.route.TransportRoute;
import dsd.transport4you.settings.ApplicationSettings;

public class RouteInactivationTask extends TimerTask{

	public static final Log log = LogFactory.getLog(RouteInactivationTask.class);
	
	public RouteInactivationTask() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() {
		
		log.info("started task");
		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		
		dao.getEntityManager().getTransaction().begin();
		
		for(TransportRoute route : dao.getTransportRoutesToInactivate(ApplicationSettings.TRANSPORT_ROUTE_INACTIVATION_TIME)){
			route.setActive(false);
			dao.update(route);
			log.info("route #"+route.getId()+" inactivated");
		}
		
		dao.getEntityManager().getTransaction().commit();
		
		dao.close();
		log.info("finished task");
	}

}
