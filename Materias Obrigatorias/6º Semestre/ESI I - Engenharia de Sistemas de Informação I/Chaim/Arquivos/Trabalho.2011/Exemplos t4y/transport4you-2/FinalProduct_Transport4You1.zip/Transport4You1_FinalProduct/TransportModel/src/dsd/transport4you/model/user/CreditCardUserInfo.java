/**
 * 
 */
package dsd.transport4you.model.user;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Class is a value object. Class contains user data.
 * 
 * @author toni, dajan
 *
 */
@Embeddable
public class CreditCardUserInfo {

	@Column(name="creditCardLastName",length=50,unique=false,nullable=false)
	private String lastName;
	
	@Column(name="creditCardFirstName",length=50,unique=false,nullable=false)
	private String firstName;
	
	@Column(name="creditCardAddress1",length=50,unique=false,nullable=false)
	private String address1;
	
	@Column(name="creditCardAddress2",length=50,unique=false,nullable=true)
	private String address2;
	
	@Column(name="creditCardCity",length=50,unique=false,nullable=false)
	private String city;
	
	@Column(name="creditCardState",length=50,unique=false,nullable=false)
	private String state;
	
	@Column(name="creditCardZipCode",length=50,unique=false,nullable=false)
	private String zipCode;
	
	@Column(name="creditCardType",length=50,unique=false,nullable=false)
	private String type;
	
	@Column(name="creditCardNumber",length=50,unique=false,nullable=false)
	private String number;
	
	@Column(name="creditCardCVV2",length=50,unique=false,nullable=false)
	private String CVV2;
	
	@Column(name="creditCardExpirationMonth",length=50,unique=false,nullable=false)
	private Integer expirationMonth;
	
	@Column(name="creditCardExpirationYear",length=50,unique=false,nullable=false)
	private Integer expirationYear;
	
	public CreditCardUserInfo() {
		// TODO Auto-generated constructor stub
	}

	public String getLastName() {
		return lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getAddress1() {
		return address1;
	}

	public String getAddress2() {
		return address2;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public String getType() {
		return type;
	}

	public String getNumber() {
		return number;
	}

	public String getCVV2() {
		return CVV2;
	}

	public Integer getExpirationMonth() {
		return expirationMonth;
	}

	public Integer getExpirationYear() {
		return expirationYear;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public void setCVV2(String cVV2) {
		CVV2 = cVV2;
	}

	public void setExpirationMonth(Integer expirationMonth) {
		this.expirationMonth = expirationMonth;
	}

	public void setExpirationYear(Integer expirationYear) {
		this.expirationYear = expirationYear;
	}
}
