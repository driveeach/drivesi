/**
 * 
 */
package dsd.transport4you.commprot.util.exceptions;

/**
 * Root exception for synchronized queue.
 * 
 * @author dajan
 *
 */
public class QueueSynchronizedException extends TransportCommunicationProtocolsException{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public QueueSynchronizedException(String message){
		super(message);
	}

}
