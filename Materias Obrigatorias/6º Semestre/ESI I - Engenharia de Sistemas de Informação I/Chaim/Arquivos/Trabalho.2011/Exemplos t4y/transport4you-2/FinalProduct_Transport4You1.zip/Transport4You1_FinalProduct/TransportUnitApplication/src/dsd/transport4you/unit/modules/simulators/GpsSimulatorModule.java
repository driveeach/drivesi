/**
 * 
 */
package dsd.transport4you.unit.modules.simulators;

import javax.swing.plaf.SliderUI;

import dsd.transport4you.interfaces.model.GpsLocation;
import dsd.transport4you.unit.modules.GpsModule;

/**
 * Class with GPS methods. Can get current GPS location.
 * 
 * @author Dino
 *
 */
public class GpsSimulatorModule extends GpsModule{


	private GpsLocation currentLocation;

	public GpsSimulatorModule() {
		this.currentLocation = new GpsLocation();
	}

	/**
	 * Gets the current GPS location of TU.
	 * @return Current GPS location of TU
	 */
	public GpsLocation getCurrentLocation() {
		currentLocation.setLatitude(45.7998144781);
		currentLocation.setLongitude(15.9711545211);
		
		return currentLocation;
	}

	/**
	 * Sets the current GPS location of TU
	 * @param currentLocation Current GPS location of TU
	 */
	public void setCurrentLocation(GpsLocation currentLocation) {
		this.currentLocation = currentLocation;
	}
}
