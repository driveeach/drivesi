package dsd.transport4you.main.notification;

import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.commprot.sms.SMSMessage;

public class SMSUserNotificationBuffer {

	private static SMSUserNotificationBuffer instance;
	
	private Set<SMSMessage> timedMessageQueue = new HashSet<SMSMessage>();
	
	private static Log log = LogFactory.getLog(SMSUserNotificationBuffer.class);
	
	private SMSUserNotificationBuffer() {
		// TODO Auto-generated constructor stub
	}
	
	public static synchronized SMSUserNotificationBuffer getInstance() {
		if(instance==null){
			instance=new SMSUserNotificationBuffer();
		}
		return instance;
	}
	
	public synchronized void add(SMSMessage msg){
		timedMessageQueue.add(msg);
		log.info("added "+msg);
	}
	
	public synchronized List<SMSMessage> popToSend(Date time){
		
		List<SMSMessage> toSend = new LinkedList<SMSMessage>();
		
		for(SMSMessage msg : timedMessageQueue){
			if(msg.getTime().before(time)){
				toSend.add(msg);
			}
		}
		log.info("removed "+toSend);
		timedMessageQueue.removeAll(toSend);
		return toSend;
	}

	public synchronized int size() {
		return timedMessageQueue.size();
	}
}
