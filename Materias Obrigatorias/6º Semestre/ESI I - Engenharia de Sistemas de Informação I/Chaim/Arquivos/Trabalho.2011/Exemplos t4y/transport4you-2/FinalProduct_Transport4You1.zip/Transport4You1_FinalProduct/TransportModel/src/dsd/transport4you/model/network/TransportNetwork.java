package dsd.transport4you.model.network;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import dsd.transport4you.util.exceptions.TransportModelValidationException;

@Entity
@Table(name="TRANSPORT_NETWORK")
public class TransportNetwork {

	@Id
	@GeneratedValue
	private Integer id;
	
	/**
	 * Transport network name.
	 */
	@Column(name="name",length=50,unique=true,nullable=false)
	private String name;
	
	/**
	 * Transport lines that make up this network.
	 */
	@OneToMany(mappedBy="transportNetwork",cascade=CascadeType.PERSIST)
	private Set<TransportLayer> transportLayers;

	public TransportNetwork(String name) {
		setName(name);
	}

	public TransportNetwork(String name,Set<TransportLayer> transportLayers) {
		setName(name);
		setTransportLayers(transportLayers);
	}
	
	public TransportNetwork() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Transport network "+getName();
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Set<TransportLayer> getTransportLayers() {
		return transportLayers;
	}

	public void setTransportLayers(Set<TransportLayer> transportLayers) {
		this.transportLayers = transportLayers;
	}

	public void validate() throws TransportModelValidationException{
		for(TransportLayer layer : getTransportLayers()){
			layer.validate();
		}
	}
}
