package dsd.transport4you.model.network.comparators;

import java.util.Comparator;

import dsd.transport4you.model.network.TransportLine;

/**
 * Sorts
 * @author Dino4674
 *
 */
public class TransportLineComparator implements Comparator<TransportLine> {

	@Override
	public int compare(TransportLine o1, TransportLine o2) {

		boolean o1IsInt = true;
		boolean o2IsInt = true;
		
		try {
			Integer.parseInt(o1.getName());
		} catch (Exception e) {
			o1IsInt = false;
		}
		
		try {
			Integer.parseInt(o1.getName());
		} catch (Exception e) {
			o2IsInt = false;
		}
		
		if(o1IsInt && o2IsInt){
					
			return Integer.valueOf(o1.getName()).compareTo(Integer.valueOf(o2.getName()));
			
		} else if (!o1IsInt && !o2IsInt) {
			return o1.getName().compareTo(o2.getName());
		} else {
			if(o1IsInt){
				return 1;
			} else {
				return -1;
			}
		}
	}
}
