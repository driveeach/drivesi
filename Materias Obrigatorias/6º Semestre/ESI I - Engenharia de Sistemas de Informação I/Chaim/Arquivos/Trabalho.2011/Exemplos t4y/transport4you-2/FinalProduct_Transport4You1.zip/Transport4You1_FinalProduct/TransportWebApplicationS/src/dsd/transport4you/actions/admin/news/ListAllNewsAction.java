package dsd.transport4you.actions.admin.news;

import java.util.ArrayList;
import java.util.List;

import dsd.transport4you.actions.ExtendedActionSupport;
import dsd.transport4you.actions.interfaces.IAdminAction;
import dsd.transport4you.model.news.News;

public class ListAllNewsAction extends ExtendedActionSupport implements IAdminAction {

	private static final long serialVersionUID = 5096842240482350677L;

	private List<News> allNews;

	@Override
	public String execute() throws Exception {
		allNews = new ArrayList<News>(webDAO.getAllNews());
		return SUCCESS;
	}

	public List<News> getAllNews() {
		return allNews;
	}

	public void setAllNews(List<News> allNews) {
		this.allNews = allNews;
	}
}
