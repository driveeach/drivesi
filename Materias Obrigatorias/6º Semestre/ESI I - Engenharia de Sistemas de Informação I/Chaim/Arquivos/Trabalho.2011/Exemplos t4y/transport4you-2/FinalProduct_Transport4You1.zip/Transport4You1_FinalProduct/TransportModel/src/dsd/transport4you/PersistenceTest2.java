package dsd.transport4you;

import java.sql.Time;
import java.util.Date;
import java.util.LinkedList;

import javax.persistence.EntityManager;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.factories.WebApplicationDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.dao.interfaces.IWebApplicationDAO;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.network.changes.TransportRouteInterruption;
import dsd.transport4you.model.route.standard.TransportStandardRouteSection;

public class PersistenceTest2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		//ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		IWebApplicationDAO webdao = WebApplicationDAOFactory.createIWebApplicationDao();
		EntityManager em = webdao.getEntityManager();
		em.getTransaction().begin();
		System.out.println(webdao.getTransportLineStationById(Integer.parseInt("6")));
		TransportRouteInterruption tri=new TransportRouteInterruption();
		tri.setFromStation(webdao.getTransportLineStationById(Integer.parseInt("6")));
		tri.setToStation(webdao.getTransportLineStationById(Integer.parseInt("8")));
//		em.getTransaction().begin();
//
//		Calendar cal = new GregorianCalendar(1988, 6, 10);
//
//		User user = UserFactory.createUser("John", null, "Doe", "jd@gmail.com","user","pass",
//					"Via Fora", "10", "Zagreb", "10000", "Croatia", cal.getTime(),
//					"11002200", "11:22:33:ee:dd:44", "11:22:33:ee:dd:45", null);
//
//		
//		System.out.println(user);
//		
		webdao.save(tri);
		

		// em.createNamedQuery("userById").setParameter(1, 1).getSingleResult();
//		System.out.println(dao.getUserByBluetoothMacAddress("11:22:33:ee:dd:44"));
//		System.out.println(dao.getUserByWiFiMacAddress("11:22:33:ee:dd:45"));
//		
//		System.out.println(dao.getNearestTransportLineStation(2223.2323001, 423.2324001, "2", TransportLineDirection.FORWARD));

//		System.out.println(dao.getTransportRoutesToInactivate(ApplicationSettings.TRANSPORT_ROUTE_INACTIVATION_TIME));
		
		//TransportStandardRouteSection rs = new TransportStandardRouteSection();
		
		//rs.setUser(dao.getUserById(1));
		//rs.setFromStation(new LinkedList<TransportLineStation>(dao.getTransportLineByName("11").getTransportLineStationsForwardTrip()).getFirst());
		//rs.setToStation(new LinkedList<TransportLineStation>(dao.getTransportLineByName("11").getTransportLineStationsForwardTrip()).getLast());
		
		//rs.setFromStationDayTime(new Time(new Date().getTime()));
		//rs.setToStationDayTime(new Time(new Date().getTime()));
		
		//System.out.println(dao.getTransportLineByName("11").getTransportLineStationsForwardTrip());
		//dao.save(rs);
		em.getTransaction().commit();
		
		//webdao.close();
	}

}
