package dsd.transport4you.unit.exceptions;

/**
 * 
 * @author Dino
 *
 */
public class NotEnoughLocationScansException extends TransportUnitException{

	private static final long serialVersionUID = -3489678118149673865L;

	public NotEnoughLocationScansException(String path) {
		super(path);
	}
		
	public NotEnoughLocationScansException(Exception e) {
		super(e);
	}
}
