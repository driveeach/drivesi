/**
 * 
 */
package dsd.transport4you.commprot.util.threads;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.commprot.util.QueueSynchronized;
import dsd.transport4you.commprot.util.exceptions.TransportCommunicationProtocolsException;
import dsd.transport4you.settings.ITransportUnitUserData;

/**
 * @author dajan
 * 
 */
public class TasksCoordinator implements Runnable {

	private QueueSynchronized<ITransportUnitUserData> tasksQueue;
	private QueueSynchronized<TransportServerHandler> tuaHandlers;
	
	private static Log log = LogFactory.getLog(TasksCoordinator.class);

	public TasksCoordinator(
			QueueSynchronized<ITransportUnitUserData> tasksQueue,
			QueueSynchronized<TransportServerHandler> tuaHandlers) {

		this.tasksQueue = tasksQueue;
		this.tuaHandlers = tuaHandlers;

	}

	@Override
	public void run() {

		while (true) {
			
			try {
				Thread.sleep(500);
				//TODO: to ApplicationSettings.java
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			while(!tasksQueue.isEmpty()) {
				for (TransportServerHandler tuaHandler : tuaHandlers) {
					if (!tuaHandler.hasTask()) {
						//tuaHandler.run();
						try {
							
							ITransportUnitUserData task = tasksQueue.getNextTask();
							tuaHandler.setTask(task);
							log.info("assigning task to handler");

						} catch (TransportCommunicationProtocolsException e) {
							
						}
					}
				}
			}
		}

	}

}
