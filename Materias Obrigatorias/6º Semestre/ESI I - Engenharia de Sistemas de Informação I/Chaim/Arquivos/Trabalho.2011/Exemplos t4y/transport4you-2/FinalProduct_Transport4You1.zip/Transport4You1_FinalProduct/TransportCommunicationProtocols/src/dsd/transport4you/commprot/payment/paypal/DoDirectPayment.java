/*
 * Copyright 2005, 2008 PayPal, Inc. All Rights Reserved.
 *
 * DoDirectPayment SOAP example; last modified 08MAY23. 
 *
 * Process a credit card payment.  
 */
package dsd.transport4you.commprot.payment.paypal;

import com.paypal.sdk.profiles.APIProfile;
import com.paypal.sdk.profiles.ProfileFactory;
import com.paypal.sdk.services.CallerServices;
import com.paypal.soap.api.BasicAmountType;
import com.paypal.soap.api.CountryCodeType;
import com.paypal.soap.api.CreditCardDetailsType;
import com.paypal.soap.api.CreditCardTypeType;
import com.paypal.soap.api.CurrencyCodeType;
import com.paypal.soap.api.DoDirectPaymentRequestDetailsType;
import com.paypal.soap.api.DoDirectPaymentRequestType;
import com.paypal.soap.api.DoDirectPaymentResponseType;
import com.paypal.soap.api.PayerInfoType;
import com.paypal.soap.api.PaymentActionCodeType;
import com.paypal.soap.api.PaymentDetailsType;
import com.paypal.soap.api.PersonNameType;

/**
 * PayPal Java SDK sample code
 */
public class DoDirectPayment 
{
	
	public String DoDirectPaymentCode(String paymentAmount, String buyerLastName, String buyerFirstName, 
			String buyerAddress1, String buyerAddress2, String buyerCity, String buyerState, 
			String buyerZipCode, String creditCardType, String creditCardNumber, 
			String CVV2, int expMonth, int expYear, PaymentActionCodeType paymentAction)

	{
		String responseValue = null;
		try
		{
			
			CallerServices caller = new CallerServices();
			APIProfile profile = ProfileFactory.createSignatureAPIProfile();
			/*
			 WARNING: Do not embed plaintext credentials in your application code.
			 Doing so is insecure and against best practices.
			 Your API credentials must be handled securely. Please consider
			 encrypting them for use in any production environment, and ensure
			 that only authorized individuals may view or modify them.
			 */

		// Set up your API credentials, PayPal end point, and API version.
			profile.setAPIUsername("dajann_1290781159_biz_api1.gmail.com");
			profile.setAPIPassword("1290781171");
			profile.setSignature("AuLccH7Xe3EVRbT0XsDtCWFvZ2hgAJ6Tozrm2gsd62KRLgedeVhaFwfs");
			profile.setEnvironment("sandbox");
			caller.setAPIProfile(profile);
			
			DoDirectPaymentRequestType pprequest = new DoDirectPaymentRequestType();
			pprequest.setVersion("51.0");

		// Add request-specific fields to the request.
			DoDirectPaymentRequestDetailsType details = new DoDirectPaymentRequestDetailsType();
			PaymentDetailsType paymentDetails = new PaymentDetailsType();
			BasicAmountType amount = new BasicAmountType();
			amount.set_value(paymentAmount);
			amount.setCurrencyID(CurrencyCodeType.USD);
			paymentDetails.setOrderTotal(amount);	
					
			com.paypal.soap.api.AddressType shipTo = new com.paypal.soap.api.AddressType();
			shipTo.setName(buyerFirstName + " " + buyerFirstName);
			shipTo.setStreet1(buyerAddress1);
			shipTo.setStreet2(buyerAddress2);
			shipTo.setCityName(buyerCity);
			shipTo.setStateOrProvince(buyerState);
			shipTo.setCountry(CountryCodeType.US);
			shipTo.setPostalCode(buyerZipCode);
			paymentDetails.setShipToAddress(shipTo);
			
			
			details.setPaymentDetails(paymentDetails);
		       
			CreditCardDetailsType cardDetails = new CreditCardDetailsType();
			cardDetails.setCreditCardType(CreditCardTypeType.fromString(creditCardType));
			cardDetails.setCreditCardNumber(creditCardNumber);
			cardDetails.setExpMonth(new Integer(expMonth));
			cardDetails.setExpYear(new Integer(expYear));
			cardDetails.setCVV2(CVV2);
			
			PayerInfoType payer = new PayerInfoType();
			PersonNameType name = new PersonNameType();
			name.setFirstName(buyerFirstName);
			name.setLastName(buyerLastName);
			payer.setPayerName(name);
			payer.setPayerCountry(CountryCodeType.US);
			payer.setAddress(shipTo);
		   
			cardDetails.setCardOwner(payer);
			details.setCreditCard(cardDetails);
			details.setIPAddress("10.244.43.106");
			
			details.setPaymentAction(paymentAction);
			pprequest.setDoDirectPaymentRequestDetails(details);

		// Execute the API operation and obtain the response.
			System.out.println(pprequest.toString());
			DoDirectPaymentResponseType ppresponse = (DoDirectPaymentResponseType) caller.call("DoDirectPayment", pprequest);
			responseValue = ppresponse.getAck().toString();
			System.out.println("TRANSACTION ID ..... "+ ppresponse.getTransactionID());
			System.out.println("Do Direct Payment is ends.......2");
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return responseValue;
	}

}