/**
 * 
 */
package dsd.transport4you.commprot.util.exceptions;

/**
 * Root exception for communication protocols.
 * 
 * @author dajan
 *
 */
public class TransportCommunicationProtocolsException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TransportCommunicationProtocolsException(String message){
		super(message);
	}
	
}
