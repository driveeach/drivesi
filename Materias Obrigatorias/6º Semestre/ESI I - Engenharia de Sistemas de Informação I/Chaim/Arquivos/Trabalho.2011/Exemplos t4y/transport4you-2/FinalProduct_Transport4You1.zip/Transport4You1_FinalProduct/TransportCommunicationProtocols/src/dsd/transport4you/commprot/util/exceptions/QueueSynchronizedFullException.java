/**
 * 
 */
package dsd.transport4you.commprot.util.exceptions;

/**
 * Queue full exception.
 * 
 * @author dajan
 *
 */
public class QueueSynchronizedFullException extends QueueSynchronizedException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public QueueSynchronizedFullException(String message) {
		super(message);
	}

}
