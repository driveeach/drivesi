package dsd.transport4you.main.handlers;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.main.notification.SMSUserNotifier;
import dsd.transport4you.main.notification.UserNotifier;
import dsd.transport4you.model.Ticket;
import dsd.transport4you.model.Ticket.TicketType;
import dsd.transport4you.model.user.User;
import dsd.transport4you.model.user.options.BillingMode;
import dsd.transport4you.settings.ApplicationSettings;
import dsd.transport4you.util.DateUtil;

public class BillingHandler {
	
	private static Log log = LogFactory.getLog(BillingHandler.class);
	
	private User user;
	private Date detectionTime;
	private ITransportModelDAO dao;
	
	private UserNotifier notifier = SMSUserNotifier.getInstance();
	
	public BillingHandler(User user, Date detectionTime, ITransportModelDAO dao) {
		this.user = user;
		this.detectionTime = detectionTime;
		this.dao = dao;
	}
	
	public boolean bill() {
		
		Date now = new Date();
		
		List<Ticket> allUncheckedTickets=null;
		Ticket ticketToUse = null;
		boolean paymentSucc = false;

		if (user.getUserOptions().getBillingMode().equals(BillingMode.PREPAID)) {
			
				allUncheckedTickets=dao.getUncheckedTickets(user.getId());
				
				if(allUncheckedTickets.size()>0){
					//returns smallest available unchecked ticket (sorted by ticket type)
					ticketToUse = allUncheckedTickets.get(0);
					ticketToUse.check(this.detectionTime);
					user.setActiveTicket(ticketToUse);
					allUncheckedTickets.remove(ticketToUse);
					paymentSucc = true;
					log.info("User " + user.getAuthorizationInfo().getUsername() + " payment succ: "+ paymentSucc + " for "+ticketToUse.getTicketType().name()+" ticket");
				
					notifier.notifyTicketCheck(user, ticketToUse.getTimeValidTo(), now);
					
					if(isLowTicketCount(allUncheckedTickets)){
						notifier.notifyLowPrepaidTicketWarning(user,allUncheckedTickets.size(),now);
					}
				}else{
					log.info("User "+user.getAuthorizationInfo().getUsername()+" no prepayed tickets left. Sending payment remainder notification");
					notifier.notifyTicketRemainder(user,DateUtil.add(Calendar.SECOND, ApplicationSettings.SMS_PAYMENT_REMAINDER_TIME, now));
				}
		}else if (user.getUserOptions().getBillingMode().equals(BillingMode.ON_DEMAND)) {
			// TODO: implement on demand payment
			log.info("User "+user.getAuthorizationInfo().getUsername()+" ondemand payment.");
		}else if (user.getUserOptions().getBillingMode().equals(BillingMode.SMS)) {
			log.info("User "+user.getAuthorizationInfo().getUsername()+" sms payment. Sending payment remainder notification");
			notifier.notifyTicketRemainder(user,DateUtil.add(Calendar.SECOND, ApplicationSettings.SMS_PAYMENT_REMAINDER_TIME, now));
		}

		return paymentSucc;
	}

	private boolean isLowTicketCount(List<Ticket> allTickets) {
		
		for(Ticket ticket : allTickets){
			if(!ticket.getTicketType().equals(TicketType.T_VALUE)){
				return false;
			}
		}
		
		if(allTickets.size()<=ApplicationSettings.LOW_TICKET_WARNING_COUNT){
			return true;
		}else{
			return false;
		}
	}
}




