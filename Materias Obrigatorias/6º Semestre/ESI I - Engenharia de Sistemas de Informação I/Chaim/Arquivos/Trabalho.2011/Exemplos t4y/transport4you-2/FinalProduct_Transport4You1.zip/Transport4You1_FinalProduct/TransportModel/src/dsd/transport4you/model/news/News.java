package dsd.transport4you.model.news;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import dsd.transport4you.model.user.User;

@Entity
@Table(name="NEWS")
@NamedQueries({
		@NamedQuery(name = "allNews", query = "SELECT n FROM News n order by time desc"),
		@NamedQuery(name = "newsByID", query = "SELECT n FROM News n where n.id = ?1")
})
public class News {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	@Column(name="title",unique=false,nullable=false)
	private String title;
	
	@Column(name="contents",unique=false,nullable=false,length=1024)
	private String contents;
	
	@ManyToOne(optional=false)
	private User author;
	
	@Column(name="time",unique=false,nullable=false)
	private Date time;
	
	@Enumerated
	private NewsCategory category;

	public News() {
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public String getContents() {
		return contents;
	}

	public User getAuthor() {
		return author;
	}

	public Date getTime() {
		return time;
	}

	public NewsCategory getCategory() {
		return category;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public void setAuthor(User author) {
		this.author = author;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public void setCategory(NewsCategory category) {
		this.category = category;
	}
}
