package dsd.transport4you.commprot.rpc;

public class RPCException extends Exception {
	
	public RPCException(String error) {
		super(error);
	}
	public RPCException(Throwable throwable) {
		super(throwable);
	}
}
