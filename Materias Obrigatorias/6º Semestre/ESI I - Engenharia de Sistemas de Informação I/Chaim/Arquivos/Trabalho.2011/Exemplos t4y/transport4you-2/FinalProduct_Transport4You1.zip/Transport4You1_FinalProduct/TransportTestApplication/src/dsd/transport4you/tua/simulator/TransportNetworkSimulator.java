package dsd.transport4you.tua.simulator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.network.TransportUnit;
import dsd.transport4you.model.user.User;
import dsd.transport4you.model.user.authorization.Role;
import dsd.transport4you.model.user.authorization.Role.RoleType;


/**
 * Simulates behavior of multiple Transport units
 * 
 * @author Dino
 *
 */
public class TransportNetworkSimulator {

	private static Random rand;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		rand = new Random();

		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		
		Role userRole = dao.getRoleByType(RoleType.USER);
		
		List<User> users = new ArrayList<User>(userRole.getUsers());
		List<TransportLine> lines = new ArrayList<TransportLine>(dao.getAllTransportLines());
		List<TransportUnit> units = new ArrayList<TransportUnit>(dao.getAllTransportUnits());

		//printOut(users, lines, units);
				
		UsersLocationService.initializeRandomData(users, lines, units);
		
		List<Thread> simulatorThreads = new ArrayList<Thread>();
	
		for (TransportUnit transportUnit : units) {
			simulatorThreads.add(new Thread(
					new TransportUnitSimulator(transportUnit.getIdentifier(), getRandomLine(lines))));
		}
		
		for (Thread thread : simulatorThreads) {
			thread.start();
		}
				
		dao.close();
	}

	private static void printOut(List<User> users, List<TransportLine> lines,
			List<TransportUnit> units) {
		System.out.println(users);
		System.out.println(lines);
		System.out.println(units);
		
		for (TransportLine line : lines) {
			for (TransportLineStation lineStation : line.getTransportLineStationsForwardTrip()) {
				System.out.println("TStation: "+lineStation.getTransportStation().getId());
			}
			for (TransportLineStation lineStation : line.getTransportLineStationsBackwardTrip()) {
				System.out.println("TStation: "+lineStation.getTransportStation().getId());
			}
		}
	}

	/**
	 * Get random line from list of all lines.
	 * @param lines All lines
	 * @return Random line
	 */
	private static TransportLine getRandomLine(List<TransportLine> lines) {
		int n = rand.nextInt(lines.size());
		return lines.get(n);
	}
}


