/**
 * 
 */
package dsd.transport4you.util.exceptions;

/**
 * @author Dajan
 *
 */
public class NoActiveRoutesException extends TransportModelException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoActiveRoutesException(Exception e) {
		super(e);
		// TODO Auto-generated constructor stub
	}
	
	public NoActiveRoutesException(String path) {
		super(path);
	}

}
