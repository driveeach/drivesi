/**
 * 
 */
package dsd.transport4you.unit.modules;

import java.util.Set;

import dsd.transport4you.unit.model.WiFiAddress;

/**
 * Detects passengers inside the transport unit over WiFi
 * 
 * @author Dino
 *
 */
public abstract class WiFiModule {
	public abstract Set<WiFiAddress> getAddressesInRange();
}
