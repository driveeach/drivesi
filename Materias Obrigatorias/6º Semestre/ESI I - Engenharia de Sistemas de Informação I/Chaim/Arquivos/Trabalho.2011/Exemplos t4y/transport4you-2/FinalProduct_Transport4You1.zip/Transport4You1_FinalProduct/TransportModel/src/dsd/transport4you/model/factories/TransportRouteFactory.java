/**
 * 
 */
package dsd.transport4you.model.factories;

import java.util.LinkedHashSet;

import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.route.TransportRoute;
import dsd.transport4you.model.route.TransportRouteSection;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.ITransportUnitUserData;

/**
 * @author Dajan
 *
 */
public class TransportRouteFactory {

	public static TransportRoute createEmptyTransportRoute(){
		
		TransportRoute transportRoute = new TransportRoute();
		transportRoute.setActive(false);
		transportRoute.setRouteSections(new LinkedHashSet<TransportRouteSection>());
		
		return transportRoute;
	}
	
	public static TransportRoute createUsersTransportRoute(ITransportUnitUserData userData, User user, TransportLineStation fromStation){
		
		TransportRoute transportRoute = new TransportRoute();
		
		//create and set root section
		TransportRouteSection routeSection = new TransportRouteSection();
		routeSection.setFromStation(fromStation);
		routeSection.setToStation(null);
		routeSection.setFromStationTime(userData.getTimeStamp());
		routeSection.setRoute(transportRoute);
		
		
		//set transport route
		transportRoute.setUser(user);
		transportRoute.setActive(true);
		transportRoute.setRouteSections(new LinkedHashSet<TransportRouteSection>());
		transportRoute.getRouteSections().add(routeSection);
		
		return transportRoute;
	}
	
	public static TransportRoute updateUsersTransportRoute(TransportRoute transportRoute, User user, TransportRouteSection section){
		
		transportRoute.setUser(user);
		transportRoute.getRouteSections().add(section);
		
		return transportRoute;
		
		
	}
	


	
}
