package dsd.transport4you.model.network;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import dsd.transport4you.util.exceptions.TransportModelValidationException;

/**
 * Represents a particular layer of a transport network.
 * @author toni
 */
@Entity
@Table(name="TRANSPORT_LAYER",uniqueConstraints={@UniqueConstraint(columnNames={"type","transportNetwork_id"})})
@NamedQueries({
    @NamedQuery(name="allTransportLayers",query="SELECT tl FROM TransportLayer tl")
})
public class TransportLayer {

	public enum TransportLayerType{
		BUS,
		METRO,
		TRAM
	}
	
	@Id
	@GeneratedValue
	private Integer id;
	
	/**
	 * Transport network this transport layer belongs to.
	 */
	@ManyToOne
	private TransportNetwork transportNetwork;
	
	/**
	 * Type of transport layer.
	 */
	@Enumerated
	private TransportLayerType type;
	
	/**
	 * Transport lines that make up this network.
	 */
	@OneToMany(mappedBy="transportLayer",cascade=CascadeType.PERSIST)
	private Set<TransportLine> transportLines;

	/**
	 * Transport lines that make up this network.
	 */
	@OneToMany(mappedBy="transportLayer",cascade=CascadeType.PERSIST)
	private Set<TransportUnit> transportUnits;
	
	public TransportLayer() {
		// TODO Auto-generated constructor stub
	}
	
	public TransportLayer(TransportNetwork network,TransportLayerType type) {
		setTransportNetwork(network);
		setType(type);
	}
	
	public TransportLayer(TransportNetwork network,TransportLayerType type,Set<TransportLine> transportLines) {
		setTransportNetwork(network);
		setType(type);
		setTransportLines(transportLines);
	}

	@Override
	public String toString() {
		return "transport layer "+getType();
	}
	
	public Integer getId() {
		return id;
	}

	public Set<TransportLine> getTransportLines() {
		return transportLines;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setTransportLines(Set<TransportLine> transportLines) {
		this.transportLines = transportLines;
	}
	
	public TransportNetwork getTransportNetwork() {
		return transportNetwork;
	}

	public void setTransportNetwork(TransportNetwork transportNetwork) {
		this.transportNetwork = transportNetwork;
	}

	public TransportLayerType getType() {
		return type;
	}

	public void setType(TransportLayerType type) {
		this.type = type;
	}

	public Set<TransportUnit> getTransportUnits() {
		return transportUnits;
	}

	public void setTransportUnits(Set<TransportUnit> transportUnits) {
		this.transportUnits = transportUnits;
	}

	public void validate() throws TransportModelValidationException{
		for(TransportLine line : getTransportLines()){
			line.validate();
		}
	}
}
