package dsd.transport4you.model.network;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import dsd.transport4you.util.exceptions.TransportModelValidationException;

/**
 * Represents a transport line of the transport network.
 * Class is an entity object.
 * @author toni, dajan
 */

@Entity
@Table(name="TRANSPORT_LINE")
@NamedQueries({
    @NamedQuery(name="transportLineByName",query="SELECT tl FROM TransportLine tl WHERE tl.name = ?1"),
    @NamedQuery(name="transportLineById",query="SELECT tl FROM TransportLine tl WHERE tl.id = ?1"),
    @NamedQuery(name="allTransportLines",query="SELECT tl FROM TransportLine tl")
})
public class TransportLine {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	/**
	 * Tranport line name.
	 */
	@Column(name="name",length=50,unique=true,nullable=false)
	private String name;
	/**
	 * List of stations that make up this lines forward trip.
	 */
	@OneToMany(mappedBy="transportLineForward",cascade=CascadeType.PERSIST)
	@OrderBy(value="stationNumber")
	private Collection<TransportLineStation> transportLineStationsForwardTrip;
	/**
	 * List of stations that make up this lines backward trip.
	 */
	@OneToMany(mappedBy="transportLineBackward",cascade=CascadeType.PERSIST)
	@OrderBy(value="stationNumber")
	private Collection<TransportLineStation> transportLineStationsBackwardTrip;
	
	/**
	 * Transport layer this transport line belongs to.
	 */
	@ManyToOne
	private TransportLayer transportLayer;
	
	public TransportLine() {
		// TODO Auto-generated constructor stub
	}
	
	public TransportLine(String name,TransportLayer transportLayer) {
		setName(name);
		setTransportLayer(transportLayer);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof TransportLine)) {
			return false;
		}
		TransportLine line = (TransportLine) obj;

		return line.id.equals(this.id);
	}
	
	@Override
	public String toString() {
		return "Transport Line "+getName();
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Collection<TransportLineStation> getTransportLineStationsForwardTrip() {
		return transportLineStationsForwardTrip;
	}
	public void setTransportLineStationsForwardTrip(Collection<TransportLineStation> transportLineStationsForwardTrip) {
		this.transportLineStationsForwardTrip = transportLineStationsForwardTrip;
	}
	public Collection<TransportLineStation> getTransportLineStationsBackwardTrip() {
		return transportLineStationsBackwardTrip;
	}
	public void setTransportLineStationsBackwardTrip(Collection<TransportLineStation> transportLineStationsBackwardTrip) {
		this.transportLineStationsBackwardTrip = transportLineStationsBackwardTrip;
	}
	
	public TransportLayer getTransportLayer() {
		return transportLayer;
	}

	public void setTransportLayer(TransportLayer transportLayer) {
		this.transportLayer = transportLayer;
	}

	public void validate() throws TransportModelValidationException{
		
		//check station duplicates
		
		Set<String> transportLineStationNamesFwd = new HashSet<String>();
		Set<String> transportLineStationNamesBkw = new HashSet<String>();
		
		
		for(TransportLineStation lineStation : getTransportLineStationsForwardTrip()){
			transportLineStationNamesFwd.add(lineStation.getTransportStation().getName()+lineStation.getTransportStation().getIndex());
		}
		
		if(transportLineStationNamesFwd.size()<getTransportLineStationsForwardTrip().size()){
			throw new TransportModelValidationException("TrasportLine "+getName()+" forward line stations contains duplicate stations");
		}
		
		for(TransportLineStation lineStation : getTransportLineStationsBackwardTrip()){
			transportLineStationNamesBkw.add(lineStation.getTransportStation().getName()+lineStation.getTransportStation().getIndex());
		}
		
		if(transportLineStationNamesBkw.size()<getTransportLineStationsBackwardTrip().size()){
			throw new TransportModelValidationException("TrasportLine "+getName()+" backward line stations contains duplicate stations");
		}
		
		//check station endings
		
		List<TransportLineStation> fwd = new ArrayList<TransportLineStation>(getTransportLineStationsForwardTrip());
		List<TransportLineStation> bkw = new ArrayList<TransportLineStation>(getTransportLineStationsBackwardTrip());
	
		Collections.sort(fwd,new Comparator<TransportLineStation>() {
			@Override
			public int compare(TransportLineStation o1, TransportLineStation o2) {
				return o1.getStationNumber().compareTo(o2.getStationNumber());
			}}
		);
		Collections.sort(bkw,new Comparator<TransportLineStation>() {
			@Override
			public int compare(TransportLineStation o1, TransportLineStation o2) {
				return o1.getStationNumber().compareTo(o2.getStationNumber());
			}}
		);
		
		String fwdStart=fwd.get(0).getTransportStation().getName();
		String fwdEnd=fwd.get(fwd.size() - 1).getTransportStation().getName();
		String bkwStart=bkw.get(0).getTransportStation().getName();
		String bkwEnd=bkw.get(bkw.size() - 1).getTransportStation().getName();
		
		try {
			if (!fwdStart.equals(bkwEnd) || !bkwStart.equals(fwdEnd)) {
				throw new TransportModelValidationException("transport line "+ getName() + " doesn't match station endings ("+fwdStart+","+fwdEnd+"),("+bkwStart+","+bkwEnd+")");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
