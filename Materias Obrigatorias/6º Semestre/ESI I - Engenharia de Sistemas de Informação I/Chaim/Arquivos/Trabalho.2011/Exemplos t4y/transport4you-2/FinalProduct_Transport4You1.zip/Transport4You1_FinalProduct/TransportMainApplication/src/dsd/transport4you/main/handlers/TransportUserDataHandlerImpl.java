package dsd.transport4you.main.handlers;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.interfaces.model.MacAddress;
import dsd.transport4you.interfaces.model.TransportLineDirection;
import dsd.transport4you.model.factories.TransportRouteFactory;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.route.TransportRoute;
import dsd.transport4you.model.route.TransportRouteSection;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.ITransportUnitUserData;
import dsd.transport4you.settings.ITransportUserDataHandler;
import dsd.transport4you.util.exceptions.NoActiveRoutesException;

public class TransportUserDataHandlerImpl implements ITransportUserDataHandler {

	private static Log log = LogFactory
			.getLog(TransportUserDataHandlerImpl.class);

	@Override
	public void handle(ITransportUnitUserData data) {

		log.info("");
		log.info("");
		log.info("started handling user data " + data.toString());

		@SuppressWarnings("unused")
		Boolean paymentSucc = null;
		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		TreeSet<User> newUsers;
		TreeSet<User> missingUsers;

		TransportLineDirection lineDirection = data.getTransportLine().getTransportLineDirection();
		String lineName = data.getTransportLine().getTransportLineName();

		TransportLineStation transportLineStation = dao
				.getNearestTransportLineStation(data.getGpsLocation()
						.getLongitude(), data.getGpsLocation().getLatitude(),
						lineName, lineDirection);
		log.info("Transport line station detected: " + transportLineStation);

		if (transportLineStation != null) {

			newUsers = identifyUsers(dao, data, "newUsers");
			log.info("New users: " + newUsers);
			missingUsers = identifyUsers(dao, data, "missingUsers");
			log.info("Missing users: " + missingUsers);

			for (User user : newUsers) {
				if (user.getActiveTicket() == null) {
					paymentSucc = new BillingHandler(user, data.getTimeStamp(), dao).bill();
				}

				if (!user.hasActiveRoute()) {
					user.getTransportRoutes().add(
							TransportRouteFactory.createUsersTransportRoute(
									data, user, transportLineStation));
				} else {
					TransportRouteSection activeRouteSection = userHasActiveRouteSection(user);
					if (activeRouteSection == null) {
						TransportRouteSection newRouteSection = new TransportRouteSection();
						newRouteSection.setFromStation(transportLineStation);
						newRouteSection.setFromStationTime(data.getTimeStamp());
						try {
							newRouteSection.setRoute(user.getActiveRoute());
							user.getActiveRoute().getRouteSections()
									.add(newRouteSection);
						} catch (NoActiveRoutesException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
					// else - ignore??
				}
			}

			for (User user : missingUsers) {

				updateRouteSection(user, transportLineStation, data);
				// separate thread closes route, because route can continue in
				// other
				// route section.
			}

			dao.getEntityManager().getTransaction().begin();
			for (User user : newUsers) {
				dao.save(user);
			}
			for (User user : missingUsers) {
				dao.save(user);
			}
			dao.getEntityManager().getTransaction().commit();

		} else {
			log.warn("detected daemon station");
		}

		dao.close();

		log.info("finished handling user data " + data.toString());
		log.info("");
		log.info("");
	}

	private TransportRouteSection userHasActiveRouteSection(User user) {

		try {
			TransportRoute activeRoute = user.getActiveRoute();
			Collection<TransportRouteSection> routeSections = activeRoute
					.getRouteSections();

			for (TransportRouteSection section : routeSections) {
				if (section.isActive()) {
					return section;
				}
			}
			// return null;

		} catch (NoActiveRoutesException e) {
			log.error("stacktrace starts here...");
			e.printStackTrace();
			log.error("stacktrace ends here...");
		}
		return null;

	}

	private void updateRouteSection(User user,
			TransportLineStation transportLineStation,
			ITransportUnitUserData data) {

		try {
			Set<TransportRouteSection> routeSections = (Set<TransportRouteSection>) user
					.getActiveRoute().getRouteSections();
			for (TransportRouteSection routeSection : routeSections) {
				if (routeSection.getToStation() == null) {
					routeSection.setToStation(transportLineStation);
					routeSection.setToStationTime(data.getTimeStamp());
				}
			}

			// TransportRouteSection lastSection =
			// routeSections.get(routeSections.size()-1);
			// lastSection.setToStation(transportLineStation);
			// lastSection.setToStationTime(data.getTimeStamp());

		} catch (NoActiveRoutesException e) {
			log.error("stacktrace starts here...");
			e.printStackTrace();
			log.error("stacktrace ends here...");
		}

	}

	private TreeSet<User> identifyUsers(ITransportModelDAO dao,
			ITransportUnitUserData data, String usersType) {
		TreeSet<User> newUsers = new TreeSet<User>();
		List<MacAddress> users = null;
		if (usersType.equals("newUsers")) {
			users = data.getNewUsers();
		}
		if (usersType.equals("missingUsers")) {
			users = data.getMissingUsers();
		}
		
		for (MacAddress macAddress : users) {
			
			log.info(macAddress.getAddress());
			
			if (macAddress.getAddressType().equals(
					MacAddress.AddressType.BLUETOOTH)) {
				User user = dao.getUserByBluetoothMacAddress(macAddress
						.getAddress());
				if (user != null) {
					newUsers.add(user);
//					log.info("New user is identified:" + user);
				} else {
					log.warn("User "+macAddress.getAddress()+" is not using system");
				}
			}
			if (macAddress.getAddressType().equals(MacAddress.AddressType.WIFI)) {
				User user = dao
						.getUserByWiFiMacAddress(macAddress.getAddress());
				if (user != null) {
					newUsers.add(user);
//					log.info("New user is identified:" + user);
				} else {
					log.warn("User "+macAddress.getAddress()+" is not using system");
				}
			}
		}
		return newUsers;
	}
}
