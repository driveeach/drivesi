package dsd.transport4you.unit.dao;

import java.util.ArrayList;
import java.util.List;

import dsd.transport4you.unit.dao.interfaces.IOperations;
import dsd.transport4you.unit.model.BluetoothAddress;
import dsd.transport4you.unit.model.WiFiAddress;


/**
 * Implementation of database that holds all of its data in memory.
 * It holds passengers that are currently in the transport unit.
 * @author Dino
 *
 */
public class DatabaseMemoryImpl implements IOperations{

	List<BluetoothAddress> bluetoothAdresses;
	List<WiFiAddress> wiFiAdresses;
	
	public DatabaseMemoryImpl(){
		bluetoothAdresses = new ArrayList<BluetoothAddress>();
		wiFiAdresses = new ArrayList<WiFiAddress>();
	}
	
	@Override
	public void saveBluetoothAddress(BluetoothAddress address) {
		if(!bluetoothAdresses.contains(address)){
			bluetoothAdresses.add(address);
		}
	}
	
	@Override
	public List<BluetoothAddress> getAllBluetoothAdresses() {
		return bluetoothAdresses;
	}
	
	@Override
	public void deleteBluetoothAddress(BluetoothAddress address) {
		bluetoothAdresses.remove(address);
	}
	
	
	@Override
	public BluetoothAddress getBluetoothAddress(BluetoothAddress address) {
		return bluetoothAdresses.get(bluetoothAdresses.indexOf(address));
	}
	
	@Override
	public void saveBluetoothAddresses(List<BluetoothAddress> addresses) {
		bluetoothAdresses.addAll(addresses);
	}
	
	@Override
	public void deleteBluetoothAddresses(List<BluetoothAddress> addresses) {
		bluetoothAdresses.removeAll(addresses);
	}
	
	@Override
	public int numberOfBluetoothAddresses() {
		return bluetoothAdresses.size();
	}
	
	@Override
	public void saveWiFiAddress(WiFiAddress address) {
		if(!wiFiAdresses.contains(address)){
			wiFiAdresses.add(address);
		}
		
	}
	
	@Override
	public List<WiFiAddress> getAllWiFiAddresses() {
		return wiFiAdresses;
	}
	
	@Override
	public void saveWiFiAddresses(List<WiFiAddress> addresses) {
		wiFiAdresses.addAll(addresses);
	}		
	@Override
	public void deleteWiFiAddress(WiFiAddress address) {
		wiFiAdresses.remove(address);
	}
	
	@Override
	public WiFiAddress getWiFiAddress(WiFiAddress address) {
		return wiFiAdresses.get(wiFiAdresses.indexOf(address));
	}
	
	@Override
	public void deleteWiFiAddresses(List<WiFiAddress> addresses) {
		wiFiAdresses.removeAll(addresses);
	}

	@Override
	public int numberOfWiFiAddresses() {
		return wiFiAdresses.size();
	}
}
