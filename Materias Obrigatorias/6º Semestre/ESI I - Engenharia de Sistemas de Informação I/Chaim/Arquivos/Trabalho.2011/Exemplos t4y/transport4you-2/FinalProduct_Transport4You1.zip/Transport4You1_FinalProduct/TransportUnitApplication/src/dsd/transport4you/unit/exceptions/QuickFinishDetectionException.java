package dsd.transport4you.unit.exceptions;

/**
 * 
 * @author Dino
 *
 */
public class QuickFinishDetectionException extends TransportUnitException{

	private static final long serialVersionUID = -3489678118149673865L;

	public QuickFinishDetectionException(String path) {
		super(path);
	}
		
	public QuickFinishDetectionException(Exception e) {
		super(e);
	}
}
