package dsd.transport4you.main.thread;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimerTask;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.main.notification.SMSUserNotifier;
import dsd.transport4you.main.notification.UserNotifier;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.network.changes.TransportRouteInterruption;
import dsd.transport4you.model.route.standard.TransportStandardRouteSection;
import dsd.transport4you.model.user.User;

/**
 * @author Dajan
 *
 */
public class StandardRouteModificationInterruptionNotificationTask extends TimerTask{

	private UserNotifier notifier = SMSUserNotifier.getInstance();
	public static final Log log = LogFactory.getLog(StandardRouteModificationInterruptionNotificationTask.class);
	
	
	@Override
	public void run() {
		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		
		List<TransportRouteInterruption> routeInteruptions = dao.getTransportRouteInterruptions();
		List<User> users = dao.getUsersWithStandardRouteSections();
		
		for(User user : users){
			
			List<TransportStandardRouteSection> standardTransportRoutes = new ArrayList<TransportStandardRouteSection>(user.getTransportStandardRouteSections());
			
			checkRoutesForNotifications(standardTransportRoutes, routeInteruptions, user, dao);
			
			
		}
		
	}


	private void checkRoutesForNotifications(
			List<TransportStandardRouteSection> transportStandardRouteSections,
			List<TransportRouteInterruption> routeInterruptions, User user,
			ITransportModelDAO dao) {
		
		List<TransportRouteInterruption> interruptionsForNotification = new ArrayList<TransportRouteInterruption>();
		
		for(TransportRouteInterruption routeInterruption : routeInterruptions){
			for(TransportStandardRouteSection standardRouteSection : transportStandardRouteSections){
				
				isStandardRouteSectionInterrupted(standardRouteSection, routeInterruption, dao);
				
				
			}
		}
	
		
	}


	private Boolean isStandardRouteSectionInterrupted(
			TransportStandardRouteSection standardRouteSection,
			TransportRouteInterruption routeInterruption, ITransportModelDAO dao) {
		
		TransportLineStation fromStandardStation = standardRouteSection.getFromStation();
		TransportLineStation toStandardStation = standardRouteSection.getToStation();

		if(!fromStandardStation.getTransportLine().equals(routeInterruption.getFromStation().getTransportLine())){
			return false;
		}
		
		GregorianCalendar cal1 = new GregorianCalendar();
		cal1.setTime(standardRouteSection.getFromStationDayTime());

//		GregorianCalendar cal2 = new GregorianCalendar();
//		cal2.setTime(routeInterruption.getFromStation());
		
		//TODO: dodati vrijeme u interruption i nastaviti probjeru je li standardna ruta prekinuta
		
		return false;
		
	}

}
