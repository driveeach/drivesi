/**
 * 
 */
package dsd.transport4you.settings;

/**
 * Interface for client implementations of communication protocol.
 * 
 * @author Dajan
 *
 */
public interface ICommunicationProtocolClient {

	/**
	 * Sends data through defined protocol.
	 * 
	 * @return true if data is sent, false otherwise. 
	 */
	public Boolean sendData();
	
}
