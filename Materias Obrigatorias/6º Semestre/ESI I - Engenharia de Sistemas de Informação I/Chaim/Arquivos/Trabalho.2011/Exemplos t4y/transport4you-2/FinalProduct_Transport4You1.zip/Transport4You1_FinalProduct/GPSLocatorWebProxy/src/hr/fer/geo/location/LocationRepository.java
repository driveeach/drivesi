package hr.fer.geo.location;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class LocationRepository {
	
	private static LocationRepository instance=null;
	
	private Map<String, String> locations;
	
	private LocationRepository() {
		locations  = Collections.synchronizedMap(new HashMap<String, String>());
	}
	
	public static synchronized LocationRepository getInstance(){
		if(instance==null){
			instance = new LocationRepository();
		}
		return instance;
	}
	
	public void add(String ip,String latitude,String longitude){
		locations.put(ip, "latitude:"+latitude+","+"longitude:"+longitude);
	}
	
	public String get(String ip){
		return locations.get(ip);
	}
}
