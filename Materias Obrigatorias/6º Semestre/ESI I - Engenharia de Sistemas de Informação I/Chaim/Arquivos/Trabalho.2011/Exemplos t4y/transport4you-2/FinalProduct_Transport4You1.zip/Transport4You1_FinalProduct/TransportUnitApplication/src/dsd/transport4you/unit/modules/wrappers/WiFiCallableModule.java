package dsd.transport4you.unit.modules.wrappers;

import java.util.Set;
import java.util.concurrent.Callable;

import dsd.transport4you.unit.model.WiFiAddress;
import dsd.transport4you.unit.modules.WiFiModule;

public class WiFiCallableModule implements Callable<Set<WiFiAddress>>{

	private WiFiModule wiFiModule;
	
	public WiFiCallableModule(WiFiModule wiFiModule){
		this.wiFiModule = wiFiModule;
	}

	@Override
	public Set<WiFiAddress> call() throws Exception {
		return wiFiModule.getAddressesInRange();
	}	
}
