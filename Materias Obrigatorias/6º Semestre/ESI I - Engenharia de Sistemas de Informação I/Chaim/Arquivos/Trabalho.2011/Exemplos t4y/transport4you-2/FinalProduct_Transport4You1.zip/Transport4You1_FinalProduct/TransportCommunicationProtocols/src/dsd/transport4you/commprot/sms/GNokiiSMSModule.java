package dsd.transport4you.commprot.sms;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.commprot.util.ProcessInfo;
import dsd.transport4you.commprot.util.ProcessUtil;
import dsd.transport4you.commprot.util.exceptions.GnokiiSMSSendingException;
import dsd.transport4you.commprot.util.exceptions.SMSModuleException;

public class GNokiiSMSModule extends SMSModule{

	public static Log log = LogFactory.getLog(GNokiiSMSModule.class);
	
	private static boolean DELETE_MSG=false;
	private static boolean DEBUG=true;
	
	static String[] test={"1. Inbox Message (Read)",
						  "Date/time: 21/11/2010 14:46:47 +0100",
							"Sender: +385955029950 Msg Center: +385951000100",
							"Text:",
							"Autobus"};
	
	private static Pattern pat1 = Pattern.compile("^\\d+\\.\\s+Inbox\\s+Message\\s+\\(Unread\\)$");
	private static Pattern pat2 = Pattern.compile("^Date/time:\\s+(.*)$");
	private static Pattern pat3 = Pattern.compile("^Sender:\\s+(.*)\\s+Msg\\s+Center:\\s+(.*)$");
	
	private static DateFormat format = new SimpleDateFormat("dd/mm/yyyy HH:mm:ss Z");
	
	private static GNokiiSMSModule instance;
	
	private GNokiiSMSModule() {
		// TODO Auto-generated constructor stub
	}
	
	public static GNokiiSMSModule getInstance() {
		if(instance==null){
			instance=new GNokiiSMSModule();
		}
		return instance;
	}
	
	@Override
	public synchronized void sendMessage(SMSMessage msg) throws GnokiiSMSSendingException {
		
		String command="gnokii --sendsms {{toNumber}}";
		command=command.replace("{{toNumber}}", msg.getTo());
		
		log.info("sending message to "+msg.getTo());
		
		try {
			ProcessInfo info = ProcessUtil.exec(command,msg.getMessage(),null);
			
			if(DEBUG){
				log.info(info.stdout);
				log.info(info.stderr);
				log.info(info.returnValue);
			}
			
			if(info.returnValue!=0){
				throw new GnokiiSMSSendingException("gnokii process returned value "+info.returnValue);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public synchronized List<SMSMessage> getNewMessages() {
		
		String command="gnokii --getsms ME 0 512"+(DELETE_MSG?" -d":"");
		
		log.info("getting new messages");
		
		ProcessInfo info=null;
		try {
			info = ProcessUtil.exec(command,null,null);
			
			if(DEBUG){
				log.info(info.stdout);
				log.info(info.stderr);
				log.info(info.returnValue);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		List<SMSMessage> messages = new LinkedList<SMSMessage>();
		
		String[] arr=info.stdout.split("\n");
		for(int i=0;i<arr.length;){
			
			Matcher m = pat1.matcher(arr[i]);
			
			if(m.matches()){
				
				m=pat2.matcher(arr[i+1]);
				m.matches();
				String timestamp = m.group(1);
				Date time=null;
				try {
					time = format.parse(timestamp);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				m=pat3.matcher(arr[i+2]);
				m.matches();
				String sender = m.group(1);
				
				String msg = arr[i+4];
				
				if (DEBUG) {
					System.out.println(timestamp);
					System.out.println(time);
					System.out.println(sender);
					System.out.println(msg);
				}
				messages.add(new SMSMessage(sender,null, msg,time));
				
				i+=5;
			}else{
				i++;
			}	
		}
			
		return messages;
	}

	public static void main(String[] args) throws SMSModuleException {
		
		SMSModule sms = new GNokiiSMSModule();
		
		sms.sendMessage(new SMSMessage(null,"0958208454", "Test from java wrapper!"));
		
//		List<SMSMessage> messages = sms.getNewMessages();
//		System.out.println(messages);

	}
}
