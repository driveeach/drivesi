package dsd.transport4you.actions.admin.routes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opensymphony.xwork2.Preparable;

import dsd.transport4you.actions.ExtendedActionSupport;
import dsd.transport4you.actions.interfaces.IAdminAction;
import dsd.transport4you.bean.TransportLayerBean;
import dsd.transport4you.model.network.TransportLayer;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.network.changes.TransportRouteModification;
import dsd.transport4you.model.network.comparators.TransportLineComparator;

public class ConfigRouteModificationAction extends ExtendedActionSupport implements IAdminAction, Preparable {

	private static final long serialVersionUID = -1380006827372725442L;

	private static Log log = LogFactory.getLog(ConfigRouteModificationAction.class);
	
	public final static String ADD_ROUTE_MODIFICATION_ATTEMPT = "addRouteModificationAttempt";
	
	private Integer transportLineId;
		
	private TransportLineStation fromStation;
	private TransportLineStation toStation;
	private String newStationNames;
	private Date fromDate;
	private Date toDate;
	
	private List<TransportLayer> transportLayers;
	private List<TransportLayerBean> transportLayersBean;
	
	private Integer fromStationId;
	private Integer toStationId;	
	
	private String message;
		
	@Override
	public String execute() throws Exception {	
		if (ADD_ROUTE_MODIFICATION_ATTEMPT.equals(getAttempt())) {
			log.info("Adding new route modification...");
						
			fromStation = webDAO.getTransportLineStationById(fromStationId);
			toStation = webDAO.getTransportLineStationById(toStationId);
			
			System.out.println(fromStationId);
			System.out.println(toStationId);
			System.out.println(newStationNames);
			
			TransportRouteModification modification = new TransportRouteModification();
			modification.setFromStation(fromStation);
			modification.setToStation(toStation);
			modification.setStationNameList(newStationNames);			
			modification.setFromTime(fromDate);
			modification.setToTime(toDate);
						
			webDAO.beginTransaction();
			webDAO.save(modification);
			webDAO.commitTransaction();
			
			setMessage(getText("messages.routeModificationSuccess"));

			log.info("Adding new route inrerruption...");
			return SUCCESS;
			
		} else {
			return INPUT;
		}
	}

	
	@Override
	public void validate() {
		if(ADD_ROUTE_MODIFICATION_ATTEMPT.equals(getAttempt())){	
			validateFromDate();
		}
	}
	
	private void validateFromDate() {
		if(fromDate == null){
			addFieldError("fromDate",getText("label.modificationStart")+" "+getText("errors.required"));
		}			
	}
	
	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
	
	public String getNewStationNames() {
		return newStationNames;
	}

	public void setNewStationNames(String newStationNames) {
		this.newStationNames = newStationNames;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Integer getFromStationId() {
		return fromStationId;
	}

	public void setFromStationId(Integer fromStationId) {
		this.fromStationId = fromStationId;
	}

	public Integer getToStationId() {
		return toStationId;
	}

	public void setToStationId(Integer toStationId) {
		this.toStationId = toStationId;
	}
	
	public Integer getTransportLineId() {
		return transportLineId;
	}

	public void setTransportLineId(Integer transportLineId) {
		this.transportLineId = transportLineId;
	}
	
	
	public List<TransportLayerBean> getTransportLayersBean() {
		return transportLayersBean;
	}


	public void setTransportLayersBean(List<TransportLayerBean> transportLayersBean) {
		this.transportLayersBean = transportLayersBean;
	}


	public List<TransportLayer> getTransportLayers() {
		return transportLayers;
	}

	public void setTransportLayers(List<TransportLayer> transportLayers) {
		this.transportLayers = transportLayers;
	}


	@Override
	public void prepare() throws Exception {

		transportLayersBean = new ArrayList<TransportLayerBean>();
		
		setTransportLayers(new ArrayList<TransportLayer>(webDAO.getAllTranportLayers()));
		
		for (TransportLayer layer : transportLayers) {			
			transportLayersBean.add(new TransportLayerBean(layer.getTransportLines(), layer.getType()));
		}
			
		for (TransportLayerBean layerBean : transportLayersBean) {
			Collections.sort(layerBean.getTransportLines(), new TransportLineComparator());
		}
	}
	
}
