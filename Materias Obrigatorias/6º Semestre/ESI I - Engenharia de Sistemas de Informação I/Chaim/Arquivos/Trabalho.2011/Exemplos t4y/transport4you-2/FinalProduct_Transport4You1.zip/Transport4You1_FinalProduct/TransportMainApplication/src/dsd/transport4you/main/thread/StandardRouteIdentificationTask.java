package dsd.transport4you.main.thread;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TimerTask;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.model.factories.TransportStandardRouteSectionFactory;
import dsd.transport4you.model.route.TransportRoute;
import dsd.transport4you.model.route.TransportRouteSection;
import dsd.transport4you.model.route.TransportRouteSectionWrapper;
import dsd.transport4you.model.route.standard.TransportStandardRouteSection;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.ApplicationSettings;

/**
 * @author Dajan
 *
 */
public class StandardRouteIdentificationTask extends TimerTask{

	public static final Log log = LogFactory.getLog(StandardRouteIdentificationTask.class);
	
	@Override
	public void run() {
		
		log.info("started task");
		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		
		List<User> users = new ArrayList<User>(dao.getAllUsers());
		
		for(User user : users){
			
			List<TransportStandardRouteSection> standardRouteSections = identifyUsersStandardRoutes(user);
			
			dao.getEntityManager().getTransaction().begin();
			
			for(TransportStandardRouteSection standardRouteSection : standardRouteSections){
				
				dao.save(standardRouteSection);
				log.info("Standard route sections saved");
				
			}
			
			dao.getEntityManager().getTransaction().commit();
			
			
			
		}
		
		dao.close();
		
	}

	private List<TransportStandardRouteSection> identifyUsersStandardRoutes(User user) {
		
		List<TransportStandardRouteSection> standardRouteSections = new ArrayList<TransportStandardRouteSection>();
		
		List<TransportRoute> routes = new ArrayList<TransportRoute>(user.getTransportRoutes());
		
		List<TransportRouteSection> routeSections = new ArrayList<TransportRouteSection>();
		
		for(TransportRoute route : routes){
			List<TransportRouteSection> routeSectionsTemp = new ArrayList<TransportRouteSection>(route.getRouteSections());
			routeSections.addAll(routeSectionsTemp);
		}
		
		List<TransportRouteSectionWrapper> wrappers = new ArrayList<TransportRouteSectionWrapper>();
		
		for(int i = 0; i < routeSections.size(); i++){
			
			TransportRouteSectionWrapper currentRouteSectionWrapper = new TransportRouteSectionWrapper(routeSections.get(i));
			
			for(int j = i+1; j < routeSections.size(); j++){
				
				TransportRouteSectionWrapper routeSectionWrapper = new TransportRouteSectionWrapper(routeSections.get(j));
				
				if(currentRouteSectionWrapper.equals(routeSectionWrapper)){
					currentRouteSectionWrapper.increaseCounter(1);
				}
				
				
				
			}
			
			wrappers.add(currentRouteSectionWrapper);
		}
		
		Collections.sort(wrappers);
		
		if(ApplicationSettings.STANDARD_ROUTE_SECTION_NOTIFICATION_NUMBER < wrappers.size()){
			
			for(int i = wrappers.size() - ApplicationSettings.STANDARD_ROUTE_SECTION_NOTIFICATION_NUMBER -1; i < wrappers.size(); i++){
				
				standardRouteSections.add(TransportStandardRouteSectionFactory.createTransportStandardRouteSection(wrappers.get(i), user));
				
			}
			
		}else{
			
			for(TransportRouteSectionWrapper wraper : wrappers){
				if(wraper.getCounter() >= ApplicationSettings.STANDARD_ROUTE_SECTION_MIN_COUNTER){
					standardRouteSections.add(TransportStandardRouteSectionFactory.createTransportStandardRouteSection(wraper, user));
				}
				
			}
			
		}
		
		return standardRouteSections;
		
	}

}
