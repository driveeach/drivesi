package dsd.transport4you.interfaces.model;

public enum TransportLineDirection {
	FORWARD,
	BACKWARD
}
