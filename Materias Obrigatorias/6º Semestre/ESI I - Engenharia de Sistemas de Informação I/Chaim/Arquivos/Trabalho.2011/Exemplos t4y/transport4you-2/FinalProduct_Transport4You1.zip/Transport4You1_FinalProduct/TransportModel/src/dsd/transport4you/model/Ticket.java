package dsd.transport4you.model;

import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.ApplicationSettings;
import dsd.transport4you.util.DateUtil;

/**
 * Represents a purchased transport network ticket.
 * @author toni, dajan
 */
@Entity
@Table(name="TICKET")
@NamedQueries({
		@NamedQuery(name = "uncheckedTicketsByUser", query = "SELECT t FROM Ticket t WHERE t.timeValidFrom is null and " +
															 "t.timeValidTo is null and t.user.id = ?1 " +
				                                             "order by t.ticketType")
})
public class Ticket {

	public enum TicketType {
		/**
		 * Time valued ticket type (time value constant defined in {@link ApplicationSettings ApplicationSettings} ).
		 * @see ApplicationSettings
		 */
		T_VALUE, 
		/**
		 * Ticket that is valid 1 day.
		 */
		DAILY, 
		/**
		 * Ticket that is valid 1 week.
		 */
		WEEKLY, 
		/**
		 * Ticket that is valid 1 month.
		 */
		MONTHLY 
	}
	
	@Id
	@GeneratedValue
	private Integer id;
	
	/**
	 * Ticket type.
	 */
	@Enumerated
	private TicketType ticketType;
	/**
	 * Time when this ticket is first used.
	 */
	@Column(name="timeValidFrom",unique=false,nullable=true)
	private Date timeValidFrom;
	
	@Column(name="timeValidTo",unique=false,nullable=true)
	private Date timeValidTo;
	
	/**
	 * Payment that has purchased this ticket.
	 */
	@ManyToOne(optional=false)
	private Payment payment;
	
	/**
	 * User this ticket belongs to.
	 */
	@ManyToOne
	private User user;
	
	public Ticket() {
		// TODO Auto-generated constructor stub
	}
	
	public Ticket(TicketType ticketType, User user) {
		this.ticketType = ticketType;
		this.user = user;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public TicketType getTicketType() {
		return ticketType;
	}
	public void setTicketType(TicketType ticketType) {
		this.ticketType = ticketType;
	}
	public Payment getPayment() {
		return payment;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	public Date getTimeValidFrom() {
		return timeValidFrom;
	}

	public Date getTimeValidTo() {
		return timeValidTo;
	}

	public void setTimeValidFrom(Date timeValidFrom) {
		this.timeValidFrom = timeValidFrom;
	}

	public void setTimeValidTo(Date timeValidTo) {
		this.timeValidTo = timeValidTo;
	}

	@Override
	public String toString() {
		return ticketType.name()+" validFrom:"+getTimeValidFrom()+" validTo:"+getTimeValidTo();
	}

	public void check(Date time) {
		setTimeValidFrom(time);
		//TODO: all other ticket types + 2 modes
		setTimeValidTo(DateUtil.add(Calendar.SECOND,ApplicationSettings.T_VAL,time));
	}
	
	public boolean isChecked(){
		return getTimeValidFrom()!=null;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ticket other = (Ticket) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
