package dsd.transport4you.main.thread;

import java.util.Date;
import java.util.TimerTask;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.main.handlers.BillingHandler;
import dsd.transport4you.model.user.User;

public class TicketExpirationTask extends TimerTask{

	public static final Log log = LogFactory.getLog(TicketExpirationTask.class);
	
	public TicketExpirationTask() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() {
		
		log.info("started task");
		
		Date now = new Date();
		
		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		
		dao.getEntityManager().getTransaction().begin();
		
		for(User user : dao.getUsersWithExpiredTicket()){
		
			user.setActiveTicket(null);
			log.info("user #"+user.getId()+" ticket expired");
			
			new BillingHandler(user, now, dao).bill();
			dao.update(user);
		}
		
		dao.getEntityManager().getTransaction().commit();
		
		dao.close();
		log.info("finished task");
	}

}
