package dsd.transport4you.model.news;

public enum NewsCategory {
	ROUTE_MODIFICATION,
	ROUTE_INTERRUPTION,
	GENERAL
}
