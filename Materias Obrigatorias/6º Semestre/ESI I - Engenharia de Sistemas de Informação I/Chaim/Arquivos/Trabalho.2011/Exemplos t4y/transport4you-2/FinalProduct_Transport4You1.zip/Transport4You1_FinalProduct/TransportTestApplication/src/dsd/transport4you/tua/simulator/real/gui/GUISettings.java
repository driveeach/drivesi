package dsd.transport4you.tua.simulator.real.gui;

public class GUISettings {

	public static final String BUTTON_OPEN_DOORS_TEXT = "Open doors";
	public static final String BUTTON_CLOSE_DOORS_TEXT = "Close doors";
	public static final String BUTTON_SELECT_LINE_TEXT = "Select line";

	public static final int WINDOW_WIDTH = 600;
	public static final int WINDOW_HEIGHT = 600;
	
}
