/**
 * 
 */
package dsd.transport4you.model.network.changes;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import dsd.transport4you.model.network.TransportLineStation;

/**
 * @author Dajan
 * 
 */
@Entity
@Table(name="TRANSPORT_ROUTE_INTERRUPTION")
@NamedQueries({
		@NamedQuery(name = "allRouteInterruptions", query = "SELECT ri FROM TransportRouteInterruption ri")
})
public class TransportRouteInterruption {

	@Id
	@GeneratedValue
	private Integer id;
	
	@ManyToOne(optional = false)
	private TransportLineStation fromStation;
	
	@ManyToOne(optional = false)
	private TransportLineStation toStation;

	/**
	 * Time when interruption becomes actual.
	 */
	@Column(name="fromTime",unique=false,nullable=false)
	private Date fromTime;
	/**
	 * Time when interruption ceases to exist.Null value signifies that current
	 * stop time is still undefined.
	 */
	@Column(name="toTime",unique=false,nullable=true)
	private Date toTime;
	
	public TransportRouteInterruption(){
		
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public TransportLineStation getFromStation() {
		return fromStation;
	}

	public void setFromStation(TransportLineStation fromStation) {
		this.fromStation = fromStation;
	}

	public TransportLineStation getToStation() {
		return toStation;
	}

	public void setToStation(TransportLineStation toStation) {
		this.toStation = toStation;
	}

	public Date getFromTime() {
		return fromTime;
	}

	public void setFromTime(Date fromTime) {
		this.fromTime = fromTime;
	}

	public Date getToTime() {
		return toTime;
	}

	public void setToTime(Date toTime) {
		this.toTime = toTime;
	}
	@Override
	public String toString() {
		return "route interruption #"
		+ getFromStation().getTransportLine().getName() + " ("
		+ getFromStation().getTransportStation().getDisplayName() + ","
		+ getToStation().getTransportStation().getDisplayName() + ") ["
		+ getFromTime() + "-" + getToTime() + "]";
	}

}
