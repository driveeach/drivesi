package dsd.transport4you.unit.exceptions;


public class GPSLocationUnavailable extends Exception {

	private static final long serialVersionUID = 1L;

	public GPSLocationUnavailable(Exception e) {
		super(e);
	}

}
