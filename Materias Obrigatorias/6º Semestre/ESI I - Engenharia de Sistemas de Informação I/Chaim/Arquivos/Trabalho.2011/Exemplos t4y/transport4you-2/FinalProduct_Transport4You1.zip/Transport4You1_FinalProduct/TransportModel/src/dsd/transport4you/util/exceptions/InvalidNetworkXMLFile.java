package dsd.transport4you.util.exceptions;

/**
 * Exception when problems occur in XML file parsing.
 * @author toni
 */
public class InvalidNetworkXMLFile extends TransportModelException {

	private static final long serialVersionUID = 1L;

	public InvalidNetworkXMLFile(Exception e) {
		super(e);
	}
	
	public InvalidNetworkXMLFile(String path) {
		super(path);
	}
	
}
