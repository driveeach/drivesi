package dsd.transport4you.unit.exceptions;

/**
 * Exception in the TransportUnit package.
 * @author Dino
 *
 */
public class TransportUnitException extends Exception{

	private static final long serialVersionUID = 6347750390340990510L;

	public TransportUnitException(String path) {
		super(path);
	}

	public TransportUnitException(Exception e) {
		super(e);
	}
}
