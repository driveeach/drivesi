package dsd.transport4you.actions.user;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.Preparable;

import dsd.transport4you.actions.ExtendedActionSupport;
import dsd.transport4you.actions.interfaces.IUserAction;
import dsd.transport4you.bean.UserBean;
import dsd.transport4you.commprot.payment.paypal.PaypalModule;
import dsd.transport4you.interfaces.model.UserCreditCardInfo;
import dsd.transport4you.model.Payment;
import dsd.transport4you.model.PaymentType;
import dsd.transport4you.model.Ticket;
import dsd.transport4you.model.Ticket.TicketType;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.ApplicationSettings;
import dsd.transport4you.settings.Constants;

public class ConfigUserTicketsAction extends ExtendedActionSupport implements IUserAction,Preparable,SessionAware {

	private static final long serialVersionUID = 400880065769043676L;
	public final static String CONFIG_USER_TICKETS_ATTEMPT = "configUserTickets";
	public final static String BUY_NEW_TICKETS_ATTEMPT = "buyNewTicketsAttempt";


	private User user;
	private int tvalTicketCount=0;
	private int dailyTicketCount=0;
	private int weeklyTicketCount=0;
	private int monthlyTicketCount=0;

	private String buyerLastName;
	private String buyerFirstName;
	private String buyerAddress1;
	private String buyerAddress2;
	private String buyerCity;
	private String buyerState;
	private String buyerZipCode;
	private String creditCardType;
	private String creditCardNumber;
	private String CVV2;
	private int expMonth;
	private int expYear;
	private int ticketsCount;

	@Override
	public void prepare() throws Exception {
		UserBean userBean = (UserBean) session.get(Constants.USER_BEAN);
		webDAO.beginTransaction();
		user = webDAO.getUserById(userBean.getId());
		for (Ticket ticket : user.getTickets()) {
			if (!ticket.isChecked()) {

				if (ticket.getTicketType().equals(TicketType.T_VALUE)) {
					tvalTicketCount++;
				} else if (ticket.getTicketType().equals(TicketType.DAILY)) {
					dailyTicketCount++;
				} else if (ticket.getTicketType().equals(TicketType.WEEKLY)) {
					weeklyTicketCount++;
				} else if (ticket.getTicketType()
						.equals(TicketType.MONTHLY)) {
					monthlyTicketCount++;
				}
			}
		}
		
		setBuyerAddress1(user.getCreditCardUserInfo().getAddress1());
		setBuyerAddress2(user.getCreditCardUserInfo().getAddress2());
		setBuyerFirstName(user.getCreditCardUserInfo().getFirstName());
		setBuyerLastName(user.getCreditCardUserInfo().getLastName());
		setBuyerCity(user.getCreditCardUserInfo().getCity());
		setBuyerState(user.getCreditCardUserInfo().getState());
		setBuyerZipCode(user.getCreditCardUserInfo().getZipCode());
		setCreditCardType(user.getCreditCardUserInfo().getType());
		setCreditCardNumber(user.getCreditCardUserInfo().getNumber());
		setCVV2(user.getCreditCardUserInfo().getCVV2());
		setExpMonth(user.getCreditCardUserInfo().getExpirationMonth());
		setExpYear(user.getCreditCardUserInfo().getExpirationYear());
		
		webDAO.commitTransaction();	
	}

	@Override
	public String execute() throws Exception {
		
		if(BUY_NEW_TICKETS_ATTEMPT.equals(getAttempt())){
			
			UserCreditCardInfo userCreditCardInfo = new UserCreditCardInfo();
			userCreditCardInfo.setBuyerAddress1(buyerAddress1);
			userCreditCardInfo.setBuyerAddress2(buyerAddress2);
			userCreditCardInfo.setBuyerCity(buyerCity);
			userCreditCardInfo.setCVV2(CVV2);
			userCreditCardInfo.setExpMonth(expMonth);
			userCreditCardInfo.setExpYear(expYear);
			userCreditCardInfo.setBuyerFirstName(buyerFirstName);
			userCreditCardInfo.setBuyerLastName(buyerLastName);
			userCreditCardInfo.setCreditCardNumber(creditCardNumber);
			userCreditCardInfo.setBuyerState(buyerState);
			userCreditCardInfo.setCreditCardType(creditCardType);
			userCreditCardInfo.setBuyerZipCode(buyerZipCode);
			
			PaypalModule paypalModule = new PaypalModule();
						
			int paymentAmount = ticketsCount * ApplicationSettings.T_COST;
			String msg = paypalModule.executePayment(userCreditCardInfo, String.valueOf(paymentAmount));
			
			System.out.println(msg);
			
			webDAO.beginTransaction();
			Payment payment = new Payment(user, PaymentType.PREPAID);
			webDAO.save(payment);
			
			for(int j=0;j<ticketsCount;j++){
				Ticket newTicket = new Ticket(TicketType.T_VALUE, user);
				newTicket.setPayment(payment);
				webDAO.save(newTicket);
			}
			webDAO.commitTransaction();
		
			return SUCCESS;
		} else {
			return INPUT;
		}		
	}


	public boolean isAttemptConfigUserTickets(){
		if(CONFIG_USER_TICKETS_ATTEMPT.equals(getAttempt())){
			return true;
		} else {
			return false;
		}		
	}
	
	public String getBuyerLastName() {
		return buyerLastName;
	}

	public void setBuyerLastName(String buyerLastName) {
		this.buyerLastName = buyerLastName;
	}

	public String getBuyerFirstName() {
		return buyerFirstName;
	}

	public void setBuyerFirstName(String buyerFirstName) {
		this.buyerFirstName = buyerFirstName;
	}

	public String getBuyerAddress1() {
		return buyerAddress1;
	}

	public void setBuyerAddress1(String buyerAddress1) {
		this.buyerAddress1 = buyerAddress1;
	}

	public String getBuyerAddress2() {
		return buyerAddress2;
	}

	public void setBuyerAddress2(String buyerAddress2) {
		this.buyerAddress2 = buyerAddress2;
	}

	public String getBuyerCity() {
		return buyerCity;
	}

	public void setBuyerCity(String buyerCity) {
		this.buyerCity = buyerCity;
	}

	public String getBuyerState() {
		return buyerState;
	}

	public void setBuyerState(String buyerState) {
		this.buyerState = buyerState;
	}

	public String getBuyerZipCode() {
		return buyerZipCode;
	}

	public void setBuyerZipCode(String buyerZipCode) {
		this.buyerZipCode = buyerZipCode;
	}

	public String getCreditCardType() {
		return creditCardType;
	}

	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getCVV2() {
		return CVV2;
	}

	public void setCVV2(String cVV2) {
		CVV2 = cVV2;
	}

	public int getExpMonth() {
		return expMonth;
	}

	public void setExpMonth(int expMonth) {
		this.expMonth = expMonth;
	}

	public int getExpYear() {
		return expYear;
	}

	public void setExpYear(int expYear) {
		this.expYear = expYear;
	}

	public void setTvalTicketCount(int tvalTicketCount) {
		this.tvalTicketCount = tvalTicketCount;
	}

	public void setDailyTicketCount(int dailyTicketCount) {
		this.dailyTicketCount = dailyTicketCount;
	}

	public void setWeeklyTicketCount(int weeklyTicketCount) {
		this.weeklyTicketCount = weeklyTicketCount;
	}

	public void setMonthlyTicketCount(int monthlyTicketCount) {
		this.monthlyTicketCount = monthlyTicketCount;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public int getTvalTicketCount() {
		return tvalTicketCount;
	}

	public int getDailyTicketCount() {
		return dailyTicketCount;
	}

	public int getWeeklyTicketCount() {
		return weeklyTicketCount;
	}

	public int getMonthlyTicketCount() {
		return monthlyTicketCount;
	}

	public void setTicketsCount(int ticketsCount) {
		this.ticketsCount = ticketsCount;
	}

	public int getTicketsCount() {
		return ticketsCount;
	}
}
