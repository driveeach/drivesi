/**
 * 
 */
package dsd.transport4you.dao.factories;

import javax.persistence.EntityManagerFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.PersistenceUtil;
import dsd.transport4you.dao.impl.TransportModelDAOImpl;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;

/**
 * Class is Web Application DAO Factory. Allows for easy
 * creation and access to DAO.
 * 
 * @author Dajan, Toni
 */
public class GeneralDAOFactory {
	
	protected static EntityManagerFactory emf;
	
	public static final Log log = LogFactory.getLog(GeneralDAOFactory.class);
	
	static{
		emf = PersistenceUtil.initialize();
	}
	
	
	/**
	 * Creates implementation of ITransportModelDAO.
	 * 
	 * @return implementation of ITransportModelDAO.
	 */
	public static ITransportModelDAO createITransportModelDAO() {
		return new TransportModelDAOImpl(emf);
	}

}
