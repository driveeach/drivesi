package dsd.transport4you.unit.settings;

public class Constants {

	public static final String DOORS_OPEN = "DOORS_OPEN";	
	public static final String DOORS_CLOSED = "DOORS_CLOSED";
	
	public static final String DIRECTION_FORWARD = "FORWARD";
	public static final String DIRECTION_BACKWARD = "BACKWARD";
	
	
	
}
