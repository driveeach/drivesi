package dsd.transport4you.model.user.authorization;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import dsd.transport4you.model.user.User;

/**
 * Class is an entity object.
 * @author toni, dajan
 */

@Entity
@Table(name="ROLE")
@NamedQueries({
    @NamedQuery(name="roleByName",query="SELECT r FROM Role r WHERE r.name = ?1")
})
public class Role {
	
	public static enum RoleType{
		ADMIN,
		USER
	}
	
	@Id
	@GeneratedValue
	private Integer id;
	/**
	 * Users that are in this role.
	 */
	@OneToMany(mappedBy="role")
	private Set<UserInRole> usersInRole;
	/**
	 * Role name.
	 */
	@Column(name="name",length=50,unique=true,nullable=false)
	private String name;
	
	public Role() {
		// TODO Auto-generated constructor stub
	}

	public Role(RoleType type) {
		setName(type.name());
	}
	
	@Override
	public String toString() {
		return "role "+getName();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Set<UserInRole> getUsersInRole() {
		return usersInRole;
	}

	public void setUsersInRole(Set<UserInRole> usersInRole) {
		this.usersInRole = usersInRole;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public boolean isAdminRole(){
		return RoleType.ADMIN.name().equals(getName());
	}
	
	public boolean isUserRole(){
		return RoleType.USER.name().equals(getName());
	}
	
	public Collection<User> getUsers(){
		
		Collection<User> users = new ArrayList<User>(getUsersInRole().size());
		
		for(UserInRole uir : getUsersInRole()){
			users.add(uir.getUser());
		}
		return users;
	}
}
