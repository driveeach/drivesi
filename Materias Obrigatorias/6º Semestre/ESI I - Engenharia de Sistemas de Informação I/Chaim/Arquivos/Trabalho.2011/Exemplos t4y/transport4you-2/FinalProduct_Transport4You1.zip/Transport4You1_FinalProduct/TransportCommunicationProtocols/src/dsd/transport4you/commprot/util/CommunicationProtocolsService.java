/**
 * 
 */
package dsd.transport4you.commprot.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import dsd.transport4you.interfaces.model.UserData;
import dsd.transport4you.settings.ITransportUnitUserData;

/**
 * @author dajan
 * 
 */
public class CommunicationProtocolsService {

	private static Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss Z").create();
	
	/**
	 * Checks for instance of class.
	 * 
	 * @param <D> 
	 * @param _class
	 * @return instance of class.
	 */
	public static <D> D getInstance(Class<D> _class) {
		try {
			return _class.newInstance();
		} catch (Exception _ex) {
			_ex.printStackTrace();
		}
		return null;
	}


	public static String toJSON(ITransportUnitUserData data) {

//		JSONObject userData = new JSONObject();
//		JSONArray newUsers = new JSONArray();
//		JSONArray missingUsers = new JSONArray();
//
//		for (MacAddress user : data.getNewUsers()) {
//
//			newUsers.add(user.getAddress());
//
//		}
//
//		for (MacAddress user : data.getMissingUsers()) {
//
//			missingUsers.add(user.getAddress());
//
//		}
//		userData.put("newUsers", newUsers);
//		userData.put("missingUsers", missingUsers);
//		// userData.put("gpsLocation", data.getGpsLocation());
//		JSONObject gpsLocation = new JSONObject();
//		gpsLocation.put("latitude", data.getGpsLocation().getLatitude());
//		gpsLocation.put("longitude", data.getGpsLocation().getLongitude());
//
//		userData.put("gpsLocation", gpsLocation);
//		userData.put("transportLineId", data.getTransportLineId());
//
		String jsonUser = gson.toJson(gson.toJsonTree(data));
//		System.out.println(gson.toJsonTree(data));
		
		return jsonUser;

	}

	public static ITransportUnitUserData toUserData(String userData){

//		JSONParser parser = new JSONParser();
//		JSONObject obj = (JSONObject) parser.parse(userData);
//		JSONArray newUsers = (JSONArray) obj.get("newUsers");
//		JSONArray missingUsers = (JSONArray) obj.get("missingUsers");
//		JSONObject gpsObj = (JSONObject) obj.get("gpsLocation");
//
//		double latitude = Double.parseDouble(gpsObj.get("latitude").toString());
//		double longitude = Double.parseDouble(gpsObj.get("longitude")
//				.toString());
//		int transportLineId = Integer.parseInt(obj.get("transportLineId")
//				.toString());
//
//		ITransportUnitUserData tuaUserData = UserDataFactory
//				.getTransportUserData(newUsers, missingUsers, latitude,
//						longitude, transportLineId);
		ITransportUnitUserData tuaUserData = gson.fromJson(userData, UserData.class);
	
		return tuaUserData;
	}

}
