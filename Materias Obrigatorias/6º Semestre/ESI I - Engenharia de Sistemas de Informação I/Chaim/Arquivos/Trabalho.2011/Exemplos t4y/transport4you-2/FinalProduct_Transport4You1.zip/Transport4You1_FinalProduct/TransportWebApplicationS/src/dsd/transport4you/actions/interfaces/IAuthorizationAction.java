package dsd.transport4you.actions.interfaces;

public interface IAuthorizationAction {

}
