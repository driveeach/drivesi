package dsd.transport4you.model;

public enum PaymentType{
	/**
	 * Prepayment of ticket(s).
	 */
	PREPAID,
	/**
	 * Payment of ticket through SMS service.
	 */
	SMS,
	/**
	 * Payment of ticket through credit-card service.
	 */
	ON_DEMAND,
	/**
	 * Cash payment of ticket(s).
	 */
	CASH
}
