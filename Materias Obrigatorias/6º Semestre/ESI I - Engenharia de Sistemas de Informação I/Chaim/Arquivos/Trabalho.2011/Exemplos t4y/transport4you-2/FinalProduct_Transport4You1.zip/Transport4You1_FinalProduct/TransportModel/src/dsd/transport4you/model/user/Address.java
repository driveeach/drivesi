package dsd.transport4you.model.user;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @author toni, dajan
 * 
 */
@Embeddable
public class Address {

	/**
	 * Current address.
	 */
	@Column(name="address",length=50,nullable=false)
	private String address;
	/**
	 * Current address number.
	 */
	@Column(name="addressNumber",length=50,nullable=false)
	private String addressNumber;
	/**
	 * Town.
	 */
	@Column(name="town",length=50,nullable=false)
	private String town;
	/**
	 * Post number.
	 */
	@Column(name="postNumber",length=50,nullable=false)
	private String postNumber;
	/**
	 * Country.
	 */
	@Column(name="country",length=50,nullable=false)
	private String country;
	
	public Address() {
		// TODO Auto-generated constructor stub
	}

	public Address(String address, String addressNumber, String town,
			String postNumber, String country) {
		super();
		this.address = address;
		this.addressNumber = addressNumber;
		this.town = town;
		this.postNumber = postNumber;
		this.country = country;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddressNumber() {
		return addressNumber;
	}

	public void setAddressNumber(String addressNumber) {
		this.addressNumber = addressNumber;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getPostNumber() {
		return postNumber;
	}

	public void setPostNumber(String postNumber) {
		this.postNumber = postNumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

}
