package dsd.transport4you.interfaces.util;

import dsd.transport4you.interfaces.model.GpsLocation;

public class GPSUtil {

	/**
	 * Returns the distance in meters between these two GPS locations.
	 * @param start Start GPS location
	 * @param end End GPS location
	 * @return Distance between start and end GPS location in meters
	 */
	public static double getDistance(GpsLocation start, GpsLocation end){
		return getDistance(start.getLatitude(), start.getLongitude(), end.getLatitude(), end.getLongitude());
	}
	
	/**
	 * Returns the distance in meters between these two GPS locations.
	 * @param startLatitude start GPS latitude
	 * @param startLongitude start GPS longitude
	 * @param endLatitude end GPS latitude
	 * @param endLongitude end GPD longitude
	 * @return Distance between start and end GPS location in meters
	 */
	public static double getDistance(double startLatitude,double startLongitude,double endLatitude,double endLongitude){
		double a = Math.PI / 180;
		//convert to radians
		double lat1 = startLatitude * a;
		double lat2 = endLatitude * a;
		double lon1 = startLongitude * a;
		double lon2 = endLongitude * a;
		double t1 = Math.sin(lat1) * Math.sin(lat2);
		double t2 = Math.cos(lat1) * Math.cos(lat2);
		double t3 = Math.cos(lon1 - lon2);
		double t4 = t2 * t3;
		double t5 = t1 + t4;

		double radDist = Math.atan(-t5/Math.sqrt(-t5 * t5 +1)) + 2 * Math.atan(1);

		//		miles = radian * 3437.74677 * 1.1508;
		//		km = miles * 1.6093470878864446;
		//		meter = km * 1000;

		double meterDist = radDist * 3437.74677 * 1.1508 * 1.6093470878864446 * 1000;
		return meterDist;
	}
	
	
	public static int getDistance2(double latitudeFrom, double longitudeFrom, double latitudeTo, double longitudeTo){
		
		 double lati, latj, longi, longj;
	     double q1, q2, q3, q4, q5;

	     lati = Math.PI/180.0 * latitudeFrom;
	     latj = Math.PI/180.0 * latitudeTo;

	     longi = Math.PI/180.0 * longitudeFrom;
	     longj = Math.PI/180.0 * longitudeTo;

	     q1 = Math.cos (latj) * Math.sin(longi - longj);
	     q3 = Math.sin((longi - longj)/2.0);
	     q4 = Math.cos((longi - longj)/2.0);
	     q2 = Math.sin(lati + latj) * q3 * q3 - Math.sin(lati - latj) * q4 * q4;
	     q5 = Math.cos(lati - latj) * q4 * q4 - Math.cos(lati + latj) * q3 * q3;
	     return (int) (6378388.0 * Math.atan2(Math.sqrt(q1*q1 + q2*q2), q5) + 1.0);
	}
	
}
