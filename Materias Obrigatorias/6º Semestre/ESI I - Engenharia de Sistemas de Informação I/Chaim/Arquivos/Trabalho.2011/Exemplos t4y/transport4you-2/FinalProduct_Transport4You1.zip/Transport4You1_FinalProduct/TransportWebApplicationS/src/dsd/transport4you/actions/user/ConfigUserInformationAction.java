package dsd.transport4you.actions.user;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.actions.ExtendedActionSupport;
import dsd.transport4you.actions.interfaces.IUserAction;
import dsd.transport4you.bean.UserBean;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.Constants;

public class ConfigUserInformationAction extends ExtendedActionSupport implements IUserAction{

	private static final long serialVersionUID = -4520003385905290416L;

	private static Log log = LogFactory.getLog(ConfigUserInformationAction.class);

	public final static String CONFIG_USER_INFO_ATTEMPT = "configUserInfoAttempt";

	private String username; 
	private String firstName;
	private String middleName;
	private String lastName; 
	private String email;
	private Date dateOfBirth;
	private String houseNumber; 
	private String address; 
	private String city; 
	private String postNumber;
	private String country;
	private String mobileNumber; 
	private String bluetoothMACAddress;
	private String wifiMACAddress;
	private String creditCardNumber;

	@Override
	public String execute() throws Exception {		
			log.info("Show user info");

			UserBean userBean = (UserBean)session.get(Constants.USER_BEAN);
			User user = webDAO.getUserByUserName(userBean.getUsername());

			setUsername(user.getAuthorizationInfo().getUsername());
			setFirstName(user.getPersonalUserInfo().getFirstName());
			setMiddleName(user.getPersonalUserInfo().getMiddleName());
			setLastName(user.getPersonalUserInfo().getLastName());
			setEmail(user.getPersonalUserInfo().getEmail());
			setDateOfBirth(user.getPersonalUserInfo().getDateOfBirth());
			setHouseNumber(user.getPersonalUserInfo().getAddress().getAddressNumber());
			setAddress(user.getPersonalUserInfo().getAddress().getAddress());
			setCity(user.getPersonalUserInfo().getAddress().getTown());
			setPostNumber(user.getPersonalUserInfo().getAddress().getPostNumber());
			setCountry(user.getPersonalUserInfo().getAddress().getCountry());
			setMobileNumber(user.getMobileUserInfo().getPhoneNumber());
			setBluetoothMACAddress(user.getMobileUserInfo().getBluetoothMacAddress());
			setWifiMACAddress(user.getMobileUserInfo().getWifiMacAddress());
			setCreditCardNumber(user.getCreditCardUserInfo().getNumber());
			
			return SUCCESS;
	}

	@Override
	public void validate() {

	}

	public boolean isAttemptConfigUserInfo(){
		if(CONFIG_USER_INFO_ATTEMPT.equals(getAttempt())){
			return true;
		} else {
			return false;
		}		
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostNumber() {
		return postNumber;
	}

	public void setPostNumber(String postNumber) {
		this.postNumber = postNumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getBluetoothMACAddress() {
		return bluetoothMACAddress;
	}

	public void setBluetoothMACAddress(String bluetoothMACAddress) {
		this.bluetoothMACAddress = bluetoothMACAddress;
	}

	public String getWifiMACAddress() {
		return wifiMACAddress;
	}

	public void setWifiMACAddress(String wifiMACAddress) {
		this.wifiMACAddress = wifiMACAddress;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
}
