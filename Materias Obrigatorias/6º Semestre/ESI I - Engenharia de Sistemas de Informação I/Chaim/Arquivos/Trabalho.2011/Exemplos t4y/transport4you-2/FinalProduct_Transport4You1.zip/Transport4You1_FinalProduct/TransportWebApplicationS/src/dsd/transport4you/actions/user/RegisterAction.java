package dsd.transport4you.actions.user;

import java.util.Date;

import javax.persistence.NoResultException;

import dsd.transport4you.actions.ExtendedActionSupport;
import dsd.transport4you.bean.UserBean;
import dsd.transport4you.factories.UserBeanFactory;
import dsd.transport4you.model.factories.UserFactory;
import dsd.transport4you.model.user.User;
import dsd.transport4you.model.user.authorization.Role;
import dsd.transport4you.model.user.authorization.Role.RoleType;
import dsd.transport4you.model.user.authorization.UserInRole;
import dsd.transport4you.settings.Constants;


public class RegisterAction extends ExtendedActionSupport {

	private static final long serialVersionUID = -2143798980632332363L;
	public final static String REGISTER_ATTEMPT = "registerAttempt";
	//private final String EMAIL_REGEXP = "/^([\w\!\#$\%\&\'\*\+\-\/\=\?\^\`{\|\}\~]+\.)*[\w\!\#$\%\&\'\*\+\-\/\=\?\^\`{\|\}\~]+@((((([a-z0-9]{1}[a-z0-9\-]{0,62}[a-z0-9]{1})|[a-z])\.)+[a-z]{2,6})|(\d{1,3}\.){3}\d{1,3}(\:\d{1,5})?)$/i";
	private final String EMAIL_REGEXP = ".+@.+\\.[a-z]+";
	private final String HOUSE_NUM_REGEXP = "[1-9]+[0-9]*[a-zA-Z]?";
	private final String POST_NUM_REGEXP = "[0-9a-zA-Z]+-?[0-9a-zA-Z]*";
	private final String MOBILE_NUM_REGEXP = "\\+?[0-9]{9,15}";
	private final String MAC_REGEXP = "([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}";
	private final String CREDIT_CARD_NUM_REGEXP = "[0-9]{6,15}";

	private User user;
	private UserBean userBean;

	private String username; 
	private String password;
	private String confirmPassword;
	private String firstName;
	private String middleName;
	private String lastName; 
	private String email;
	private Date dateOfBirth;
	private String houseNumber; 
	private String address; 
	private String city; 
	private String postNumber;
	private String country;
	private String mobileNumber; 
	private String bluetoothMACAddress;
	private String wifiMACAddress;

	public String execute() {
		if (REGISTER_ATTEMPT.equals(getAttempt())) {		
			try {
				user = UserFactory.createUser(firstName, middleName, lastName,
						email, username, password, address, houseNumber, city,
						postNumber, country, dateOfBirth, mobileNumber,
						bluetoothMACAddress, wifiMACAddress);
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (user != null) {

				Role userRole = webDAO.getRoleByType(RoleType.USER);
				UserInRole uir = new UserInRole(user, userRole);

				webDAO.getEntityManager().getTransaction().begin();
				webDAO.save(user);
				webDAO.save(uir);
				webDAO.getEntityManager().getTransaction().commit();
				webDAO.getEntityManager().refresh(user);

				userBean = UserBeanFactory.createUserBean(user);

				session.put(Constants.USER_BEAN, userBean);
				return SUCCESS;

			} else {
				return ERROR;
			}
		} else {
			return INPUT;
		}
	}

	@Override
	public void validate() {
		if (REGISTER_ATTEMPT.equals(getAttempt())) {
			validateUsername();
			validatePassword();
			validateConfirmPasword();
			validateFirstName();
			validateLastName();
			validateEmail();
			validateDateofBirth();
			validateHouseNumber();
			validateAddress();
			validateCity();
			validatePostNumber();
			validateCountry();
			validateMobileNumber();
			validateBluetoothMACAddress();
			validateWifiMACAddress();
		}	
	}

	/**
	 * Validates WiFi MAC address field.
	 */
	private void validateWifiMACAddress() {
		if(wifiMACAddress != null && wifiMACAddress.isEmpty()){
			addFieldError("wifiMACAddress",getText("label.wifiMACAddress")+" "+getText("errors.required"));
		} else if (wifiMACAddress != null && !wifiMACAddress.matches(MAC_REGEXP)) {
			addFieldError("wifiMACAddress", getText("label.wifiMACAddress")+" "+getText("errors.macAddress"));
		}		
	}

	/**
	 * Validates bluetooth MAC address field.
	 */
	private void validateBluetoothMACAddress() {
		if(bluetoothMACAddress != null && bluetoothMACAddress.isEmpty()){
			addFieldError("bluetoothMACAddress",getText("label.bluetoothMACAddress")+" "+getText("errors.required"));
		} else if (bluetoothMACAddress != null && !bluetoothMACAddress.matches(MAC_REGEXP)) {
			addFieldError("bluetoothMACAddress", getText("label.bluetoothMACAddress")+" "+getText("errors.macAddress"));
		}	 
	}

	/**
	 * Validates mobile number field.
	 */
	private void validateMobileNumber() {
		if(mobileNumber != null && mobileNumber.isEmpty()){
			addFieldError("mobileNumber",getText("label.mobileNumber")+" "+getText("errors.required"));
		} else if (mobileNumber != null && !mobileNumber.matches(MOBILE_NUM_REGEXP)) {
			addFieldError("mobileNumber",getText("label.mobileNumber")+" "+getText("errors.mobileNumber"));
		}
	}

	/**
	 * Validates country field.
	 */
	private void validateCountry() {
		if(country != null && country.isEmpty()){
			addFieldError("country",getText("label.country")+" "+getText("errors.required"));
		}		
	}

	/**
	 * Validates post number field.
	 */
	private void validatePostNumber() {
		if(postNumber != null && postNumber.isEmpty()){
			addFieldError("postNumber",getText("label.postNumber")+" "+getText("errors.required"));
		} else if (postNumber != null && !postNumber.matches(POST_NUM_REGEXP)) {
			addFieldError("postNumber",getText("label.postNumber")+" "+getText("errors.postNumber"));
		}		
	}

	/**
	 * Validates city field.
	 */
	private void validateCity() {
		if(city != null && city.isEmpty()){
			addFieldError("city",getText("label.city")+" "+getText("errors.required"));
		}		
	}

	/**
	 * Validates house number field.
	 */
	private void validateHouseNumber() {
		if(houseNumber != null && houseNumber.isEmpty()){
			addFieldError("houseNumber",getText("label.houseNumber")+" "+getText("errors.required"));
		} else if (houseNumber != null && !houseNumber.matches(HOUSE_NUM_REGEXP)) {
			addFieldError("houseNumber",getText("label.houseNumber")+" "+getText("errors.houseNumber"));
		}		
	}

	/**
	 * Validates address field.
	 */
	private void validateAddress() {
		if(address != null && address.isEmpty()){
			addFieldError("address",getText("label.address")+" "+getText("errors.required"));
		}			
	}

	/**
	 * Validate date of birth field. Only checks if it's not null.
	 * The rest of validation is done on the client side with javascript.
	 */
	private void validateDateofBirth() {
		if(dateOfBirth == null){
			addFieldError("dateOfBirth",getText("label.dateOfBirth")+" "+getText("errors.required"));
		}		
	}

	/**
	 * Validates email field.
	 */
	private void validateEmail() {
		if(email != null && email.isEmpty()){
			addFieldError("email",getText("label.email")+" "+getText("errors.required"));
		} else if (email != null && !email.matches(EMAIL_REGEXP)) {
			addFieldError("email",getText("label.email")+" "+getText("errors.invalid"));
		}			
	}

	/**
	 * Validates last name field.
	 */
	private void validateLastName() {
		if(lastName != null && lastName.isEmpty()){
			addFieldError("lastName",getText("label.lastName")+" "+getText("errors.required"));
		}		
	}

	/**
	 * Validate first name field.
	 */
	private void validateFirstName() {
		if(firstName != null && firstName.isEmpty()){
			addFieldError("firstName",getText("label.firstName")+" "+getText("errors.required"));
		}		
	}

	/**
	 * Validates password field.
	 */
	private void validatePassword() {
		if(password != null && password.isEmpty()){
			addFieldError("password",getText("label.password")+" "+getText("errors.required"));
		}	
	}

	/**
	 * Validates confirm password field. Has to be equals to password field.
	 */
	private void validateConfirmPasword() {
		if(confirmPassword != null && confirmPassword.isEmpty()){
			addFieldError("confirmPassword",getText("label.confirmPassword")+" "+getText("errors.required"));

		} else if(password != null && !password.isEmpty() && 
				!confirmPassword.equals(password)) {
			addFieldError("confirmPassword",getText("errors.passwordNotMatching"));
		}			
	}

	/**
	 * Validates username field.
	 */
	private void validateUsername() {
		if(username != null && username.isEmpty()){
			addFieldError("username", getText("label.username")+" "+getText("errors.required"));
		} else if (username != null) {
			User user = null;
			try {
				user = webDAO.getUserByUserName(username);
			} catch (NoResultException e) {
				//ignorable --> user is null
			}
			if(user != null){
				addFieldError("username", getText("errors.usernameExists"));
			}
		}
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostNumber() {
		return postNumber;
	}

	public void setPostNumber(String postNumber) {
		this.postNumber = postNumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getBluetoothMACAddress() {
		return bluetoothMACAddress;
	}

	public void setBluetoothMACAddress(String bluetoothMACAddress) {
		this.bluetoothMACAddress = bluetoothMACAddress;
	}

	public String getWifiMACAddress() {
		return wifiMACAddress;
	}

	public void setWifiMACAddress(String wifiMACAddress) {
		this.wifiMACAddress = wifiMACAddress;
	}
}
