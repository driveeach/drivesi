package dsd.transport4you.model.user.options;

/**
 * Payment modes.
 * 
 * @author toni, dajan
 * 
 */
public enum BillingMode {
	/**
	 * On demand payment.
	 */
	ON_DEMAND,
	/**
	 * SMS payment.
	 */
	SMS,
	/**
	 * Prepaid ticket payment.
	 */
	PREPAID
}