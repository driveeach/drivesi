package dsd.transport4you.unit.tests.unit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import dsd.transport4you.unit.dao.DatabaseMemoryImpl;
import dsd.transport4you.unit.dao.interfaces.IOperations;
import dsd.transport4you.unit.model.BluetoothAddress;
import dsd.transport4you.unit.model.WiFiAddress;

public class DatabaseMemoryImplTest {

	IOperations operations;

	@Before
	public void setUp(){
		operations = new DatabaseMemoryImpl();
	}

	@After
	public void tearDown() {
		operations = null;
	}

	@Test
	public void numberOfBluetoothAddresses(){
		String addressString = "12345";
		BluetoothAddress address = new BluetoothAddress(addressString);
		
		operations.saveBluetoothAddress(address);
		int size = operations.numberOfBluetoothAddresses();
		assertEquals("Size of BT addresses with 1 element,", 1, size);
		
		int size2 = operations.getAllBluetoothAdresses().size();
		assertEquals("Size is the same", size2, size);
		
		operations.deleteBluetoothAddress(address);
		size = operations.numberOfBluetoothAddresses();
		assertEquals("Size of BT addresses with 0 element,", 0, size);
	}

	@Test
	public void addingBluetoothAddresses(){
		
		List<BluetoothAddress> addresses = new ArrayList<BluetoothAddress>();
		
		addresses.add(new BluetoothAddress("1"));
		addresses.add(new BluetoothAddress("12"));
		addresses.add(new BluetoothAddress("123"));
		addresses.add(new BluetoothAddress("1234"));
		
		operations.saveBluetoothAddresses(addresses);
		int size = operations.numberOfBluetoothAddresses();		
		assertEquals("Size of BT addresses with 4 elements,", 4, size);
		
		operations.deleteBluetoothAddresses(addresses);
		size = operations.numberOfBluetoothAddresses();
		assertEquals("Size of BT addresses with 0 elements,", 0, size);
	}
	
	@Test
	public void equalsBluetoothAddress() {
		String addressString = "12345";
		BluetoothAddress address = new BluetoothAddress(addressString);
		operations.saveBluetoothAddress(address);
		BluetoothAddress retrievedAddress = operations.getBluetoothAddress(address);
		
		BluetoothAddress newAddress = new BluetoothAddress(addressString);
		
		assertEquals("Bluetooth adddress equals,", address, retrievedAddress);
		assertSame("Bluetooth adddress same,", address, retrievedAddress);
		assertEquals("Bluetooth adddress equals,", address, newAddress);
	}

	@Test(expected=IndexOutOfBoundsException.class)
	public void getOnEmptyBluetoothAddresses(){
		operations.getAllBluetoothAdresses().get(0);	
	}
	
	@Test
	public void numberOfWiFiAddresses(){
		String addressString = "12345";
		WiFiAddress address = new WiFiAddress(addressString);
		
		operations.saveWiFiAddress(address);
		int size = operations.numberOfWiFiAddresses();
		assertEquals("Size of WiFi addresses with 1 element,", 1, size);
		
		int size2 = operations.getAllWiFiAddresses().size();
		assertEquals("Size is the same", size2, size);
				
		operations.deleteWiFiAddress(address);
		size = operations.numberOfWiFiAddresses();
		assertEquals("Size of WiFi addresses with 0 element,", 0, size);

	}
	
	@Test
	public void addingWiFiAddresses(){
		
		List<WiFiAddress> addresses = new ArrayList<WiFiAddress>();
		
		addresses.add(new WiFiAddress("1"));
		addresses.add(new WiFiAddress("12"));
		addresses.add(new WiFiAddress("123"));
		addresses.add(new WiFiAddress("1234"));
		
		operations.saveWiFiAddresses(addresses);
		int size = operations.numberOfWiFiAddresses();		
		assertEquals("Size of BT addresses with 4 elements,", 4, size);
		
		operations.deleteWiFiAddresses(addresses);
		size = operations.numberOfWiFiAddresses();
		assertEquals("Size of BT addresses with 0 elements,", 0, size);
	}

	@Test
	public void equalsWiFiAddress() {
		String addressString = "12345";
		WiFiAddress address = new WiFiAddress(addressString);
		operations.saveWiFiAddress(address);
		WiFiAddress retrievedAddress = operations.getWiFiAddress(address);
		
		WiFiAddress newAddress = new WiFiAddress(addressString);
		
		assertEquals("WiFi adddress equals,", address, retrievedAddress);
		assertSame("WiFi adddress same,", address, retrievedAddress);
		assertEquals("WiFi adddress equals,", address, newAddress);
	}

	@Test(expected=IndexOutOfBoundsException.class)
	public void getOnEmptyWiFiAddresses(){
		operations.getAllBluetoothAdresses().get(0);	
	}
}
