package dsd.transport4you.bean;

import java.util.List;

public class TransportLineBean {

	private String name;
	private List<TransportLineStationBean> forwardTrip;
	private List<TransportLineStationBean> backwardTrip;
	public TransportLineBean(String name,
			List<TransportLineStationBean> forwardTrip,
			List<TransportLineStationBean> backwardTrip) {
		super();
		this.name = name;
		this.forwardTrip = forwardTrip;
		this.backwardTrip = backwardTrip;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<TransportLineStationBean> getForwardTrip() {
		return forwardTrip;
	}
	public void setForwardTrip(List<TransportLineStationBean> forwardTrip) {
		this.forwardTrip = forwardTrip;
	}
	public List<TransportLineStationBean> getBackwardTrip() {
		return backwardTrip;
	}
	public void setBackwardTrip(List<TransportLineStationBean> backwardTrip) {
		this.backwardTrip = backwardTrip;
	}	
}
