/**
 * 
 */
package dsd.transport4you.model.network.changes;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import dsd.transport4you.model.network.TransportLineStation;

/**
 * @author Dajan,Toni
 *
 */
@Entity
@Table(name="TRANSPORT_ROUTE_MODIFICATION")
@NamedQueries({
		@NamedQuery(name = "allRouteModifications", query = "SELECT ri FROM TransportRouteModification ri")
})
public class TransportRouteModification {

	@Id
	@GeneratedValue
	private Integer id;
	
	@ManyToOne(optional = false)
	private TransportLineStation fromStation;
	
	@ManyToOne(optional = false)
	private TransportLineStation toStation;
	
	/**
	 * Time when modification becomes actual.
	 */
	@Column(name="fromTime",unique=false,nullable=false)
	private Date fromTime;
	/**
	 * Time when modification ceases to exist.Null value signifies that current
	 * stop time is still undefined.
	 */
	@Column(name="toTime",unique=false,nullable=true)
	private Date toTime;
	
	@Column(name="stationNameList",nullable=false)
	private String stationNameList;
	
	public TransportRouteModification(){
		
	}
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}

	public TransportLineStation getFromStation() {
		return fromStation;
	}

	public TransportLineStation getToStation() {
		return toStation;
	}

	public void setFromStation(TransportLineStation fromStation) {
		this.fromStation = fromStation;
	}

	public void setToStation(TransportLineStation toStation) {
		this.toStation = toStation;
	}

	public Date getFromTime() {
		return fromTime;
	}

	public void setFromTime(Date fromTime) {
		this.fromTime = fromTime;
	}

	public Date getToTime() {
		return toTime;
	}

	public void setToTime(Date toTime) {
		this.toTime = toTime;
	}
	
	public String getStationNameList() {
		return stationNameList;
	}

	public void setStationNameList(String stationNameList) {
		this.stationNameList = stationNameList;
	}

	@Override
	public String toString() {
		return "route modification #"
				+ getFromStation().getTransportLine().getName() + " ("
				+ getFromStation().getTransportStation().getDisplayName() + ","
				+ getStationNameList() + ","
				+ getToStation().getTransportStation().getDisplayName() + ") ["
				+ getFromTime() + "-" + getToTime() + "]";
	}
}
