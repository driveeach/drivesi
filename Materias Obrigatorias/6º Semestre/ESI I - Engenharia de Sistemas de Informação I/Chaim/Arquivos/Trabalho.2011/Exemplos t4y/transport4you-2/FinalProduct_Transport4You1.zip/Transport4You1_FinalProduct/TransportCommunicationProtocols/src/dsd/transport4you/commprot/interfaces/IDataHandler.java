/**
 * 
 */
package dsd.transport4you.commprot.interfaces;

import dsd.transport4you.settings.ITransportUnitUserData;

/**
 * @author dajan
 *
 */
public interface IDataHandler {
	
	/**
	 * Sets task for handler.
	 * 
	 * @param task
	 */
	public void setTask(ITransportUnitUserData task);
	
	/**
	 * Checks if handler has task.
	 * 
	 * @return true if handler has task. Otherwise false.
	 */
	public Boolean hasTask();

}
