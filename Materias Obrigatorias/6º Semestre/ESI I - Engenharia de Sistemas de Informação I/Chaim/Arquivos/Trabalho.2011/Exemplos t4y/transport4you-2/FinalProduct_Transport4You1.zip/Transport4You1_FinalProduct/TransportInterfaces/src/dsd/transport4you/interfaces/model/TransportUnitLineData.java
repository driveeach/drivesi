package dsd.transport4you.interfaces.model;

public class TransportUnitLineData {
	
	private String transportLineName;
	private TransportLineDirection transportLineDirection;
	
	public TransportUnitLineData() {
		// TODO Auto-generated constructor stub
	}
	
	public TransportUnitLineData(String transportLineName, 
			TransportLineDirection transportLineDirection) {
		this.transportLineName = transportLineName;
		this.transportLineDirection = transportLineDirection;
	}
	
	public void setTransportLineName(String transportLineName) {
		this.transportLineName = transportLineName;
	}
	public String getTransportLineName() {
		return transportLineName;
	}
	public void setTransportLineDirection(TransportLineDirection transportLineDirection) {
		this.transportLineDirection = transportLineDirection;
	}
	public TransportLineDirection getTransportLineDirection() {
		return transportLineDirection;
	}	
	
	@Override
	public String toString() {
		return transportLineName+"-"+transportLineDirection;
	}
}
