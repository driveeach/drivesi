package dsd.transport4you.model.network;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;


/**
 * A single transport station in the public transport network.
 * Class is an entity object.
 * @author toni, dajan
 */
@Entity
@Table(name="TRANSPORT_STATION", uniqueConstraints={@UniqueConstraint(columnNames={"name","`index`"})})
public class TransportStation {

	@Id
	@GeneratedValue
	private Integer id;
	
	/**
	 * GPS location of station.
	 */
	@Embedded
	private GpsLocation gpsLocation;
	
	/**
	 * Short name of transport station.
	 */
	@Column(name="name",length=50,unique=false,nullable=false)
	private String name;

	@Column(name="`index`",length=50,unique=false,nullable=false)
	private String index;
	
	/**
	 * Full(display) name of transport station.
	 */
	@Column(name="displayName",length=50,unique=false,nullable=false)
	private String displayName;
	
	/**
	 * Set of all Transport Lines that pass through this station.
	 */
	@OneToMany(mappedBy="transportStation")
	private Set<TransportLineStation> transportLineStations;
	
	@Override
	public String toString() {
		return "station "+getName()+"-"+getIndex()+
			   " at "+getGpsLocation().toString();
	}
	
	public TransportStation() {
		// TODO Auto-generated constructor stub
	}
	
	public TransportStation(GpsLocation gpsLocation, String name,String index, String displayName) {
		setGpsLocation(gpsLocation);
		setName(name);
		setIndex(index);
		setDisplayName(displayName);
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public GpsLocation getGpsLocation() {
		return gpsLocation;
	}
	public void setGpsLocation(GpsLocation gpsLocation) {
		this.gpsLocation = gpsLocation;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public Set<TransportLineStation> getTransportLineStations() {
		return transportLineStations;
	}
	public void setTransportLineStations(Set<TransportLineStation> transportLineStations) {
		this.transportLineStations = transportLineStations;
	}
}
