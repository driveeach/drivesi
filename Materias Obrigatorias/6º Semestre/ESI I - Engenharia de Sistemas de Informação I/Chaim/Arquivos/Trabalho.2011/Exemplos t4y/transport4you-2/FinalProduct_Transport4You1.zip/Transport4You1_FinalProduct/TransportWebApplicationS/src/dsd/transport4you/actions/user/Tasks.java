package dsd.transport4you.actions.user;

import dsd.transport4you.actions.ExtendedActionSupport;
import dsd.transport4you.actions.interfaces.IAdminAction;
import dsd.transport4you.actions.interfaces.IUserAction;

public class Tasks extends ExtendedActionSupport implements IUserAction,IAdminAction{
	
	private static final long serialVersionUID = 1L;

	@Override
	public String execute() throws Exception {
		return SUCCESS;
	}
}
