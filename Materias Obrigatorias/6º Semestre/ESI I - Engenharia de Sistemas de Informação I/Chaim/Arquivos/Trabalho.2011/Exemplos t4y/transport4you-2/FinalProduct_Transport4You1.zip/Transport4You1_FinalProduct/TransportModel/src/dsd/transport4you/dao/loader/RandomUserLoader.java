/**
 * 
 */
package dsd.transport4you.dao.loader;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.model.Payment;
import dsd.transport4you.model.PaymentType;
import dsd.transport4you.model.Ticket;
import dsd.transport4you.model.Ticket.TicketType;
import dsd.transport4you.model.factories.UserFactory;
import dsd.transport4you.model.user.User;
import dsd.transport4you.model.user.authorization.Role;
import dsd.transport4you.model.user.authorization.Role.RoleType;
import dsd.transport4you.model.user.authorization.UserInRole;
import dsd.transport4you.settings.ApplicationSettings;

/**
 * @author Dajan,Toni
 *
 */
public class RandomUserLoader {
	
	public static Log log = LogFactory.getLog(RandomUserLoader.class);

	public static void main(String[] args) {
		
		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		
		generateRandomUsers(dao);
		
		dao.getEntityManager().getTransaction().commit();
		dao.close();
		
	}

	public static void generateRandomUsers(ITransportModelDAO dao) {
		
		Role userRole = dao.getRoleByType(RoleType.USER);
		Role adminRole = dao.getRoleByType(RoleType.ADMIN);
	
		int i=1;
		createUser(dao,userRole,i,"Dino","Bartošak","dino.bartosak@fer.com","+385958208454", "001F7EA90C89");	
		
		for(i = i+1; i < ApplicationSettings.DB_LOADER_USER_COUNT; i++){
			createUser(dao,userRole,i,"firstName" + i,"lastName" + i, "email" + i + "@gmail.com","phoneNumber"+i, "bluetoothMacAddress" + i);
		}
		
		User user;
		UserInRole uir;
		
		for(int j = i; j < ApplicationSettings.DB_LOADER_ADMIN_COUNT+i; j++){
			
			user = UserFactory.createUser("firstName" + j, "middleName"+j, "lastName" + j, "email" + j + "@gmail.com", "username" + j, "password" + j, "address" + j, "" + j + "", "town" + j, "10000", "Croatia", new Date(), "phoneNumber"+j, "bluetoothMacAddress" + j, "wifiMacAddress" + j);
			uir = new UserInRole(user,adminRole);
			
			dao.save(user);
			dao.save(uir);
			
			log.info("created "+user);	
		}
		
		dao.getEntityManager().refresh(userRole);
		dao.getEntityManager().refresh(adminRole);
	}

	private static void createUser(ITransportModelDAO dao,Role role,int i,String firstname,String lastname,String email,String phoneNumber,String bluetoothMac) {
		
		User user = UserFactory.createUser(firstname, null, lastname, email, "username" + i, "password" + i, "address" + i, "" + i + "", "town" + i, "10000", "Croatia", new Date(), phoneNumber,bluetoothMac, "wifiMacAddress" + i);
		UserInRole uir = new UserInRole(user,role);
		
		Payment payment = new Payment(user, PaymentType.PREPAID);
		
		dao.save(payment);
		dao.save(user);
		dao.save(uir);
		
		for(int j=0;j<ApplicationSettings.DB_LOADER_PREPAID_TICKET_COUNT;j++){
			Ticket newTicket = new Ticket(TicketType.T_VALUE,user);
			newTicket.setPayment(payment);
			dao.save(newTicket);
		}
		log.info("created "+user);
	}
	
}
