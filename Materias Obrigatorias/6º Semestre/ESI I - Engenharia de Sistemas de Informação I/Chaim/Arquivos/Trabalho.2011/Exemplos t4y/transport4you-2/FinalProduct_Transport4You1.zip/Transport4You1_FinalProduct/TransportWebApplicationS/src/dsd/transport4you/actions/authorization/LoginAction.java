package dsd.transport4you.actions.authorization;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.bean.UserBean;
import dsd.transport4you.dao.interfaces.IWebApplicationDAO;
import dsd.transport4you.factories.UserBeanFactory;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.Constants;

public class LoginAction extends AuthorizationAction{

	private static final long serialVersionUID = -7025202904193630399L;

	private static Log log = LogFactory.getLog(LoginAction.class);
	
	public final static String LOGIN_ATTEMPT = "loginAttempt";
	
	private User user;
	private UserBean userBean;

	private String username;
	private String password;
	
	private Boolean rememberMe;
	
	private String errorMsg;
	
	public String execute() {
			
		userBean = (UserBean) session.get(Constants.USER_BEAN);
		if(userBean != null) {
			return SUCCESS;
		}

		user = webDAO.getUserByAuthorization(username, password);

		if(user == null){
			setErrorMsg(getText("error.login"));
			return INPUT;

		}else{
			loginUser(user,session,httpResponse,webDAO,rememberMe);
			return SUCCESS;
		}
	}

	public static UserBean loginUser(User user,Map<String,Object> session,HttpServletResponse response,IWebApplicationDAO webDAO,Boolean rememberMe) {
		
		UserBean userBean = UserBeanFactory.createUserBean(user);
		session.put(Constants.USER_BEAN, userBean);
		
		if(rememberMe){
			user.refreshSessionTokens();
			updateSessionCookie(user,response);
			log.info("session tokens refreshed");
		}else{
			user.clearSessionTokens();
			clearSessionCookie(user,response);
			log.info("session tokens cleared");
		}
		
		webDAO.beginTransaction();
		webDAO.update(user);
		webDAO.commitTransaction();
		
		log.info("user "+userBean.getUsername()+" successfully logged in");
		return userBean;
	}

	@Override
	public void validate() {
					
		if (username == null || password == null) {
			return;
		}
		
		if(username.isEmpty() || password.isEmpty()){
			String msg = getText("error.login");
			//addFieldError("fieldError.loginError", msg);
			setErrorMsg(msg);
		}
	}

	public User getUser() {
		return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public void setRememberMe(Boolean rememberMe) {
		this.rememberMe = rememberMe;
	}
}
