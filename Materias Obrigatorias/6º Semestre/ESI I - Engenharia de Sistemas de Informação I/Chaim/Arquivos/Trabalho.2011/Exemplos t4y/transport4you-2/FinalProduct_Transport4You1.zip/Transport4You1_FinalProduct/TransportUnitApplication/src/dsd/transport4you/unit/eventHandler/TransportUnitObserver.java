package dsd.transport4you.unit.eventHandler;

import java.util.Observable;
import java.util.Observer;

import dsd.transport4you.interfaces.model.TransportLineDirection;
import dsd.transport4you.interfaces.model.TransportUnitLineData;
import dsd.transport4you.unit.dao.DatabaseMemoryImpl;
import dsd.transport4you.unit.dao.interfaces.IOperations;
import dsd.transport4you.unit.events.IDoorsClosedEvent;
import dsd.transport4you.unit.events.IDoorsOpenEvent;
import dsd.transport4you.unit.events.IUnitDirectionChangedToBackwardEvent;
import dsd.transport4you.unit.events.IUnitDirectionChangedToForwardEvent;
import dsd.transport4you.unit.modules.BluetoothModule;
import dsd.transport4you.unit.modules.GprsModule;
import dsd.transport4you.unit.modules.GpsModule;
import dsd.transport4you.unit.modules.WiFiModule;
import dsd.transport4you.unit.modules.hardware.BluetoothHardwareModule;
import dsd.transport4you.unit.modules.hardware.GprsHardwareModule;
import dsd.transport4you.unit.modules.hardware.GpsHardwareModule;
import dsd.transport4you.unit.modules.hardware.AirodumpWiFiModule;
import dsd.transport4you.unit.modules.simulators.BluetoothSimulatorModule;
import dsd.transport4you.unit.modules.simulators.GprsSimulatorModule;
import dsd.transport4you.unit.modules.simulators.GpsSimulatorModule;
import dsd.transport4you.unit.modules.simulators.WiFiSimulatorModule;
import dsd.transport4you.unit.simulator.SimulationSettings;

/**
 * Class that listens to events from transport unit and delegates them
 * 
 * @author Dino
 *
 */
public class TransportUnitObserver implements Observer  {

	private TransportUnitLineData transportUnitLineData;
	private String transportUnitId;
	
	private BluetoothModule bluetoothModule;
	private WiFiModule wiFiModule;
	private GpsModule gpsModule;
	private GprsModule gprsModule;
	
	private IOperations operations = new DatabaseMemoryImpl();

	private DetectionHandler detectionHandler;
	private Thread detectionThread;
	
	public TransportUnitObserver(String transportUnitId, TransportUnitLineData transportUnitLineData) {

		this.transportUnitId = transportUnitId;
		this.transportUnitLineData = transportUnitLineData;

		initializeModules();
	}

	@Override
	public void update(Observable o, Object caller) {
		if(caller instanceof IDoorsOpenEvent){
			if(detectionHandler != null && detectionHandler.isRunning()){
				detectionHandler.quickFinish();
			}
			
		} else if (caller instanceof IDoorsClosedEvent) {
			detectionHandler = new DetectionHandler(bluetoothModule, wiFiModule, gpsModule, gprsModule, operations, transportUnitId, transportUnitLineData);
			detectionThread = new Thread(detectionHandler);
			detectionThread.start();
			
		} else if (caller instanceof IUnitDirectionChangedToForwardEvent) {
			transportUnitLineData.setTransportLineDirection(TransportLineDirection.FORWARD);	
			
		} else if (caller instanceof IUnitDirectionChangedToBackwardEvent) {
			transportUnitLineData.setTransportLineDirection(TransportLineDirection.BACKWARD);	
		}
	}

	
	/**
	 * Initializes all transport unit's modules depending on simulation settings 
	 */
	private void initializeModules() {
		//BT module
		switch (SimulationSettings.BT_MODULE_IMPL) {
		case SimulationSettings.SIMULATOR :
			bluetoothModule = new BluetoothSimulatorModule();
			break;

		case SimulationSettings.REAL :
			bluetoothModule = new BluetoothHardwareModule();
			break;
		}

		//WiFi module
		switch (SimulationSettings.WIFI_MODULE_IMPL) {
		case SimulationSettings.SIMULATOR :
			wiFiModule = new WiFiSimulatorModule();
			break;

		case SimulationSettings.REAL :
			wiFiModule = new AirodumpWiFiModule();
			break;
		}
		
		//GPS module
		switch (SimulationSettings.GPS_MODULE_IMPL) {
		case SimulationSettings.SIMULATOR :
			gpsModule = new GpsSimulatorModule();
			break;
	
		case SimulationSettings.REAL :
			gpsModule = new GpsHardwareModule();
			break;
		}
		
		//GPRS module
		switch (SimulationSettings.GPRS_MODULE_IMPL) {
		case SimulationSettings.SIMULATOR :
			gprsModule = new GprsSimulatorModule();
			break;
	
		case SimulationSettings.REAL :
			gprsModule = new GprsHardwareModule();
			break;
		}
	}
	
	public BluetoothModule getBluetoothModule() {
		return bluetoothModule;
	}

	public WiFiModule getWiFiModule() {
		return wiFiModule;
	}

	public GpsModule getGpsModule() {
		return gpsModule;
	}
}
