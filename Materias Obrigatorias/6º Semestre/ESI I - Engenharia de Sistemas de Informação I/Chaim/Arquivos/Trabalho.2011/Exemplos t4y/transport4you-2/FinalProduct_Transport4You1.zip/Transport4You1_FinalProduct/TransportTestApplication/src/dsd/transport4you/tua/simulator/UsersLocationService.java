package dsd.transport4you.tua.simulator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import dsd.transport4you.interfaces.model.MacAddress;
import dsd.transport4you.interfaces.model.MacAddress.AddressType;
import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.network.TransportUnit;
import dsd.transport4you.model.user.User;
import dsd.transport4you.unit.simulator.SimulationSettings;

/**
 * Simulates users positions. User can be on station or in transport unit.
 * @author Dino
 *
 */
public class UsersLocationService {

	private static Random rand = new Random();
	private static Map<Integer, List<User>> usersAtStation;
	private static Map<String, List<User>> usersInTransportUnit;
	private static List<User> nonDrivingUsers;


	/**
	 * Simulates passengers exit from transport unit at station
	 * @param unitId Unit from which passengers are exiting
	 * @param stationId Station at which passengers are exiting from transport unit
	 * @param exitCount Number of passengers to exit
	 */
	public static synchronized void passengersExitUnit(String unitId, int stationId, int exitCount){
		//remove some passengers from unit
		for (int i = 0; i < exitCount && usersInTransportUnit.get(unitId).size() > 0; i++) {
			int n = rand.nextInt(usersInTransportUnit.get(unitId).size());
			usersAtStation.get(stationId).add(usersInTransportUnit.get(unitId).remove(n));
		}

		//put some passengers from station in "inactive" mode
		int inactivateCount = (int) (usersAtStation.get(stationId).size() * SimulationSettings.INACTIVATE_PASSENGERS_ON_EXIT_PERCENTAGE);
		for (int i = 0; i < inactivateCount && usersAtStation.get(stationId).size() > 0; i++) {
			int n = rand.nextInt(usersAtStation.get(stationId).size());
			nonDrivingUsers.add(usersAtStation.get(stationId).remove(n));
		}

		System.out.println(nonDrivingUsers.size()+ " NON DR"+nonDrivingUsers);
	}	

	/**
	 * Simulates passengers enter unit from station
	 * @param unitId Unit in which passengers are entering
	 * @param stationId Station from which passengers are entering transport unit
	 * @param enterCount Number of passengers to enter
	 */
	public static synchronized void passengersEnterUnit(String unitId, int stationId, int enterCount){
		//put some passengers from "inactive" mode on station
		int activateCount = (int) (usersAtStation.get(stationId).size() * SimulationSettings.ACTIVATE_PASSENGERS_ON_ENTER_PERCENTAGE);
		//if there are no passengers on station activate some 
		if(activateCount == 0){
			for (int i = 0; i < nonDrivingUsers.size(); i++) {
				if(rand.nextFloat() < SimulationSettings.ACTIVATE_PASSENGER_AT_EMPTY_STATION_PROBABILITY){
					usersAtStation.get(stationId).add(nonDrivingUsers.remove(i));					
				}
			}
		} else {
			for (int i = 0; i < activateCount && nonDrivingUsers.size() > 0; i++) {
				int n = rand.nextInt(nonDrivingUsers.size());
				usersAtStation.get(stationId).add(nonDrivingUsers.remove(n));
			}
		}

		//add passengers to unit
		for (int i = 0; i < enterCount && usersAtStation.get(stationId).size() > 0; i++) {
			int n = rand.nextInt(usersAtStation.get(stationId).size());
			usersInTransportUnit.get(unitId).add(usersAtStation.get(stationId).remove(n));
		}
	}	

	/**
	 * Reduces passengers count in transport unit by reduceCoeff of total count because unit is driving so
	 * some address were not inside unit but were in unit's range
	 * 
	 * @param unitId Unit from which passengers are "exiting"
	 * @param stationId Station at which passengers are "exiting" from transport unit
	 * @param reduceCoeff Reducing coefficient
	 */
	public static synchronized void reducePassengersCount(String unitId, int stationId, double reduceCoeff) {

		int reduceCount = (int)(usersInTransportUnit.get(unitId).size() * reduceCoeff);
		for (int i = 0; i < reduceCount && usersInTransportUnit.get(unitId).size() > 0; i++) {
			int n = rand.nextInt(usersInTransportUnit.get(unitId).size());
			usersAtStation.get(stationId).add(usersInTransportUnit.get(unitId).remove(n));
		}
	}

	/**
	 * Gets all MAC addresses in transport unit
	 * @param unitId Id of unit
	 * @return All MAC addresses in transport unit
	 */
	public static synchronized List<MacAddress> getUserMacAddressesInUnit(String unitId) {

		List<MacAddress> addresses = new ArrayList<MacAddress>();
		for (User user : usersInTransportUnit.get(unitId)) {
			addresses.add(new MacAddress(
					AddressType.WIFI, user.getMobileUserInfo().getWifiMacAddress()));
			addresses.add(new MacAddress(
					AddressType.BLUETOOTH, user.getMobileUserInfo().getBluetoothMacAddress()));

		}
		return addresses;
	}

	/**
	 * Initializes all data. Puts passengers on random stations or in "inactive" mode with 50% odds
	 * for each case. 
	 * All transport units are empty after this method return.
	 * @param users All users
	 * @param lines All lines in all networks
	 * @param units All units in all networks
	 */
	public static void initializeRandomData(List<User> users, 
			List<TransportLine> lines, List<TransportUnit> units) {		

		usersAtStation = new HashMap<Integer, List<User>>();
		usersInTransportUnit = new HashMap<String, List<User>>();

		//initialize stations
		for (TransportLine line : lines) {
			for (TransportLineStation lineStation : line.getTransportLineStationsForwardTrip()) {
				usersAtStation.put(lineStation.getTransportStation().getId(), new ArrayList<User>());
			}

			for (TransportLineStation lineStation : line.getTransportLineStationsBackwardTrip()) {
				usersAtStation.put(lineStation.getTransportStation().getId(), new ArrayList<User>());
			}
		}

		//initialize transport units
		for (TransportUnit unit : units) {
			usersInTransportUnit.put(unit.getIdentifier(), new ArrayList<User>());
		}

		//initialize non-driving users
		nonDrivingUsers = new ArrayList<User>();

		putPassengengersOnRandomStations(users);

		String s = "";
		for (Integer station : usersAtStation.keySet()) {
			s+=+station+"-"+usersAtStation.get(station)+"\n";
		}
		System.out.println(s);
	}

	/**
	 * Puts all passengers on random stations or in "inactive" mode with 50% odds for each case.
	 * @param users All passengers
	 */
	private static void putPassengengersOnRandomStations(List<User> users) {

		List<Integer> stations = new ArrayList<Integer>(usersAtStation.keySet());

		for (User user : users) {
			if (rand.nextFloat() < 0.5) {
				int n = rand.nextInt(stations.size()); //index in list
				int station = stations.get(n); //station ID value
				usersAtStation.get(station).add(user);
			} else {
				nonDrivingUsers.add(user);
			}

		}
	}
}
