package dsd.transport4you.unit.modules.wrappers;

import java.util.Set;
import java.util.concurrent.Callable;

import dsd.transport4you.unit.model.BluetoothAddress;
import dsd.transport4you.unit.modules.BluetoothModule;

public class BluetoothCallableModule implements Callable<Set<BluetoothAddress>>{

	private BluetoothModule bluetoothModule;
	
	public BluetoothCallableModule(BluetoothModule bluetoothModule){
		this.bluetoothModule = bluetoothModule;
	}

	@Override
	public Set<BluetoothAddress> call() throws Exception {
		return bluetoothModule.getAddressesInRange();
	}
}
