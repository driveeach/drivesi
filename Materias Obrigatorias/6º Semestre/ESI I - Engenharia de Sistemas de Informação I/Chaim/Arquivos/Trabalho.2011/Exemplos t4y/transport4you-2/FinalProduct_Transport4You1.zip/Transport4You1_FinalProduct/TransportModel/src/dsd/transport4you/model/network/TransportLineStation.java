package dsd.transport4you.model.network;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import dsd.transport4you.model.route.TransportRouteSection;

/**
 * Class represents a transport station on a transport line. Class is an entity
 * object.
 * 
 * @author toni, dajan
 */
@Entity
@Table(name = "TRANSPORT_LINE_STATION")
@NamedQueries({
    @NamedQuery(name="transportLineStationById",query="SELECT tl FROM TransportLineStation tl WHERE tl.id = ?1")
})
public class TransportLineStation {

	@Id
	@GeneratedValue
	private Integer id;

	/**
	 * Index of station on transport line (starts at 0).
	 */
	@Column(name = "stationNumber", nullable = false)
	private Integer stationNumber;

	/**
	 * Transport line the station is on (forward direction).
	 */
	@ManyToOne
	private TransportLine transportLineForward;

	/**
	 * Transport line the station is on (backward direction).
	 */
	@ManyToOne
	private TransportLine transportLineBackward;

	/**
	 * Transport station this represents.
	 */
	@ManyToOne(cascade = CascadeType.PERSIST)
	private TransportStation transportStation;

	/**
	 * All route sections that start at this line station.
	 */
	@OneToMany(mappedBy = "fromStation")
	private Set<TransportRouteSection> startingRouteSections;

	/**
	 * All route sections that end at this line section.
	 */
	@OneToMany(mappedBy = "toStation")
	private Set<TransportRouteSection> endingRouteSections;

	public TransportLineStation() {

	}

	public TransportLineStation(Integer stationNumber,
			TransportStation transportStation) {
		setStationNumber(stationNumber);
		setTransportStation(transportStation);
	}

	public TransportLineStation(Integer stationNumber,
			TransportStation transportStation,
			TransportLine transportLineForward,
			TransportLine transportLineBackward) {

		setStationNumber(stationNumber);
		setTransportLineForward(transportLineForward);
		setTransportLineBackward(transportLineBackward);
		setTransportStation(transportStation);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof TransportLineStation)) {
			return false;
		}
		TransportLineStation station = (TransportLineStation) obj;

		return station.getId().equals(this.getId());

	}

	@Override
	public String toString() {
		return "(" + getTransportStation().getName() + "," + getStationNumber()
				+ ")";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getStationNumber() {
		return stationNumber;
	}

	public void setStationNumber(Integer stationNumber) {
		this.stationNumber = stationNumber;
	}

	public TransportLine getTransportLineForward() {
		return transportLineForward;
	}

	public void setTransportLineForward(TransportLine transportLineForward) {
		this.transportLineForward = transportLineForward;
	}

	public TransportLine getTransportLineBackward() {
		return transportLineBackward;
	}

	public void setTransportLineBackward(TransportLine transportLineBackward) {
		this.transportLineBackward = transportLineBackward;
	}

	public TransportStation getTransportStation() {
		return transportStation;
	}

	public void setTransportStation(TransportStation transportStation) {
		this.transportStation = transportStation;
	}

	public Set<TransportRouteSection> getStartingRouteSections() {
		return startingRouteSections;
	}

	public void setStartingRouteSections(
			Set<TransportRouteSection> startingRouteSections) {
		this.startingRouteSections = startingRouteSections;
	}

	public Set<TransportRouteSection> getEndingRouteSections() {
		return endingRouteSections;
	}

	public void setEndingRouteSections(
			Set<TransportRouteSection> endingRouteSections) {
		this.endingRouteSections = endingRouteSections;
	}

	public TransportLine getTransportLine(){
		
		if(getTransportLineForward() != null){
			return getTransportLineForward();
		}else{
			return getTransportLineBackward();
		}
		
	}
	
	
	
}
