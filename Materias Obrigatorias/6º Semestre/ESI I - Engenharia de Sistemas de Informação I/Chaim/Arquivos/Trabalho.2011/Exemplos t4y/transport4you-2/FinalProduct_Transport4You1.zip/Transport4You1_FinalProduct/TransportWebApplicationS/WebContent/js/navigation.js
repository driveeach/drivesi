/**
 * Functions navigation manipulation
 * @author Dino
 */

function showSingleElement(elementId) {
	hideAll('userData');
	$('#'+elementId).css({'display' : 'inline'});
}

function hideAll(classElements){
	$('div.'+classElements).css({'display' : 'none'});
}

function showNavigationTree(navigationTree){
	$('dl.dd.newsConfig').css({'display' : 'inline'});
}