package dsd.transport4you.commprot.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class ProcessUtil {

	
	public static ProcessInfo exec(String command,String stdin,Integer timeout) throws IOException, InterruptedException {
		
		Process p = Runtime.getRuntime().exec(command);
		
		BufferedWriter stdinWriter = new BufferedWriter(new OutputStreamWriter(p.getOutputStream()));
		BufferedReader stdoutReader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		BufferedReader stderrReader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		
		if(stdin!=null){
			stdinWriter.write(stdin);
		}
		stdinWriter.close();
		
		int ret=-1;
		if(timeout==null){
			ret = p.waitFor();
		}else{
			Thread.sleep(timeout);
			p.destroy();
		}

		StringBuffer builder = new StringBuffer();
		
		String stdout="",stderr="",line;
		
		while((line=stdoutReader.readLine())!=null){
			builder.append(line);
			builder.append(System.getProperty("line.separator"));
		}
		stdout=builder.toString();
		
		builder = new StringBuffer();
		while((line=stderrReader.readLine())!=null){
			builder.append(line);
			builder.append(System.getProperty("line.separator"));
		}
		stderr=builder.toString();
		
		
		stdoutReader.close();
		stderrReader.close();
		
		ProcessInfo info = new ProcessInfo();
		info.returnValue=ret;
		info.stdout=stdout;
		info.stderr=stderr;
		return info;
	}
}
