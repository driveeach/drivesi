/**
 * 
 */
package dsd.transport4you.model.user;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Class is a value object. Class contains mobile user data.
 * 
 * @author toni, dajan
 * 
 */
@Embeddable
public class MobileUserInfo {

	/**
	 * Mobile phone number.
	 */
	@Column(name="phoneNumber",length=50,unique=true,nullable=false)
	private String phoneNumber;
	/**
	 * Mobile phone wifi mac address.
	 */
	@Column(name="wifiMacAddress",length=50,unique=true,nullable=true)
	private String wifiMacAddress;
	/**
	 * Moblie bluetooth mac address.
	 */
	@Column(name="bluetoothMacAddress",length=50,unique=true,nullable=true)
	private String bluetoothMacAddress;
	
	public MobileUserInfo() {
		// TODO Auto-generated constructor stub
	}
	
	public MobileUserInfo(String phoneNumber, String wifiMacAddress,
			String bluetoothMacAddress) {
		super();
		this.phoneNumber = phoneNumber;
		this.wifiMacAddress = wifiMacAddress;
		this.bluetoothMacAddress = bluetoothMacAddress;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getWifiMacAddress() {
		return wifiMacAddress;
	}
	public void setWifiMacAddress(String wifiMacAddress) {
		this.wifiMacAddress = wifiMacAddress;
	}
	public String getBluetoothMacAddress() {
		return bluetoothMacAddress;
	}
	public void setBluetoothMacAddress(String bluetoothMacAddress) {
		this.bluetoothMacAddress = bluetoothMacAddress;
	}

}
