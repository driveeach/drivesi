package dsd.transport4you.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import dsd.transport4you.model.factories.TransportNetworkFactory;
import dsd.transport4you.model.network.TransportNetwork;
import dsd.transport4you.util.exceptions.InvalidNetworkXMLFile;

public class TransportNetworkFactoryTest {
	
	@Before
	public void setUp(){

	}

	@After
	public void tearDown() {
	
	}
	
//	@Test()
//	public void transportNetworkCreation() throws InvalidNetworkXMLFile{
//		TransportNetwork network = TransportNetworkFactory.fromXML("network_test.xml");
//		
//		Assert.assertNotNull(network);
//		Assert.assertEquals("MyTransportNetwork",network.getName());
//		
//		Assert.assertNotNull(network.getTransportLines());
//		Assert.assertEquals(network.getTransportLines().size(),3);
//		
//		for(TransportLine line : network.getTransportLines()){
//			
//			if("1".equals(line.getName())){
//				Assert.assertEquals(line.getTransportLineStationsForwardTrip().size(), 3);
//				Assert.assertEquals(line.getTransportLineStationsBackwardTrip().size(), 3);
//			}else if("2".equals(line.getName())){
//				Assert.assertEquals(line.getTransportLineStationsForwardTrip().size(), 3);
//				Assert.assertEquals(line.getTransportLineStationsBackwardTrip().size(), 3);
//			}else if("15".equals(line.getName())){
//				Assert.assertEquals(line.getTransportLineStationsForwardTrip().size(), 2);
//				Assert.assertEquals(line.getTransportLineStationsBackwardTrip().size(), 2);
//			}else{
//				Assert.fail();
//			}
//		}
//	}

	@Test(expected=InvalidNetworkXMLFile.class)
	public void transportNetworkCreationWithMissingFile() throws InvalidNetworkXMLFile{
		TransportNetwork network = TransportNetworkFactory.fromXML("network.xml_missing");
	}
	
	@Test(expected=InvalidNetworkXMLFile.class)
	public void transportNetworkCreationWithWronglyFormattedFile() throws InvalidNetworkXMLFile{
		TransportNetwork network = TransportNetworkFactory.fromXML("network_wrong_parse.xml");
	}
	
	@Test(expected=InvalidNetworkXMLFile.class)
	public void transportNetworkCreationWithSemanticallyWrongFile1() throws InvalidNetworkXMLFile{
		TransportNetwork network = TransportNetworkFactory.fromXML("network_wrong_semantic.xml");
	}
	
	@Test(expected=InvalidNetworkXMLFile.class)
	public void transportNetworkCreationWithSemanticallyWrongFile2() throws InvalidNetworkXMLFile{
		TransportNetwork network = TransportNetworkFactory.fromXML("network_wrong_semantic2.xml");
	}
}
