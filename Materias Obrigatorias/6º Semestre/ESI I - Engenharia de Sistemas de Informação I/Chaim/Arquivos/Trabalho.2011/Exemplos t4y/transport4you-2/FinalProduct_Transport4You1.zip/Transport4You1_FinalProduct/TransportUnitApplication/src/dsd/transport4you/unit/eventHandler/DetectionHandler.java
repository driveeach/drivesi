/**
 * 
 */
package dsd.transport4you.unit.eventHandler;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

import dsd.transport4you.interfaces.model.GpsLocation;
import dsd.transport4you.interfaces.model.MacAddress;
import dsd.transport4you.interfaces.model.MacAddress.AddressType;
import dsd.transport4you.interfaces.model.TransportUnitLineData;
import dsd.transport4you.interfaces.model.UserData;
import dsd.transport4you.interfaces.util.GPSUtil;
import dsd.transport4you.unit.dao.interfaces.IOperations;
import dsd.transport4you.unit.exceptions.GPSLocationUnavailable;
import dsd.transport4you.unit.exceptions.NotEnoughLocationScansException;
import dsd.transport4you.unit.exceptions.QuickFinishDetectionException;
import dsd.transport4you.unit.model.BluetoothAddress;
import dsd.transport4you.unit.model.WiFiAddress;
import dsd.transport4you.unit.modules.BluetoothModule;
import dsd.transport4you.unit.modules.GprsModule;
import dsd.transport4you.unit.modules.GpsModule;
import dsd.transport4you.unit.modules.WiFiModule;
import dsd.transport4you.unit.modules.wrappers.BluetoothCallableModule;
import dsd.transport4you.unit.modules.wrappers.WiFiCallableModule;
import dsd.transport4you.unit.settings.Settings;

/**
 * Threaded class that detects passengers inside the transport unit
 * 
 * @author Dino
 *
 */
public class DetectionHandler implements Runnable {

	/**
	 * Database access
	 */
	private IOperations operations;
	//** modules **//
	private BluetoothCallableModule bluetoothModule;
	private WiFiCallableModule wiFiModule;
	private GpsModule gpsModule;
	private GprsModule gprsModule;

	//** unit data, line that this unit is driving and unit unique identifier **//
	private TransportUnitLineData transportUnitLineData;
	private String transportUnitId;
	/**
	 * Data to be sent to Transport Main Application (TMA)
	 */
	private UserData userData;
	/**
	 * Multiple scans per detection
	 */
	private volatile List<Set<BluetoothAddress>> bluetoothScan;
	/**
	 * Multiple scans per detection
	 */
	private volatile List<Set<WiFiAddress>> wiFiScan;	
	/**
	 * BT addresses inside Transport Unit (TU)
	 */
	private List<BluetoothAddress> bluetoothAddresses;
	/**
	 * WiFi addresses inside Transport Unit (TU)
	 */
	private List<WiFiAddress> wiFiAddresses;
	/**
	 * State of this thread
	 */
	private volatile boolean running = false;
	/**
	 * Tells if this detection has to finish
	 */
	private volatile boolean quickFinish = false;

	/**
	 * Constructor
	 * @param bluetoothModule
	 * @param wiFiModule
	 * @param gpsModule
	 * @param gprsModule
	 * @param operations
	 * @param transportUnitId
	 * @param transportUnitLineData
	 */
	public DetectionHandler(BluetoothModule bluetoothModule, WiFiModule wiFiModule,
			GpsModule gpsModule, GprsModule gprsModule, IOperations operations, String transportUnitId,
			TransportUnitLineData transportUnitLineData) {

		this.bluetoothModule = new BluetoothCallableModule(bluetoothModule);
		this.wiFiModule = new WiFiCallableModule(wiFiModule);
		this.gpsModule = gpsModule;
		this.gprsModule = gprsModule;

		this.transportUnitLineData = transportUnitLineData;
		this.transportUnitId = transportUnitId;

		this.operations = operations;

		initializeFields();
	}

	/**
	 * Initializes fields
	 */
	private void initializeFields() {

		userData = new UserData();

		bluetoothScan = new ArrayList<Set<BluetoothAddress>>();
		wiFiScan = new ArrayList<Set<WiFiAddress>>();

		bluetoothAddresses = new ArrayList<BluetoothAddress>();
		wiFiAddresses = new ArrayList<WiFiAddress>();
	}

	@Override
	public void run() {
		if(isRunning()){
			System.out.println("\tXXXX Allready doing detection XXXX ignore");
			return;
		}
		running = true;
		
		GpsLocation location = getCurrentGpsLocation();		
		userData.setGpsLocation(new GpsLocation(location.getLatitude(), location.getLongitude()));
		userData.setTimeStamp(new Date());

		try {
			smartDetectPassengers();

		} catch (NotEnoughLocationScansException e) {
			System.out.println(e.getMessage());
			running = false;
			quickFinish = false;
			return;
		}

		running = false;
		quickFinish = false;

		setUserData();
		sendDataToServer();
		updateDatabase();
	}

	/**
	 * Returns current GPS location of TU as new GpsLocation object
	 * @return Current GPS location of TU as new GpsLocation object
	 */
	private GpsLocation getCurrentGpsLocation() {
		GpsLocation location = null; 
		
		try {
			location = gpsModule.getCurrentLocation();
		} catch (GPSLocationUnavailable e) {
			e.printStackTrace();
		}

		return location;
	}

	/**
	 * Smartly detects passengers that are inside TU.
	 * @throws InterruptedException 
	 * @throws NotEnoughLocationScansException 
	 */
	private void smartDetectPassengers() throws NotEnoughLocationScansException {
		System.out.println("\t\t**** started smart detection ****");

		GpsLocation here;
		GpsLocation lastLocScan = userData.getGpsLocation();
		long now;
		long lastTimeScan = 0;

		int timeScan = 0;
		int locationScan = 0;

		while (true) {
			sleep(100);
			now = System.currentTimeMillis();
			if(now - lastTimeScan > Settings.TIME_SCAN_PERIOD * 1000){
				try {
					scanForAddressesInRange();
				} catch (QuickFinishDetectionException e) {
					if (locationScan < Settings.MIN_LOCATION_SCANS) {
						throw new NotEnoughLocationScansException("Not enough location scans");
					} else {
						break;
					}
				}
				timeScan++;
				lastTimeScan = now;
			}

			GpsLocation current = getCurrentGpsLocation();
			here = new GpsLocation(current.getLatitude(), current.getLongitude());
				
			if(here != null && lastLocScan != null && GPSUtil.getDistance(lastLocScan, here) > Settings.LOCATION_SCAN_DISTANCE){
				try {
					scanForAddressesInRange();
				} catch (QuickFinishDetectionException e) {
					if (locationScan < Settings.MIN_LOCATION_SCANS) {
						throw new NotEnoughLocationScansException("Not enough location scans");
					} else {
						break;
					}
				}
				locationScan++;
				lastLocScan = here;
			}
			
			if (timeScan >= Settings.MIN_TIME_SCANS && locationScan >= Settings.MIN_LOCATION_SCANS) {
				break;
			}
		}

		filterAddresses();

		System.out.println("\t\t---- Smart detection finished ----");
	}

	/**
	 * Sleep period in milliseconds
	 * @param sleepTime
	 */
	private void sleep(int sleepTime) {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
	}

	/**
	 * Filters addresses from multiple scans.
	 */
	private void filterAddresses() {

		Set<BluetoothAddress> bluetoothCross = bluetoothScan.get(0);
		for (int i = 1; i < bluetoothScan.size(); i++) {
			bluetoothCross.retainAll(bluetoothScan.get(i));
		}	

		Set<WiFiAddress> wiFiCross = wiFiScan.get(0);
		for (int i = 1; i < wiFiScan.size(); i++) {
			wiFiCross.retainAll(wiFiScan.get(i));
		}	

		for (BluetoothAddress address : bluetoothCross) {
			bluetoothAddresses.add(address);
		}

		for(WiFiAddress address : wiFiCross){
			wiFiAddresses.add(address);
		}
	}


	/**
	 * Sets data that will be sent to TransportMainApplication (TMA) and updates database
	 */
	private void setUserData() {
		System.out.println("Setting users data...");
		List<MacAddress> missingUsers = new ArrayList<MacAddress>();
		List<MacAddress> newUsers = new ArrayList<MacAddress>();

		//find missing users
		for (BluetoothAddress address : operations.getAllBluetoothAdresses()) {
			if(!bluetoothAddresses.contains(address)){
				missingUsers.add(new MacAddress(AddressType.BLUETOOTH, address.getAddress()));
			}
		}

		//find missing users
		for (WiFiAddress address : operations.getAllWiFiAddresses()) {
			if(!wiFiAddresses.contains(address)){
				missingUsers.add(new MacAddress(AddressType.WIFI, address.getAddress()));
			}
		}


		//find new users
		for (BluetoothAddress address : bluetoothAddresses){
			if(!operations.getAllBluetoothAdresses().contains(address)){
				newUsers.add(new MacAddress(AddressType.BLUETOOTH, address.getAddress()));
			}
		}

		//find new user
		for (WiFiAddress address : wiFiAddresses){
			if(!operations.getAllWiFiAddresses().contains(address)){
				newUsers.add(new MacAddress(AddressType.WIFI, address.getAddress()));
			}
		}

		userData.setMissingUsers(missingUsers);
		userData.setNewUsers(newUsers);
		userData.setTransportLine(transportUnitLineData);
		userData.setTransportUnitUniqueIdentifier(transportUnitId);

		System.out.println("Users data set.");
	}

	/**
	 * Updates units database
	 */
	private void updateDatabase() {
		System.out.println("Updating database...");
		for (MacAddress address : userData.getMissingUsers()) {
			if(address.getAddressType().equals(AddressType.BLUETOOTH)) {
				operations.deleteBluetoothAddress(new BluetoothAddress(address.getAddress()));
			}else if (address.getAddressType().equals(AddressType.WIFI)) {
				operations.deleteWiFiAddress(new WiFiAddress(address.getAddress()));
			}
		}

		for (MacAddress address : userData.getNewUsers()) {
			if(address.getAddressType().equals(AddressType.BLUETOOTH)) {
				operations.saveBluetoothAddress(new BluetoothAddress(address.getAddress()));
			}else if (address.getAddressType().equals(AddressType.WIFI)) {
				operations.saveWiFiAddress(new WiFiAddress(address.getAddress()));
			}
		}		
		System.out.println("Database updated.");
	}	

	/**
	 * Sends data to server (TMA)
	 */
	private void sendDataToServer() {
		System.out.println("Sending data to server... ");
		gprsModule.sendData(userData);
		System.out.println("Data sent to server.");
	}

	/**
	 * This method scans BT and WiFi addresses that are in transport units range.
	 * It scans concurrently. 
	 * @throws InterruptedException 
	 * @throws QuickFinishDetectionException 
	 */
	private void scanForAddressesInRange() throws QuickFinishDetectionException {

		Set<BluetoothAddress> bluetoothScanSet = new TreeSet<BluetoothAddress>();
		Set<WiFiAddress> wiFiScanSet = new TreeSet<WiFiAddress>();

		ExecutorService es = Executors.newFixedThreadPool(2);

		FutureTask<Set<BluetoothAddress>> bluetoothModuleTask = 
			new FutureTask<Set<BluetoothAddress>> (bluetoothModule);
		FutureTask<Set<WiFiAddress>> wiFiModuleTask = 
			new FutureTask<Set<WiFiAddress>> (wiFiModule);

		es.submit(bluetoothModuleTask);
		es.submit(wiFiModuleTask);

		try {
			bluetoothScanSet = bluetoothModuleTask.get();
		}  catch (Exception e) {
			e.printStackTrace();
		} 

		try {
			wiFiScanSet = wiFiModuleTask.get();
		} catch (Exception e) {
			e.printStackTrace();
		} 

		es.shutdown();

		if(quickFinish){
			throw new QuickFinishDetectionException("Quick finish detection, ignore last scan!");
		}

		bluetoothScan.add(bluetoothScanSet);
		wiFiScan.add(wiFiScanSet);
	}


	/**
	 * Checks if this thread is already running
	 * @return True if this thread is running, false otherwise
	 */
	public boolean isRunning() {
		return running;
	}

	/**
	 * Sets this detection to quick finish
	 */
	public void quickFinish(){
		quickFinish = true;
	}
}
