package dsd.transport4you.util.exceptions;

/**
 * Exception in the TransportModel package.
 * @author toni
 */
public class TransportModelException extends Exception {

	private static final long serialVersionUID = 1L;

	public TransportModelException(String path) {
		super(path);
	}

	public TransportModelException(Exception e) {
		super(e);
	}

}
