package dsd.transport4you;

import java.util.List;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.model.user.User;

public class PersistenceTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		
		List<User> users = dao.getUsersWithStandardRouteSections();
		System.out.println(users);
		System.out.println(users.size());
		
		dao.close();
	}

}
