/**
 * 
 */
package dsd.transport4you.unit.modules;

import java.util.Set;

import dsd.transport4you.unit.model.BluetoothAddress;

/**
 * @author Dajan
 *
 */
public abstract class BluetoothModule {
	public abstract Set<BluetoothAddress> getAddressesInRange();
}
