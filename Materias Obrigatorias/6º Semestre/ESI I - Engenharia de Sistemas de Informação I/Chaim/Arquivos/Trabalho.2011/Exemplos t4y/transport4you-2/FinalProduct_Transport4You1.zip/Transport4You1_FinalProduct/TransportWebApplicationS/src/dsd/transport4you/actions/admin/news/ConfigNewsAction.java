package dsd.transport4you.actions.admin.news;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opensymphony.xwork2.Preparable;

import dsd.transport4you.actions.ExtendedActionSupport;
import dsd.transport4you.actions.interfaces.IAdminAction;
import dsd.transport4you.bean.UserBean;
import dsd.transport4you.model.news.News;
import dsd.transport4you.model.news.NewsCategory;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.Constants;

public class ConfigNewsAction extends ExtendedActionSupport implements Preparable,IAdminAction {

	private static Log log = LogFactory.getLog(ConfigNewsAction.class);

	private static final long serialVersionUID = -4118646305782135726L;

	public final static String ADD_NEW_NEWS_ATTEMPT = "addNewNewsAttempt";
	public final static String DELETE_NEWS_ATTEMPT = "deleteNewsAttempt";
	public final static String PREPARE_UPDATE_NEWS_ATTEMPT = "prepareUpdate";
	public final static String UPDATE_NEWS_ATTEMPT = "updateNewsAttempt";

	private News news;

	private UserBean userBean;
	private User author;
	private String title;
	private String contents;
	private NewsCategory category;
	private String categoryString;
	private List<String> categoryList;
	
	/**
	 * For news editing and deleting
	 */
	private Integer newsIdToEdit;

	@Override
	public String execute() throws Exception {	

		System.out.println("Attempt and id: "+getAttempt()+" "+newsIdToEdit);
		
		if (ADD_NEW_NEWS_ATTEMPT.equals(getAttempt())) {		

			userBean = (UserBean)session.get(Constants.USER_BEAN);
			author = webDAO.getUserByUserName(userBean.getUsername());

			log.info("Author "+author+" is adding new news...");

			news = new News();
			news.setAuthor(author);
			news.setTitle(title);
			news.setContents(contents);
			setCategory();
			news.setCategory(category);
			news.setTime(new Date());

			webDAO.getEntityManager().getTransaction().begin();
			webDAO.save(news);
			webDAO.getEntityManager().getTransaction().commit();

			log.info("Author "+author+" added new news...");
			return SUCCESS;

		} else if (DELETE_NEWS_ATTEMPT.equals(getAttempt())) {
			
			webDAO.beginTransaction();
			news = webDAO.getNewsById(newsIdToEdit);
			webDAO.delete(news);
			webDAO.commitTransaction();
			
			log.info("News deleted...");
			return SUCCESS;
			
		} else if (PREPARE_UPDATE_NEWS_ATTEMPT.equals(getAttempt())) {
			
			userBean = (UserBean)session.get(Constants.USER_BEAN);
			author = webDAO.getUserByUserName(userBean.getUsername());
				
			news = webDAO.getNewsById(newsIdToEdit);
			setTitle(news.getTitle());
			setContents(news.getContents());
			
			System.out.println("prepare: "+newsIdToEdit);
			return INPUT;
			
		} else if (UPDATE_NEWS_ATTEMPT.equals(getAttempt())) {
			userBean = (UserBean)session.get(Constants.USER_BEAN);
			author = webDAO.getUserByUserName(userBean.getUsername());
				
			news = webDAO.getNewsById(newsIdToEdit);
			
			news.setAuthor(author);
			news.setTitle(title);
			news.setContents(contents);
			news.setTime(new Date());
			
			webDAO.beginTransaction();
			webDAO.update(news);
			webDAO.commitTransaction();
			
			System.out.println("prepare: "+newsIdToEdit);
			return SUCCESS;
		} else {
			if(author != null){
				log.info("Author "+author+" failed adding new news...");
			}
			return INPUT;
		}
	}

	private void setCategory() {
		if (categoryString.equals(getText("text.newsCategory.general"))) {
			setCategory(NewsCategory.GENERAL);
		} else if (categoryString.equals(getText("text.newsCategory.routeInterruption"))) {
			setCategory(NewsCategory.ROUTE_INTERRUPTION);
		} else if (categoryString.equals(getText("text.newsCategory.routeModification"))) {
			setCategory(NewsCategory.ROUTE_MODIFICATION);
		}
	}

	@Override
	public void validate() {
		if(ADD_NEW_NEWS_ATTEMPT.equals(getAttempt())){	
			validateTitle();
			validateContents();
		}
	}

	private void validateContents() {
		if(contents != null && contents.isEmpty()){
			addFieldError("contents",getText("label.contents")+" "+getText("errors.required"));
		}
	}

	private void validateTitle() {
		if(title != null && title.isEmpty()){
			addFieldError("title",getText("label.title")+" "+getText("errors.required"));
		}
	}

	public boolean isAttemptAddNewNews(){
		if(ADD_NEW_NEWS_ATTEMPT.equals(getAttempt())){
			return true;
		} else {
			return false;
		}		
	}

	public boolean isAttemptPrepareUpdate(){
		if(PREPARE_UPDATE_NEWS_ATTEMPT.equals(getAttempt())){
			return true;
		} else {
			return false;
		}	
	}
	
	public String getCategoryString() {
		return categoryString;
	}

	public void setCategoryString(String categoryString) {
		this.categoryString = categoryString;
	}

	public List<String> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<String> categoryList) {
		this.categoryList = categoryList;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public NewsCategory getCategory() {
		return category;
	}

	public void setCategory(NewsCategory category) {
		this.category = category;
	}
	
	public Integer getNewsIdToEdit() {
		return newsIdToEdit;
	}

	public void setNewsIdToEdit(Integer newsIdToEdit) {
		this.newsIdToEdit = newsIdToEdit;
	}

	@Override
	public void prepare() throws Exception {
		categoryList = new ArrayList<String>();

		categoryList.add(getText("text.newsCategory.general"));
		categoryList.add(getText("text.newsCategory.routeInterruption"));
		categoryList.add(getText("text.newsCategory.routeModification"));		
	}
}