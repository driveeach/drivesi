/**
 * 
 */
package dsd.transport4you.commprot.util.threads;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.commprot.util.CommunicationProtocolsService;
import dsd.transport4you.commprot.util.QueueSynchronized;
import dsd.transport4you.commprot.util.exceptions.TransportCommunicationProtocolsException;
import dsd.transport4you.settings.ITransportUnitUserData;

/**
 * @author dajan
 * 
 */
public class TaskReceiver implements Runnable {

	private static Log log = LogFactory.getLog(TaskReceiver.class);

	private QueueSynchronized<ITransportUnitUserData> queue;

	private String userData;
	private BufferedReader tcpReader;

	public TaskReceiver(QueueSynchronized<ITransportUnitUserData> queue,
			Socket client) {

		this.queue = queue;
		this.userData = "";
		try {
			tcpReader = new BufferedReader(new InputStreamReader(
					client.getInputStream()));
		} catch (IOException e) {
			log.error("stacktrace starts here...");
			e.printStackTrace();
			log.error("stacktrace ends here...");
		}
	}

	@Override
	public void run() {

		try {
			while (true) {

				String line = tcpReader.readLine();
				if (line == null) {
					break;
				}
				userData += line;
			}
			ITransportUnitUserData users = CommunicationProtocolsService
					.toUserData(userData);
			queue.add(users);
			log.info("added data to queue. Current size:"+queue.size());

		} catch (IOException e) {
			log.error("stacktrace starts here...");
			e.printStackTrace();
			log.error("stacktrace ends here...");
		} catch (TransportCommunicationProtocolsException e) {
			log.error("stacktrace starts here...");
			e.printStackTrace();
			log.error("stacktrace ends here...");
		}

	}

}
