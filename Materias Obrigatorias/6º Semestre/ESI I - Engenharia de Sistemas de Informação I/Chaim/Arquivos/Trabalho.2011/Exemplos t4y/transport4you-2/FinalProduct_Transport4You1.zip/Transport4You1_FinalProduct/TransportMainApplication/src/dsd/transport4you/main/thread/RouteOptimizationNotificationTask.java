package dsd.transport4you.main.thread;

import java.util.TimerTask;

public class RouteOptimizationNotificationTask extends TimerTask{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
