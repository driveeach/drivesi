package dsd.transport4you.main;

import dsd.transport4you.main.thread.StandardRouteIdentificationTask;

public class Test {

	public static void main(String[] args) {
		
		StandardRouteIdentificationTask task = new StandardRouteIdentificationTask();
		
		Thread thread = new Thread(task);
		thread.start();
		
	}
	
	
}
