package dsd.transport4you.model.network;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * A transport unit vehicle servicing passengers around the city on the public transportation network;
 * @author toni
 */
@Entity
@Table(name="TRANSPORT_UNIT")
@NamedQueries({
    @NamedQuery(name="allTransportUnits",query="SELECT tu FROM TransportUnit tu")
})
public class TransportUnit {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	@Column(name="identifier",length=50,unique=true,nullable=false)
	private String identifier;

	/**
	 * Transport layer this unit belongs to.
	 */
	@ManyToOne
	private TransportLayer transportLayer;
	
	/**
	 * Last Transport line station this unit has arrived to.
	 */
	@ManyToOne
	private TransportLineStation currentStation;
	
	/**
	 * Time when this unit arrived at current station.
	 */
	@Column(name="timeCurrentStation",unique=false,nullable=true)
	private Date timeCurrentStation;
	
	public TransportUnit() {
		// TODO Auto-generated constructor stub
	}
	
	

	public TransportUnit(String identifier, TransportLayer transportLayer) {
		this.identifier = identifier;
		this.transportLayer = transportLayer;
	}

	public Integer getId() {
		return id;
	}

	public String getIdentifier() {
		return identifier;
	}

	public TransportLineStation getCurrentStation() {
		return currentStation;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public void setCurrentStation(TransportLineStation currentStation) {
		this.currentStation = currentStation;
	}
	
	public Date getTimeCurrentStation() {
		return timeCurrentStation;
	}

	public void setTimeCurrentStation(Date timeCurrentStation) {
		this.timeCurrentStation = timeCurrentStation;
	}
	public TransportLayer getTransportLayer() {
		return transportLayer;
	}
	public void setTransportLayer(TransportLayer layer) {
		this.transportLayer = layer;
	}

	@Override
	public String toString() {
		return "transport unit "+getIdentifier();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransportUnit other = (TransportUnit) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
