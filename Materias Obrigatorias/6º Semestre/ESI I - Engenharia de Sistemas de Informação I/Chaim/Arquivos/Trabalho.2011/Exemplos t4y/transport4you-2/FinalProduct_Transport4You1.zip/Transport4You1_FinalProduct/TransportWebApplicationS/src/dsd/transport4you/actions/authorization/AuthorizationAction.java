package dsd.transport4you.actions.authorization;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletResponseAware;

import dsd.transport4you.actions.ExtendedActionSupport;
import dsd.transport4you.actions.interfaces.IAuthorizationAction;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.ApplicationSettings;
import dsd.transport4you.settings.Constants;

public class AuthorizationAction extends ExtendedActionSupport implements ServletResponseAware,IAuthorizationAction{

	private static final long serialVersionUID = 1L;
	
	protected HttpServletResponse httpResponse;
	
	public static void updateSessionCookie(User user,HttpServletResponse httpResponse){
		
		Map<String,String> data = new HashMap<String,String>();
		data.put(Constants.SESSION_TOKEN,user.getAuthorizationInfo().getSessionToken().toString());
		data.put(Constants.SESSION_HASH,user.getAuthorizationInfo().getSessionHash().toString());
		
		Cookie cookie = new Cookie(Constants.SESSION_COOKIE_NAME,gson.toJson(data));
		cookie.setMaxAge(ApplicationSettings.SESSION_COOKIE_MAX_AGE);
		httpResponse.addCookie(cookie);
	}
	
	public static void clearSessionCookie(User user,HttpServletResponse httpResponse){	
		Cookie cookie = new Cookie(Constants.SESSION_COOKIE_NAME,"-");
		cookie.setMaxAge(0);
		httpResponse.addCookie(cookie);
	}
	
	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.httpResponse=response;
	}
	

}
