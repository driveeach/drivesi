package dsd.transport4you.actions;

import java.text.SimpleDateFormat;
import java.util.Map;

import org.apache.struts2.interceptor.CookiesAware;
import org.apache.struts2.interceptor.SessionAware;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.opensymphony.xwork2.ActionSupport;

import dsd.transport4you.dao.interfaces.IWebApplicationDAO;

public class ExtendedActionSupport extends ActionSupport implements SessionAware,CookiesAware {

	private static final long serialVersionUID = -8652664275768232842L;

	public static final String NOT_LOGGED_IN = "notLoggedIn";
	public static final String NO_PERMISSION = "noPermission";
	
	private String attempt;
	protected IWebApplicationDAO webDAO;
		
	protected Map<String, Object> session;
	protected Map<String, String> cookieMap;
	
	public SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		
	public static Gson gson = new GsonBuilder().create();
	protected Object[] emptyList = new Object[0];
	
	public String getActionName() {	
		return getClass().getSimpleName();
	}
	
	public String getAttempt() {
		return attempt;
	}

	public void setAttempt(String attempt) {
		this.attempt = attempt;
	}

	public IWebApplicationDAO getWebDAO() {
		return webDAO;
	}
	
	public void setWebDAO(IWebApplicationDAO webDAO) {
		this.webDAO = webDAO;
	}
	
	public Object[] getEmptyList() {
		return emptyList;
	}

	public void setEmptyList(Object[] emptyList) {
		this.emptyList = emptyList;
	}

	@Override
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
	
	@Override
	public void setCookiesMap(Map<String, String> cookieMap) {
		this.cookieMap = cookieMap;
	}
	
	public Map<String, String> getCookieMap() {
		return cookieMap;
	}
	
	public SimpleDateFormat getDateFormat() {
		return dateFormat;
	}
}
