package dsd.transport4you.commprot.sms;

import java.util.Date;

public class SMSMessage {

	private String from;
	private String to;
	private String message;
	
	private Date time;
	
	public SMSMessage(String from, String to, String message) {
		this(from,to,message,new Date());
	}
	
	public SMSMessage(String from, String to, String message,Date time) {
		
		this.from = from;
		this.to = to;
		this.message = message;
		this.time=time;
		
		if(!(this.from==null ^ this.to==null)){
			throw new IllegalArgumentException("specify from or to number");
		}
	}
	
	public String getFrom() {
		return from;
	}
	public String getTo() {
		return to;
	}
	public String getMessage() {
		return message;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	@Override
	public String toString() {
		if(to!=null){
			return "to:"+getTo()+" msg:"+getMessage();
		}else{
			return getTime().toString()+" from:"+getFrom()+" msg:"+getMessage();
		}
	}
}
