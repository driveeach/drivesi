package dsd.transport4you.model.route;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import dsd.transport4you.model.user.User;

/**
 * A single route performed by a user on the transport network, using one or more transport lines.
 * Consist of one or more route sections.
 * Class is an entity object.
 * @author toni, dajan
 */
@Entity
@Table(name="TRANSPORT_ROUTE")

@NamedQueries({
	@NamedQuery(name = "routesToInactivate", query = "select tr from TransportRouteSection trs,TransportRoute tr " +
													 "where trs.route.id=tr.id and tr.active=1 and " +
													 "toStation_id is not null and trs.toStationTime<?1 " +
													 "group by tr.id")
})
public class TransportRoute {

	@Id
	@GeneratedValue
	private Integer id;
	/**
	 * Route sections that a user performs during this route journey.
	 */
	@OneToMany(mappedBy="route",cascade=CascadeType.ALL)
	@OrderBy(value="fromStationTime")
	private Set<TransportRouteSection> routeSections;
	/**
	 * User that performs the route.
	 */
	@ManyToOne
	private User user;
	
	/**
	 * Tells if the current route is currently still active (is the user still travelling).
	 */
	@Column(name="active",unique=false,nullable=false)
	private Boolean active;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Set<TransportRouteSection> getRouteSections() {
		return routeSections;
	}

	public void setRouteSections(Set<TransportRouteSection> routeSections) {
		this.routeSections = routeSections;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}
	

	
	@Override
	public String toString() {
		return "route- #" + getRouteSections().size();
	}
}
