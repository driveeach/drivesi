package dsd.transport4you.commprot.util.exceptions;

public class GnokiiSMSSendingException extends SMSModuleException {

	public GnokiiSMSSendingException(String string) {
		super(string);
	}

}
