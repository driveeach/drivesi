package dsd.transport4you.interceptors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

import dsd.transport4you.actions.ExtendedActionSupport;
import dsd.transport4you.dao.factories.WebApplicationDAOFactory;
import dsd.transport4you.dao.interfaces.IWebApplicationDAO;

public class DAOInterceptor implements Interceptor {

	private static final long serialVersionUID = 1438035079089582086L;
	private static Log log = LogFactory.getLog(DAOInterceptor.class);


	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void init() {
		// TODO Auto-generated method stub

	}

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		log.info("dao interceptor...");
		
		IWebApplicationDAO webDAO = WebApplicationDAOFactory.createIWebApplicationDao();
		
		Object action = invocation.getAction();
		if (action instanceof ExtendedActionSupport) {
			ExtendedActionSupport eas = (ExtendedActionSupport) invocation.getAction();
			eas.setWebDAO(webDAO);
		}
		String returnValue = invocation.invoke();
		
		webDAO.close();
		return returnValue;
	}

}
