/**
 * 
 */
package dsd.transport4you.commprot.payment.paypal;

import com.paypal.soap.api.PaymentActionCodeType;

import dsd.transport4you.commprot.payment.PaymentModule;
import dsd.transport4you.interfaces.model.UserCreditCardInfo;

/**
 * @author Dajan
 *
 */
public class PaypalModule extends PaymentModule {

	/* (non-Javadoc)
	 * @see dsd.transport4you.main.modules.PaymentModule#executePayment(dsd.transport4you.interfaces.model.UserCreditCardInfo)
	 */
	@Override
	public String executePayment(UserCreditCardInfo creditCardInfo, String paymentAmount) {
		DoDirectPayment directPayment = new DoDirectPayment();
		
		String message = directPayment.DoDirectPaymentCode(paymentAmount, creditCardInfo.buyerLastName, creditCardInfo.buyerFirstName, creditCardInfo.buyerAddress1, creditCardInfo.buyerAddress2, creditCardInfo.buyerCity, creditCardInfo.buyerState, creditCardInfo.buyerZipCode, creditCardInfo.creditCardType, creditCardInfo.creditCardNumber, creditCardInfo.CVV2, creditCardInfo.expMonth, creditCardInfo.expYear, PaymentActionCodeType.Sale);
		
		return message;
	}

}
