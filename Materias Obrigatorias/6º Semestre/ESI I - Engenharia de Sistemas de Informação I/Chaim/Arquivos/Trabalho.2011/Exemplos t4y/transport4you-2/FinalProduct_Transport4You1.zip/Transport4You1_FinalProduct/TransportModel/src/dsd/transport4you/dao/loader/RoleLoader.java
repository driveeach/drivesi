/**
 * 
 */
package dsd.transport4you.dao.loader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.IGeneralDAO;
import dsd.transport4you.model.user.authorization.Role;

/**
 * @author Dajan
 *
 */
public class RoleLoader {

	public static Log log = LogFactory.getLog(RoleLoader.class);
	
	public static void main(String[] args) {
		IGeneralDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		
		dao.getEntityManager().getTransaction().begin();

		loadRoles(dao);
		
		dao.getEntityManager().getTransaction().commit();
		dao.close();
		
	}

	public static void loadRoles(IGeneralDAO dao) {
		Role adminRole = new Role(Role.RoleType.ADMIN);
		Role userRole = new Role(Role.RoleType.USER);
		
		dao.save(adminRole);
		dao.save(userRole);
		
		log.info("created "+adminRole);
		log.info("created "+userRole);
	}
	
}
