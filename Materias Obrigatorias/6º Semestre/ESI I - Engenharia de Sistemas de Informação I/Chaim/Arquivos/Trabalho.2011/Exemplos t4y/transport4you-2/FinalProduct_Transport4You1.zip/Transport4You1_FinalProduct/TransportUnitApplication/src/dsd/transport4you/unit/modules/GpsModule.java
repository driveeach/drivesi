/**
 * 
 */
package dsd.transport4you.unit.modules;

import dsd.transport4you.interfaces.model.GpsLocation;
import dsd.transport4you.unit.exceptions.GPSLocationUnavailable;

/**
 * Class with GPS methods. Can get current GPS location.
 * 
 * @author Dino
 *
 */
public abstract class GpsModule {

	public abstract GpsLocation getCurrentLocation() throws GPSLocationUnavailable;
}
