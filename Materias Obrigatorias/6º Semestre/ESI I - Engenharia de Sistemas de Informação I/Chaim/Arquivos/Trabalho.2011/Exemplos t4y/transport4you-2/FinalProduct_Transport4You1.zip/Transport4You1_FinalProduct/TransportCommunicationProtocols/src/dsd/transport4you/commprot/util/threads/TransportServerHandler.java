/**
 * 
 */
package dsd.transport4you.commprot.util.threads;

import dsd.transport4you.commprot.interfaces.IDataHandler;
import dsd.transport4you.settings.ITransportUserDataHandlerFactory;

/**
 * @author dajan
 *
 */
public abstract class TransportServerHandler implements Runnable, IDataHandler{

	public abstract void setHandlerFactory(
			ITransportUserDataHandlerFactory handlerFactory);


	
}
