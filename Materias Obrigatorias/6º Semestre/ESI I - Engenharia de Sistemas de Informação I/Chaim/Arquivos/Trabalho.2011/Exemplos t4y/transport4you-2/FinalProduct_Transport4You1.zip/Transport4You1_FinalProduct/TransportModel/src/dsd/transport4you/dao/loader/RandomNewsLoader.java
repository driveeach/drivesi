package dsd.transport4you.dao.loader;

import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.model.news.News;
import dsd.transport4you.model.news.NewsCategory;
import dsd.transport4you.model.user.User;
import dsd.transport4you.model.user.authorization.Role;
import dsd.transport4you.model.user.authorization.Role.RoleType;

public class RandomNewsLoader {

	public static Log log = LogFactory.getLog(RandomNewsLoader.class);

	public static void main(String[] args) {

		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		
		Role adminRole = dao.getRoleByType(RoleType.ADMIN);
		List<User> adminUsers = (List<User>) adminRole.getUsers();

		System.out.println(adminUsers);
		dao.close();
	}

	public static void generateRandomNews(ITransportModelDAO dao) {

		Random rand = new Random();
		
		Role adminRole = dao.getRoleByType(RoleType.ADMIN);
		List<User> adminUsers = (List<User>) adminRole.getUsers();

		// ************ //
		NewsCategory category = NewsCategory.GENERAL;		
		User author = adminUsers.get(rand.nextInt(adminUsers.size()));	
		News news = new News();
		news.setAuthor(author);
		news.setCategory(category);
		news.setTime(new Date());
		news.setTitle("Tramlining");
		news.setContents("Tramlining is the tendency of a vehicle's wheels to follow the " +
				"contours in the surface upon which it runs. The term comes from the tendency " +
				"of a car's wheels to follow the normally recessed rails of street trams, without " +
				"driver input in the same way that the train does.");

		dao.save(news);
		log.info("created "+news);	
		// ************ //

		// ************ //
		category = NewsCategory.ROUTE_INTERRUPTION;		
		author = adminUsers.get(rand.nextInt(adminUsers.size()));	
		news = new News();
		news.setAuthor(author);
		news.setCategory(category);
		news.setTime(new Date());
		news.setTitle("Line 2 interruption");
		news.setContents("Line 2 won't be driving on Wednesday 02/16 8:00-9:30 due to presidents ceremony.");

		dao.save(news);
		log.info("created "+news);	
		// ************ //
		
		// ************ //
		category = NewsCategory.ROUTE_INTERRUPTION;		
		author = adminUsers.get(rand.nextInt(adminUsers.size()));	
		news = new News();
		news.setAuthor(author);
		news.setCategory(category);
		news.setTime(new Date());
		news.setTitle("Line 7 interruption");
		news.setContents("Line 7 won't be driving on Thursday 02/17 10:00-11:00.");

		dao.save(news);
		log.info("created "+news);	
		// ************ //
		
		// ************ //
		category = NewsCategory.ROUTE_INTERRUPTION;		
		author = adminUsers.get(rand.nextInt(adminUsers.size()));	
		news = new News();
		news.setAuthor(author);
		news.setCategory(category);
		news.setTime(new Date());
		news.setTitle("Line 6 interruption");
		news.setContents("Line 6 won't be driving on Friday 02/18 10:00-11:00 from stations Sveti Duh to Trg Bana J. Jelačića");

		dao.save(news);
		log.info("created "+news);	
		// ************ //

		
//		for(int i = 0; i < ApplicationSettings.DB_LOADER_NEWS_COUNT; i++){
//
//			News oneModificationNews = new News();
//			NewsCategory category = NewsCategory.GENERAL;
//
//			int categoryType = rand.nextInt(3);
//			switch (categoryType) {
//			case 0:
//				category = NewsCategory.GENERAL;
//				break;
//
//			case 1:
//				category = NewsCategory.ROUTE_INTERRUPTION;
//				break;
//
//			case 2:
//				category = NewsCategory.ROUTE_MODIFICATION;
//				break;
//			}
//			
//			User author = adminUsers.get(rand.nextInt(adminUsers.size()));
//			
//			oneModificationNews.setAuthor(author);
//			oneModificationNews.setCategory(category);
//			oneModificationNews.setTime(new Date());
//			oneModificationNews.setTitle("Title "+i);
//			oneModificationNews.setContents("One news contents");
//
//			dao.save(oneModificationNews);
//			log.info("created "+oneModificationNews);	
//		}
	}
}
