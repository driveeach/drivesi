/**
 * 
 */
package dsd.transport4you.unit.events;

/**
 * @author Dino4674
 *
 */
public class IDoorsOpenEvent {

}
