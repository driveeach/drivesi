package dsd.transport4you.settings;


public interface ITransportUserDataHandlerFactory {

	public ITransportUserDataHandler createTransportUserDataHandler();

}
