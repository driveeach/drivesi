package dsd.transport4you.unit.dao.interfaces;

import java.util.List;

import dsd.transport4you.unit.model.BluetoothAddress;
import dsd.transport4you.unit.model.WiFiAddress;


/**
 * Interface contains all required methods for implementation of Transport Unit
 * Application (TUA).
 * @author Dino
 *
 */
public interface IOperations {
	
	/**
	 * Saves BT address in database
	 * @param address Address to be saved
	 */
	public void saveBluetoothAddress(BluetoothAddress address);
	
	/**
	 * Gets all BT addresses currently in Transport Unit
	 */
	public List<BluetoothAddress> getAllBluetoothAdresses();
	
	/**
	 * Deletes BT address from database
	 * @param address Address to be deleted
	 */
	public void deleteBluetoothAddress(BluetoothAddress address);
	
	/**
	 * Gets required BT address from database
	 * @param address Address to be retrieved from database
	 * @return Required address
	 */
	public BluetoothAddress getBluetoothAddress(BluetoothAddress address);
	
	/**
	 * Saves BT addresses in database
	 * @param addresses Addresses to add
	 */
	public void saveBluetoothAddresses(List<BluetoothAddress> addresses);
	
	/**
	 * Deletes given BT addresses from database
	 * @param addresses Addresses to be deleted
	 */
	public void deleteBluetoothAddresses(List<BluetoothAddress> addresses);
	
	/**
	 * Gets the number of BT addresses currently in database
	 * @return Number of BT addresses in database
	 */
	public int numberOfBluetoothAddresses();
	
	/**
	 * Saves WiFi address in database
	 * @param address to be saved
	 */
	public void saveWiFiAddress(WiFiAddress address);
	
	/**
	 * Gets all WiFi addresses currently in Transport Unit
	 */
	public List<WiFiAddress> getAllWiFiAddresses();
	
	/**
	 * Deletes WiFi address from database
	 * @param address Address to be deleted
	 */
	public void deleteWiFiAddress(WiFiAddress address);
	
	/**
	 * Gets required WiFi address from database
	 * @param address Address to be retrieved from database
	 * @return Required address
	 */
	public WiFiAddress getWiFiAddress(WiFiAddress address);
	
	/**
	 * Saves WiFi addresses in database
	 * @param addresses Addresses to add
	 */
	public void saveWiFiAddresses(List<WiFiAddress> addresses);
	
	/**
	 * Deletes given WiFi addresses from database
	 * @param addresses Addresses to be deleted
	 */
	public void deleteWiFiAddresses(List<WiFiAddress> addresses);
	
	/**
	 * Gets the number of WiFi addresses currently in database
	 * @return Number of WiFi addresses in database
	 */
	public int numberOfWiFiAddresses();
	
}
