package dsd.transport4you.model.user.authorization;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import dsd.transport4you.model.user.User;

/**
 * A role that is assigned to a user.
 * Class is an entity object.
 * @author toni, dajan
 */
@Entity
@Table(name="USER_IN_ROLE")
public class UserInRole {

	@Id
	@GeneratedValue
	private Integer id;
	/**
	 * User this UserInRole refers to.
	 */
	@ManyToOne(optional=false)
	private User user;
	/**
	 * Role this UserInRole refers to.
	 */
	@ManyToOne(optional=false)
	private Role role;
	
	
	public Integer getId() {
		return id;
	}
	
	public UserInRole() {
		// TODO Auto-generated constructor stub
	}
	
	public UserInRole(User user, Role role) {
		this.user = user;
		this.role = role;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
}
