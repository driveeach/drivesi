/**
 * 
 */
package dsd.transport4you.commprot.payment;

import dsd.transport4you.interfaces.model.UserCreditCardInfo;

/**
 * @author Dajan
 *
 */
public abstract class PaymentModule {

	public abstract String executePayment(UserCreditCardInfo creditCardInfo, String paymentAmount);
	
}
