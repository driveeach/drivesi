package dsd.transport4you.unit.modules.hardware;

import java.io.IOException;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;



import dsd.transport4you.unit.model.BluetoothAddress;
import dsd.transport4you.unit.modules.BluetoothModule;

/**
 * @author Dajan
 * 
 */
public class BluetoothHardwareModule extends BluetoothModule implements
		DiscoveryListener {

	// object used for waiting
	private static Object lock = new Object();

	// vector containing the devices discovered
	@SuppressWarnings("rawtypes")
	private static Vector vecDevices = new Vector();


	// methods of DiscoveryListener

	/**
	 * This call back method will be called for each discovered bluetooth
	 * devices.
	 */
	@SuppressWarnings("unchecked")
	public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {
		System.out.println("Device discovered: "
				+ btDevice.getBluetoothAddress());
		// add the device to the vector
		if (!vecDevices.contains(btDevice)) {
			vecDevices.addElement(btDevice);
		}
	}

	// no need to implement this method since services are not being discovered
	public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {
	}

	// no need to implement this method since services are not being discovered
	public void serviceSearchCompleted(int transID, int respCode) {
	}

	/**
	 * This callback method will be called when the device discovery is
	 * completed.
	 */
	public void inquiryCompleted(int discType) {
		synchronized (lock) {
			lock.notify();
		}

		switch (discType) {
		case DiscoveryListener.INQUIRY_COMPLETED:
			System.out.println("INQUIRY_COMPLETED");
			break;

		case DiscoveryListener.INQUIRY_TERMINATED:
			System.out.println("INQUIRY_TERMINATED");
			break;

		case DiscoveryListener.INQUIRY_ERROR:
			System.out.println("INQUIRY_ERROR");
			break;

		default:
			System.out.println("Unknown Response Code");
			break;
		}
	}// end method

	@Override
	public Set<BluetoothAddress> getAddressesInRange() {

		vecDevices.clear();
		Set<BluetoothAddress> addresses = new TreeSet<BluetoothAddress>();
		// create an instance of this class
		BluetoothHardwareModule bluetoothDeviceDiscovery = new BluetoothHardwareModule();

		// display local device address and name
		LocalDevice localDevice = null;
		try {
			localDevice = LocalDevice.getLocalDevice();
		} catch (BluetoothStateException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		System.out.println("Address: " + localDevice.getBluetoothAddress());
		System.out.println("Name: " + localDevice.getFriendlyName());

		// find devices
		DiscoveryAgent agent = localDevice.getDiscoveryAgent();

		System.out.println("Starting device inquiry...");
		try {
			agent.startInquiry(DiscoveryAgent.GIAC, bluetoothDeviceDiscovery);
		} catch (BluetoothStateException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			synchronized (lock) {
				lock.wait();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("Device Inquiry Completed. ");

		// print all devices in vecDevices
		int deviceCount = vecDevices.size();

		if (deviceCount <= 0) {
			System.out.println("No Devices Found .");
		} else {
			// print bluetooth device addresses and names in the format [ No.
			// address (name) ]
			System.out.println("Bluetooth Devices: ");
			for (int i = 0; i < deviceCount; i++) {
				RemoteDevice remoteDevice = (RemoteDevice) vecDevices
						.elementAt(i);
				
				System.out.println((i + 1) + ". "
						+ remoteDevice.getBluetoothAddress());
				addresses.add(new BluetoothAddress(remoteDevice
						.getBluetoothAddress()));
		
			}
		}

		return addresses;
	}

}
