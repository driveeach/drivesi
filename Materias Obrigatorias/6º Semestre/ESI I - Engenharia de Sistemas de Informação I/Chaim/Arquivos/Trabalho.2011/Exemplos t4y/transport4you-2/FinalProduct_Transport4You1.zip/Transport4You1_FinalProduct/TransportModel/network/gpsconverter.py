import ooolib
import unohelper
import os.path

conversionfile='data/konverzija.xls'
gpsfile='data/gps.xls'

desktop = ooolib.getDesktop()

conversionfileurl = unohelper.systemPathToFileUrl(os.path.abspath(conversionfile))
conversionfiledoc = desktop.loadComponentFromURL(conversionfileurl, "_blank", 0, () )
conversionsheet = conversionfiledoc.getSheets().getByIndex(0)

gpsfileurl = unohelper.systemPathToFileUrl(os.path.abspath(gpsfile))
gpsfiledoc = desktop.loadComponentFromURL(gpsfileurl, "_blank", 0, () )
gpssheet = gpsfiledoc.getSheets().getByIndex(0)

for row in range(1,2807):
    x = gpssheet.getCellByPosition(3, row).getValue()
    y = gpssheet.getCellByPosition(4, row).getValue()
    z = gpssheet.getCellByPosition(5, row).getValue()
    print x,y,z

    if x!=0:
        conversionsheet.getCellByPosition(1,3).setValue(x)
        conversionsheet.getCellByPosition(2,3).setValue(y)
        conversionsheet.getCellByPosition(3,3).setValue(z)

        latitude=conversionsheet.getCellByPosition(6,16).getValue()
        longitude=conversionsheet.getCellByPosition(6,19).getValue()
        print latitude,longitude
        
        gpssheet.getCellByPosition(6, row).setValue(latitude)
        gpssheet.getCellByPosition(7, row).setValue(longitude)
