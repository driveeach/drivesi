///**
// * 
// */
//package dsd.transport4you.commprot.simulator;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.json.simple.parser.ParseException;
//
//import dsd.transport4you.commprot.TransportServer;
//import dsd.transport4you.commprot.factories.UserDataFactory;
//import dsd.transport4you.commprot.util.CommunicationProtocolsService;
//import dsd.transport4you.interfaces.ITransportUnitUserData;
//import dsd.transport4you.interfaces.model.UserMacAddress;
//import dsd.transport4you.interfaces.model.WiFiAddress;
//
///**
// * @author dajan
// *
// */
//public class Simulator {
//
//	/**
//	 * @param args
//	 */
//	public static void main(String[] args) {
//		List<UserMacAddress> newUsers = new ArrayList<UserMacAddress>();
//		List<UserMacAddress> missingUsers = new ArrayList<UserMacAddress>();
//		
//		newUsers.add(new WiFiAddress("dajan"));
//		newUsers.add(new WiFiAddress("dajan"));
//		
//		missingUsers.add(new WiFiAddress("dajan"));
//		missingUsers.add(new WiFiAddress("dajan"));
//		
//		ITransportUnitUserData userData = UserDataFactory.getTransportUserData(newUsers, missingUsers, 0, 0, 0);
//		
//		System.out.println(CommunicationProtocolsService.toJSON(userData));
//		
//		try {
//			ITransportUnitUserData userData1 = CommunicationProtocolsService.toUserData(CommunicationProtocolsService.toJSON(userData).toString());
//			
//			
//			
//			System.out.println(userData1.getNewUsers() + " " + userData1.getMissingUsers() + " " + userData.getGpsLocation() + " " + userData.getTransportLineId());
//		} catch (ParseException e) {
//			
//			e.printStackTrace();
//		}
//
//	}
//
//}
