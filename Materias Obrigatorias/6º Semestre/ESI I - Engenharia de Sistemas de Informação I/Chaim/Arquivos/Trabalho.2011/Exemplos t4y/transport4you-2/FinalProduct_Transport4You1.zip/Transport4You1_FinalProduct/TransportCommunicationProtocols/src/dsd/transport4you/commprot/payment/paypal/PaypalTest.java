/**
 * 
 */
package dsd.transport4you.commprot.payment.paypal;

import com.paypal.soap.api.PaymentActionCodeType;


/**
 * @author Dajan
 * 
 */
public class PaypalTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		DoDirectPayment directPayment = new DoDirectPayment();
	
		//USer credit card info.. --> fill in UserCreditCardInfo class
		String paymentAmount = "10";
//		String buyerLastName = "Dajan";
//		String buyerFirstName = "Zvekic";
		String buyerLastName = "Zvekic";
		String buyerFirstName = "Dajan"; //makes no difference
		String buyerAddress1 = "Palinovecka 37";
		String buyerAddress2 = "";
		String buyerCity = "Zagreb";
		String buyerState = "Croatia";
		String buyerZipCode = "10000";
		String creditCardType = "Visa";
		String creditCardNumber = "4937627572675122";
		String CVV2 = "000";
		int expMonth = 11;
		int expYear = 2015;
		
		
		String message = directPayment.DoDirectPaymentCode(paymentAmount, buyerLastName, buyerFirstName, buyerAddress1, buyerAddress2, buyerCity, buyerState, buyerZipCode, creditCardType, creditCardNumber, CVV2, expMonth, expYear, PaymentActionCodeType.Sale);
		System.out.println(message);
	}
}
