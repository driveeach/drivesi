package dsd.transport4you.model.user;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class AuthorizationInfo {

	/**
	 * Username.
	 */
	@Column(name = "username", length = 50, unique = true, nullable = false)
	private String username;
	/**
	 * Password. Password is encrypted with SHA1 encryption. Encrypted password
	 * is always 40 characters long.
	 */
	@Column(name = "password", length = 40, nullable = false)
	private String password;
	/**
	 * User is valid.
	 */
	@Column(name = "valid", length = 50, nullable = false)
	private Boolean valid;
	
	@Column(name = "sessionToken", length = 50, nullable = true)
	private Long sessionToken;
	
	@Column(name = "sessionHash", length = 40, nullable = true)
	private Integer sessionHash;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Boolean getValid() {
		return valid;
	}

	public void setValid(Boolean valid) {
		this.valid = valid;
	}

	public Long getSessionToken() {
		return sessionToken;
	}

	public Integer getSessionHash() {
		return sessionHash;
	}

	public void setSessionToken(Long sessionToken) {
		this.sessionToken = sessionToken;
	}

	public void setSessionHash(Integer sessionHash) {
		this.sessionHash = sessionHash;
	}
}
