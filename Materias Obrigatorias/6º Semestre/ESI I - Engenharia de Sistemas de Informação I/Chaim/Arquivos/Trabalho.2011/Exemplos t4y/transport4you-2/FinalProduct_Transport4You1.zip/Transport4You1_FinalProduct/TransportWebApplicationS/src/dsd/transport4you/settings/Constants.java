package dsd.transport4you.settings;

public class Constants {

	public static final String USER = "user";
	public static final String USER_BEAN = "userBean";

	public static final String WEB_DAO = "webDao";
	public static final String CURRENT_TASK = "currentTask";
	public static final String SESSION_TOKEN = "token";
	public static final String SESSION_HASH = "hash";
	public static final String SESSION_COOKIE_NAME = "T4You_Session";
	
}
