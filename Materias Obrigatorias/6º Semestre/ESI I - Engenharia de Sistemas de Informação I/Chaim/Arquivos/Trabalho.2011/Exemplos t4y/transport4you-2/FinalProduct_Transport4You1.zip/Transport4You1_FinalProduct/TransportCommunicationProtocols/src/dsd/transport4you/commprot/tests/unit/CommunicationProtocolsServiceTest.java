///**
// * 
// */
//package dsd.transport4you.commprot.tests.unit;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.json.simple.JSONObject;
//import org.json.simple.parser.ParseException;
//
//import dsd.transport4you.commprot.factories.UserDataFactory;
//import dsd.transport4you.commprot.util.CommunicationProtocolsService;
//import dsd.transport4you.interfaces.ITransportUnitUserData;
//import dsd.transport4you.interfaces.model.GpsLocation;
//import dsd.transport4you.interfaces.model.UserMacAddress;
//import dsd.transport4you.interfaces.model.WiFiAddress;
//import junit.framework.TestCase;
//
//
///**
// * @author Dajan
// *
// */
//public class CommunicationProtocolsServiceTest extends TestCase{
//	
//	private List<UserMacAddress> newUsers;
//	private List<UserMacAddress> missingUsers;
//	private double latitude;
//	private double longitude;
//	private int transportId;
//	JSONObject jsonObj;
//
//
//
//	@Override
//	protected void setUp() throws Exception {
//
//		newUsers = new ArrayList<UserMacAddress>();
//		missingUsers = new ArrayList<UserMacAddress>();
//
//		for (int i = 0; i < 10; i++) {
//
//			newUsers.add(new WiFiAddress(Integer.toHexString(i)));
//			missingUsers.add(new WiFiAddress(Integer.toHexString(i + 10)));
//
//		}
//
//		latitude = 50.2;
//		longitude = 24.4;
//		transportId = 5;
//		ITransportUnitUserData userData = UserDataFactory.getTransportUserData(newUsers, missingUsers, latitude, longitude, transportId);
//		jsonObj = CommunicationProtocolsService.toJSON(userData);
//
//	}
//
//	
//	public void testGetInstance(){
//		
//		GpsLocation gpsInstance = CommunicationProtocolsService.getInstance(GpsLocation.class);
//		//Integer inInstance = CommunicationProtocolsService.getInstance(Integer.class);
//		
//		assertTrue(gpsInstance instanceof GpsLocation);
//		//assertTrue(inInstance instanceof Integer);
//		
//	}
//	
////	public void testToJson(){
////		ITransportUnitUserData userData = UserDataFactory.getTransportUserData(newUsers, missingUsers, latitude, longitude, transportId);
////		
////		jsonObj = CommunicationProtocolsService.toJSON(userData);
////		assertTrue(jsonObj instanceof JSONObject);
////		
////		
////	}
//	
//	public void testToUserData(){
//		try {
//			ITransportUnitUserData userData = CommunicationProtocolsService.toUserData(jsonObj.toJSONString());
//			assertTrue(userData instanceof ITransportUnitUserData);
//		} catch (ParseException e) {
//			
//			e.printStackTrace();
//		}
//		
//		
//	}
//
//}
