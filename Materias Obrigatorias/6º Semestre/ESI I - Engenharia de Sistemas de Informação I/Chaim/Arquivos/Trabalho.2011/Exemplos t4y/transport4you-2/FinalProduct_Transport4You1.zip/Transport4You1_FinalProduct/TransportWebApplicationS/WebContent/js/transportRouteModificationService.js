/**
 * Contains method for drawing transport lines on google map and configuring
 * route modifications.
 * @author Dino
 */

/**
 * Action for fetching transport line data.
 */
var fetchLineDataAction = "FetchTransportLineData";
/**
 * Map which displays stations and lines.
 */
var map;
/**
 * Geocoder for getting address by LatLng values
 */
var geocoder;
/**
 * Directions service which renders direction (from - to GPS location). 
 */
var directionsService;
/**
 * Contains all currently showing directions.
 */
var directionsDisplayArray = [];
/**
 * Contains all currently showing stations (markers). 
 * Key: station name
 * Value: Array data[], data[0] -> station, data[1] -> marker
 */
var stationsAndMarkersMap = [];
/**
 * Contains all currently showing markers which represents new stations for modification
 */
var newStationsMarkers = [];
/**
 * FROM station id for route interruption.
 */
var fromFromStationId;
/**
 * TO station id for route interruption.
 */
var toStationId;
/**
 * New station names for route modification.
 */
var newStationNames = "";
/**
 * Number of currently selected stations.
 * Max should be 2 as FROM and TO station.
 */
var selectedStationsCount = 0;
/**
 * Holds currently selected stations/markers as IDs of TransportLineStation.
 */
var currentlySelectedStations = [];


var STATION_SELECTED_IMG = 'img/station_selected.png';
var STATION_UNSELECTED_IMG = 'img/station_unselected.png';

function initialize() {
	directionsService = new google.maps.DirectionsService();
	geocoder = new google.maps.Geocoder();

	var centerPoint = new google.maps.LatLng(45.812529,15.976868);
	var myOptions = {
			zoom: 6,
			mapTypeId: google.maps.MapTypeId.ROADMAP,
			center: centerPoint
	};
	map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);

	google.maps.event.addListener(map, 'click', function(event) {
		addNewStationMarker(event.latLng);
	});
}

/**
 * Draws transport line on google map.
 */
function drawTransportLine() {
	$("#transportLineErrorMessage").text("").show(); //delete currently showing message
	$("#transportLineMessage").text("").show(); //delete currently showing message
	
	var lineId = $('#transportLine').val();	
	fetchTransporLineFromServer(lineId);
}

/**
 * Fetches the transport line data from server
 * @param lineId Id of transport line
 */
function fetchTransporLineFromServer(lineId){
	$.getJSON(window.fetchLineDataAction,{
		transportLineId: lineId}, function (ans){
			drawLine(ans.line);
		});
}

/**
 * Adds route interruption via ajax.
 * @param errorMsg Error message to display on validation error
 */
function addRouteModification(selectedStationsErrMsg, newStationMarkersErrMsg){
	$("#transportLineErrorMessage").text("").show(); //delete currently showing message
	$("#transportLineMessage").text("").show(); //delete currently showing message
	
	if(currentlySelectedStations.length != 2){
		$("#transportLineErrorMessage").text(selectedStationsErrMsg).show().fadeOut(4000);
		return;
	} else if (getElementCountFromArray(newStationsMarkers) == 0) {
		$("#transportLineErrorMessage").text(newStationMarkersErrMsg).show().fadeOut(4000);
		return;
	} else {
		newStationNames = "";
		for ( var i in newStationsMarkers) {
			newStationNames += "#"+newStationsMarkers[i].title;
		}
		
		$('#fromStationId').val(currentlySelectedStations[0]);
		$('#toStationId').val(currentlySelectedStations[1]);		
		$('#newStationNames').val(newStationNames);		
		$("#addRouteModificationForm").submit();	
	}
}

function getElementCountFromArray(array) {
	var elemenCount = 0;
	for(var key in array){
		if(array.hasOwnProperty(key)){
			elemenCount++; 
		}	
	}

	return elemenCount;
}

/**
 * Draws one transport line.
 */
function drawLine(line){
	drawTrip(line.forwardTrip);
	//drawTrip(line.backwardTrip);
}

/**
 * Draws one transport line trip (forward or backward). Google API's limit is 10 locations
 * request so if given trip has more than 10 locations it has to be splited on parts with 10 
 * locations. 
 */
function drawTrip(trip){
	var requestsArray = [];
	for(var i = 1; i < trip.length; i++){
		var request = [];
		request[0] = trip[i - 1];
		request[1] = trip[i];

		requestsArray[i - 1] = request;
	}		

	calcRoute(requestsArray);
}

/**
 * Draws one route. 
 * @param requestsArray Array with locations. Each array has 2 elements (start and end location)
 */
function calcRoute(requestsArray) {

	deleteOverlaysAndRestartFields();

	for (var i = 0; i < requestsArray.length; i++) {
		var stations = requestsArray[i];

		var start = new google.maps.LatLng(stations[0].location.latitude, stations[0].location.longitude);
		var end = new google.maps.LatLng(stations[1].location.latitude, stations[1].location.longitude);

		var request = {
				origin: start, 
				destination: end,
				optimizeWaypoints: false,
				travelMode: google.maps.DirectionsTravelMode.WALKING,
				provideRouteAlternatives : false
		};

		directionsService.route(request, function(response, status) {
			if (status == google.maps.DirectionsStatus.OK) {

				var directionsDisplay = new	google.maps.DirectionsRenderer();
				directionsDisplayArray.push(directionsDisplay);
				directionsDisplay.suppressMarkers = true;
				directionsDisplay.setMap(map);
				directionsDisplay.setDirections(response);

				directionsDisplayArray.push(directionsDisplay);
			}
		});

		addMarker(stations[0]);
		if(i == requestsArray.length - 1){
			addMarker(stations[1]);
		}
	}
}

/**
 * Adds one marker on map on given station location.
 */
function addMarker(station){

	var image = STATION_UNSELECTED_IMG;
	if(station.selected == true){
		image = STATION_SELECTED_IMG;
	}

	var latLng = new google.maps.LatLng(station.location.latitude, station.location.longitude);
	var marker = new google.maps.Marker({
		position: latLng,
		map: map,
		animation: google.maps.Animation.DROP,
		title: station.stationName,
		icon: image
	});

	var data = [];
	data[0] = station;
	data[1] = marker;

	stationsAndMarkersMap[station.stationName] = data;

	google.maps.event.addListener(marker, 'click', function() {

		if(stationsAndMarkersMap[station.stationName][0].selected == false){
			if(selectedStationsCount < 2){
				selectedStationsCount++;
				stationsAndMarkersMap[station.stationName][0].selected = true;
				stationsAndMarkersMap[station.stationName][1].setIcon(STATION_SELECTED_IMG);
				currentlySelectedStations.push(stationsAndMarkersMap[station.stationName][0].lineStationId);
			}
		} else {
			selectedStationsCount--;
			stationsAndMarkersMap[station.stationName][0].selected = false;
			stationsAndMarkersMap[station.stationName][1].setIcon(STATION_UNSELECTED_IMG);
			removeFromArrayByValue(currentlySelectedStations, stationsAndMarkersMap[station.stationName][0].lineStationId);
			alert(currentlySelectedStations.length);
		}
	});
}

/**
 * Adds one marker on map on given station location.
 */
function addNewStationMarker(latLng){

	geocoder.geocode({'latLng': latLng}, function(results, status) {
		if (status == google.maps.GeocoderStatus.OK) {
			if (results[0]) {
				var marker = new google.maps.Marker({
					position: latLng, 
					map: map, 
					title: results[0].formatted_address
				}); 

				newStationsMarkers[results[0].formatted_address] = marker;

				google.maps.event.addListener(marker, 'click', function() {
					marker.setMap(null);
					delete newStationsMarkers[results[0].formatted_address];			
				});
			}
		} else {
			alert("Geocoder failed due to: " + status);
		}
	});
}

/**
 * Removes an item from array by given value.
 * @param array Array from which an item will be removed.
 * @param value Value of an item to be removed
 */
function removeFromArrayByValue(array, value){
	for(var i = 0; i < array.length; i++) {
		if(array[i] == value) {
			array.splice(i, 1);
			break;
		}
	}
}

/**
 * Deletes all markers and lines from map.
 * Resets fields needed for logic.
 */
function deleteOverlaysAndRestartFields(){

	if(directionsDisplayArray){
		for (i in directionsDisplayArray) {
			directionsDisplayArray[i].setMap(null);
		}
		directionsDisplayArray.length = 0;
	}

	if (stationsAndMarkersMap) {
		for (i in stationsAndMarkersMap) {
			stationsAndMarkersMap[i][1].setMap(null);
		}
		stationsAndMarkersMap.length = 0;
	}

	if (newStationsMarkers) {
		for (i in newStationsMarkers) {
			newStationsMarkers[i].setMap(null);
		}
		newStationsMarkers.length = 0;
	}

	newStationNames = "";
	currentlySelectedStations.length = 0;
	selectedStationsCount = 0;
}