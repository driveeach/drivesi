/**
 * 
 */
package dsd.transport4you.commprot.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import dsd.transport4you.commprot.util.exceptions.QueueSynchronizedEmptyException;
import dsd.transport4you.commprot.util.exceptions.QueueSynchronizedFullException;
import dsd.transport4you.commprot.util.exceptions.TransportCommunicationProtocolsException;

/**
 * @author dajan
 * 
 */
public class QueueSynchronized<E> implements Iterable<E>{

	private List<E> queue;

	private int queueSize;

	/**
	 * @param queueSize
	 */
	public QueueSynchronized(int queueSize) {

		this.queueSize = queueSize;
		this.queue = new ArrayList<E>(queueSize);
	}

	/**
	 * @param element
	 * @throws TransportCommunicationProtocolsException
	 */
	public synchronized void add(E element)
			throws TransportCommunicationProtocolsException {

		if (queue.size() == queueSize)
			throw new QueueSynchronizedFullException(
					"Can not add element to full queue.");

		queue.add(element);

	}

	/**
	 * @return
	 * @throws TransportCommunicationProtocolsException
	 */
	public synchronized E getNextTask()
			throws TransportCommunicationProtocolsException {

		if (queue.isEmpty())
			throw new QueueSynchronizedEmptyException(
					"Can not get element from empty queue");

		return queue.remove(0);

	}

	/**
	 * @return
	 */
	public synchronized Boolean isEmpty() {

		return queue.isEmpty();
	}
	
	public synchronized int size(){
		return queue.size();
	}

	@Override
	public Iterator<E> iterator() {
		
		return queue.iterator();
	}

}
