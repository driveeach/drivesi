/**
 * 
 */
package dsd.transport4you.unit.tests.modules;

import dsd.transport4you.unit.modules.hardware.BluetoothHardwareModule;

/**
 * @author Dajan
 *
 */
public class BluetoothTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		BluetoothHardwareModule module = new BluetoothHardwareModule();
		
		while(true){
			
			module.getAddressesInRange();
		}

	}

}
