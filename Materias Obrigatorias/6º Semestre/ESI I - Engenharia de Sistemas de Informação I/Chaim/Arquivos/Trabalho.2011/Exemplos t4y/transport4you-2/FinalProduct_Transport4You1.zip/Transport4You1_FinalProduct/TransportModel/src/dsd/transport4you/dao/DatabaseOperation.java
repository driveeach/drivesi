package dsd.transport4you.dao;

import javax.persistence.EntityManager;

public interface DatabaseOperation<T> {
	public T executeOperation(EntityManager em);
}