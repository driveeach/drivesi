/**
 * 
 */
package dsd.transport4you.unit.modules.hardware;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.commprot.sms.GNokiiSMSModule;
import dsd.transport4you.commprot.util.ProcessInfo;
import dsd.transport4you.commprot.util.ProcessUtil;
import dsd.transport4you.settings.ApplicationSettings;
import dsd.transport4you.unit.model.WiFiAddress;
import dsd.transport4you.unit.modules.WiFiModule;
import dsd.transport4you.unit.settings.Settings;

/**
 * Detects passengers inside the transport unit over WiFi
 * 
 * @author Dino
 *
 */
public class AirodumpWiFiModule extends WiFiModule {

	public static Log log = LogFactory.getLog(AirodumpWiFiModule.class);
	
	private int sniffTime;
	
	private String INTERFACE="wlan0";
	private String OUTPUT_FORMAT="csv";
	private String OUTPUT_FILE="/tmp/wlan.dump-01."+OUTPUT_FORMAT;
	
	private boolean DEBUG=true;
	
	private String macRegexp="([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}";
	private Pattern pattern = Pattern.compile("^("+macRegexp+"),\\s+([^,]+),\\s+([^,]+),\\s+-?\\d+,\\s+\\d+,[^,]+,[^,]*$");
	
	private static DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	public AirodumpWiFiModule() {

	}

	@Override
	public Set<WiFiAddress> getAddressesInRange() {
	
		Set<WiFiAddress> scannedAddresses = new HashSet<WiFiAddress>();
		
		log.info("started address detection");
		
		Date now = new Date();
//		System.out.println("now:"+now);
		
		try {
			Thread.sleep(Settings.WLAN_SCAN_DURATION*1000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		List<String> lines=null;
		try {
			lines = fetchLines();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(String line : lines){
			
			//00:26:82:AF:87:64, 2010-12-05 20:27:55, 2010-12-05 20:27:55, -80,        3, (not associated) , svemowlan
			
			Matcher match = pattern.matcher(line);
//			System.out.println(line);
			if(match.matches()){
//				System.out.println(match.group());
				
				String mac=match.group(1);
				String timeLastDetectedStr = match.group(4);
				Date timeLastDetected=null;
				try {
					timeLastDetected = format.parse(timeLastDetectedStr);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
//				System.out.println(timeLastDetected);
				
				if(timeLastDetected.after(now)){
//					System.out.println(mac);
//					System.out.println(timeLastDetectedStr);
					scannedAddresses.add(new WiFiAddress(mac));
				}
			}
		}
		
		log.info("finished address detection");
		
		return scannedAddresses;
	}

	private List<String> fetchLines() throws IOException {
		
		File wlanCurrent = new File("/tmp/wlan.current");

		FileUtils.copyFile(new File(OUTPUT_FILE),wlanCurrent);
		
		BufferedReader reader = new BufferedReader(new FileReader(wlanCurrent));
	
		List<String> lines = new LinkedList<String>();
		String line = reader.readLine();
		lines.add(line);
		
		while((line=reader.readLine())!=null){
			lines.add(line);
		}
	
		reader.close();
		wlanCurrent.delete();
		
		return lines;
	}

	public static void main(String[] args) {
		
		WiFiModule mod = new AirodumpWiFiModule();
		
		while(true){
			System.out.println(mod.getAddressesInRange());
		}
	}
	
}
