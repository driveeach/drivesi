package dsd.transport4you.dao.interfaces;

import java.util.Collection;
import java.util.List;

import dsd.transport4you.interfaces.model.TransportLineDirection;
import dsd.transport4you.model.Ticket;
import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.network.TransportUnit;
import dsd.transport4you.model.network.changes.TransportRouteInterruption;
import dsd.transport4you.model.network.changes.TransportRouteModification;
import dsd.transport4you.model.route.TransportRoute;
import dsd.transport4you.model.user.User;


/**
 * Interface contains all required methods for implementation of Transport Model.
 * @author Toni
 */
public interface ITransportModelDAO extends IGeneralDAO{

	public Collection<User> getAllUsers();
	public User getUserByBluetoothMacAddress(String macAddress);
	public User getUserByWiFiMacAddress(String macAddress);
	public TransportLineStation getNearestTransportLineStation(double longitude, double latitude, String transportLineName, TransportLineDirection direction);
	public TransportLine getTransportLineByName(String name);
	public List<TransportLine> getAllTransportLines();
	public List<Ticket> getUncheckedTickets(Integer id);
	public List<TransportRoute> getTransportRoutesToInactivate(Integer inactivationTime);
	public List<User> getUsersWithExpiredTicket();
	public List<TransportUnit> getAllTransportUnits();
	public User getUserByPhoneNumber(String phoneNumber);
	
	public List<User> getUsersWithStandardRouteSections();
	public List<TransportRouteInterruption> getTransportRouteInterruptions();
	public List<TransportRouteModification> getTransportRouteModifications();
}
