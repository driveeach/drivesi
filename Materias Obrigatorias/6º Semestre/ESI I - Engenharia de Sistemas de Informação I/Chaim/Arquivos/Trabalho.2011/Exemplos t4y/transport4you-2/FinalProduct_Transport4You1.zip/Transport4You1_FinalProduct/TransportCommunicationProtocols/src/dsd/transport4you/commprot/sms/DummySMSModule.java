package dsd.transport4you.commprot.sms;

import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DummySMSModule extends SMSModule {

	public static Log log = LogFactory.getLog(DummySMSModule.class);
	
	@Override
	public void sendMessage(SMSMessage msg) {
		log.info("sending message: "+msg);
	}

	@Override
	public List<SMSMessage> getNewMessages() {
		log.info("no messages to receive");
		return new LinkedList<SMSMessage>();
	}

}
