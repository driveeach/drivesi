package dsd.transport4you.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import dsd.transport4you.model.user.User;

/**
 * A payment of one or more tickets done by a user.
 * Class is an entity object.
 * @author toni, dajan
 */
@Entity
@Table(name="PAYMENT")
public class Payment {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	/**
	 * User that has executed this payment.
	 */
	@ManyToOne
	private User user;
	
	/**
	 * The type of payment this instance is.
	 */
	@Enumerated
	private PaymentType paymentType;
	
	/**
	 * Time when this payment occured.
	 */
	@Column(name="time",unique=false,nullable=false)
	private Date time;
	
	/**
	 * Tickets that are purchased with this payment.
	 */
	@OneToMany(mappedBy="payment")
	private Set<Ticket> tickets;
	
	public Payment() {
		// TODO Auto-generated constructor stub
	}
	
	public Payment(User user,PaymentType type) {
		this(user,type,new Date());
	}
	
	public Payment(User user,PaymentType type,Date time) {
		this.user = user;
		this.paymentType = type;
		this.time=time;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Set<Ticket> getTickets() {
		return tickets;
	}
	public void setTickets(Set<Ticket> tickets) {
		this.tickets = tickets;
	}

	public PaymentType getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}
}
