package dsd.transport4you.settings;


public interface ITransportUserDataHandler {

	public void handle(ITransportUnitUserData data);
}
