package dsd.transport4you.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import dsd.transport4you.model.network.TransportLayer.TransportLayerType;
import dsd.transport4you.model.network.TransportLine;

public class TransportLayerBean {

	
	private List<TransportLine> transportLines;
	private TransportLayerType type;
	
	public TransportLayerBean(Set<TransportLine> transportLines,
			TransportLayerType type) {
		this.transportLines = new ArrayList<TransportLine>(transportLines);
		this.type = type;
	}
	public List<TransportLine> getTransportLines() {
		return transportLines;
	}
	public void setTransportLines(List<TransportLine> transportLines) {
		this.transportLines = transportLines;
	}
	public TransportLayerType getType() {
		return type;
	}
	public void setType(TransportLayerType type) {
		this.type = type;
	}		
}
