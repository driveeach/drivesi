/**
 * 
 */
package dsd.transport4you.unit.modules.hardware;

import dsd.transport4you.interfaces.model.GpsLocation;
import dsd.transport4you.unit.modules.GpsModule;

/**
 * Class with GPS methods. Can get current GPS location.
 * 
 * @author Dino
 *
 */
public class GpsHardwareModule extends GpsModule{

	@Override
	public GpsLocation getCurrentLocation() {
		return null;
	}


}
