package dsd.transport4you.model.factories.xml;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import dsd.transport4you.model.network.GpsLocation;
import dsd.transport4you.model.network.TransportLayer;
import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.network.TransportNetwork;
import dsd.transport4you.model.network.TransportStation;
import dsd.transport4you.model.network.TransportLayer.TransportLayerType;
import dsd.transport4you.util.exceptions.InvalidNetworkXMLFile;

/**
 * Class implements deserialization from xml file to TransportNetwork hierarchy.
 * @author toni
 */
public class TransportNetworkXMLDeserializer {

	private XPath xpath;
	private Document doc;

	private Map<String,TransportStation> transportStationMap;
	private TransportNetwork transportNetwork;
	
	public TransportNetworkXMLDeserializer(String path) throws InvalidNetworkXMLFile {
		
	    DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
	    domFactory.setNamespaceAware(true); // never forget this!
	    DocumentBuilder builder;
		try {
			builder = domFactory.newDocumentBuilder();
			this.doc = builder.parse(path);
		} catch (ParserConfigurationException e) {
			throw new InvalidNetworkXMLFile(e);
		} catch (SAXException e) {
			throw new InvalidNetworkXMLFile(e);
		} catch (IOException e) {
			throw new InvalidNetworkXMLFile(e);
		}
	    
	    XPathFactory factory = XPathFactory.newInstance();
	    this.xpath = factory.newXPath();
	}
	
	/**
	 * Deserializer xml file to TransportNetwork object.
	 * @return the created transport network object.
	 * @throws InvalidNetworkXMLFile in case of any problem with the xml file. 
	 */
	public TransportNetwork deserialize() throws InvalidNetworkXMLFile{
		
		try {
			createTransportNetwork();
			createTransportStationMap();
			this.transportNetwork.setTransportLayers(createTransportLayers());
		} catch (Exception e) {
			throw new InvalidNetworkXMLFile(e);
		}

		return this.transportNetwork;
	}
	
	private void createTransportNetwork() {
		String transportNetworkName = (String) doQuery("/transport-network/@name",XPathConstants.STRING);
		this.transportNetwork=new TransportNetwork(transportNetworkName);
	}

	private Set<TransportLayer> createTransportLayers(){
		
		Set<TransportLayer> transportLayers = new HashSet<TransportLayer>();
		NodeList transportLayerNodes = (NodeList) doQuery("/transport-network/transport-layers/transport-layer",XPathConstants.NODESET);
		
		for (int i = 0; i < transportLayerNodes.getLength(); i++) {
			
			Node transportLayerNode=transportLayerNodes.item(i);
			String typeValue = transportLayerNode.getAttributes().getNamedItem("type").getNodeValue().toUpperCase();
			TransportLayerType type = TransportLayerType.valueOf(typeValue);
			
			TransportLayer layer = new TransportLayer(this.transportNetwork,type);
			layer.setTransportLines(createTransportLines(layer));
			
			transportLayers.add(layer);
		}
		
		return transportLayers;
	}
	
	private Set<TransportLine> createTransportLines(TransportLayer layer) {
		
		Set<TransportLine> transportLines=new HashSet<TransportLine>();

		String xpathToLine = "/transport-network/transport-layers/transport-layer" +
							 "[@type=\""+ layer.getType().name().toLowerCase()+ "\"]" +
							 "/transport-lines/transport-line";

	    NodeList transportLineNodes = (NodeList) doQuery(xpathToLine,XPathConstants.NODESET);
	    
	    for (int i = 0; i < transportLineNodes.getLength(); i++) {
	    	Node transportStationNode=transportLineNodes.item(i);
	        String transportLineName = (String)transportStationNode.getAttributes().getNamedItem("name").getNodeValue();
	        TransportLine transportLine = new TransportLine(transportLineName,layer);
	        
	        NodeList forwardTransportStationList = (NodeList) doQuery(xpathToLine+"[@name=\""+transportLineName+"\"]/forward-transport-stations/transport-station",XPathConstants.NODESET);
	        NodeList backwardTransportStationList = (NodeList) doQuery(xpathToLine+"[@name=\""+transportLineName+"\"]/backward-transport-stations/transport-station",XPathConstants.NODESET);
	        
	        Set<TransportLineStation> transportLineStationsForwardTrip = new HashSet<TransportLineStation>();
	        Set<TransportLineStation> transportLineStationsBackwardTrip = new HashSet<TransportLineStation>();
	        
	        int stationNumber=0;
	        for (int j = 0; j < forwardTransportStationList.getLength(); j++) {
	        	TransportStation station = nodeToTransportStation(forwardTransportStationList.item(j));
	        	TransportLineStation lineStation = new TransportLineStation(stationNumber++,station,transportLine,null);
	        	transportLineStationsForwardTrip.add(lineStation);
	        }
	        
	        stationNumber=0;
	        for (int j = 0; j < backwardTransportStationList.getLength(); j++) {    	
	        	TransportStation station = nodeToTransportStation(backwardTransportStationList.item(j));
	        	TransportLineStation lineStation = new TransportLineStation(stationNumber++,station,null,transportLine);
	        	transportLineStationsBackwardTrip.add(lineStation);
	        }
	        
	        transportLine.setTransportLineStationsForwardTrip(transportLineStationsForwardTrip);
	        transportLine.setTransportLineStationsBackwardTrip(transportLineStationsBackwardTrip);
	        
	        transportLines.add(transportLine);
	    }
	    
	    return transportLines;
	}

	private TransportStation nodeToTransportStation(Node n) {
		String stationName = n.getAttributes().getNamedItem("name").getNodeValue();
		String stationIndex = n.getAttributes().getNamedItem("index").getNodeValue();
		TransportStation station = this.transportStationMap.get(stationName+"-"+stationIndex);
		return station;
	}

	private void createTransportStationMap(){
		
		this.transportStationMap=new HashMap<String, TransportStation>();

	    NodeList transportStationNodes = (NodeList) doQuery("/transport-network/transport-stations/transport-station",XPathConstants.NODESET);
	    
	    for (int i = 0; i < transportStationNodes.getLength(); i++) {
	    	Node transportStationNode=transportStationNodes.item(i);
	        String name = (String)transportStationNode.getAttributes().getNamedItem("name").getNodeValue();
	        String index = (String)transportStationNode.getAttributes().getNamedItem("index").getNodeValue();
	        
	        String displayName = (String)doQuery("/transport-network/transport-stations/transport-station[@name=\""+name+"\"]/display-name",XPathConstants.STRING);
	        
	        Double latitude = Double.valueOf((String) doQuery("/transport-network/transport-stations/transport-station[@name=\""+name+"\"]/gps-location/latitude",XPathConstants.STRING));
	        Double longitude = Double.valueOf((String) doQuery("/transport-network/transport-stations/transport-station[@name=\""+name+"\"]/gps-location/longitude",XPathConstants.STRING));
	        GpsLocation gpsLocation = new GpsLocation(latitude, longitude);
	        
	        TransportStation station = new TransportStation(gpsLocation,name,index,displayName);
	        this.transportStationMap.put(name+"-"+index,station);
	    }
	}
	
	private Object doQuery(String query,QName type){
	    XPathExpression expr;
	    Object result = null;
	    
		try {
//			query="/transport-network/transport-stations/transport-station[@name=\"Dom 'Svetog Josipa'\"]/gps-location/latitude";
//			System.out.println(query);
			expr = xpath.compile(query);
			result = expr.evaluate(doc,type);
		} catch (XPathExpressionException e) {
			//ignorable
			e.printStackTrace();
		}
		return result;
	}
}
