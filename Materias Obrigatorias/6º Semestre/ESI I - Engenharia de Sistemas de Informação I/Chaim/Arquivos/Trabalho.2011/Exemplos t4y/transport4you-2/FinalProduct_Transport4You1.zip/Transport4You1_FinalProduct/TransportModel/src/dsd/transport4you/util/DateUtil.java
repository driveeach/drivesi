package dsd.transport4you.util;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateUtil {

	public static Date floor(Date time){
		Calendar cal = (Calendar) GregorianCalendar.getInstance();
		cal.setTime(time);
		cal=new GregorianCalendar(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH));
		return cal.getTime();
	}
	
	public static Date add(int field,int amount,Date time){
		Calendar cal = (Calendar) GregorianCalendar.getInstance();
		cal.setTime(time);
		cal.add(field, amount);
		return cal.getTime();
	}
}
