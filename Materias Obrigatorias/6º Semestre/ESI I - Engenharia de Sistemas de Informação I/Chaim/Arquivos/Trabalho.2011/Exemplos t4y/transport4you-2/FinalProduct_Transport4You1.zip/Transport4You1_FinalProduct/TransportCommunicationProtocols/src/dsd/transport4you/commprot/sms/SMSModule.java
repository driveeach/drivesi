package dsd.transport4you.commprot.sms;

import java.util.List;

import dsd.transport4you.commprot.util.exceptions.SMSModuleException;

public abstract class SMSModule {

	public abstract void sendMessage(SMSMessage msg) throws SMSModuleException;
	public abstract List<SMSMessage> getNewMessages();
	
}
