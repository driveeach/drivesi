package dsd.transport4you.unit.modules.simulators;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import dsd.transport4you.unit.model.BluetoothAddress;
import dsd.transport4you.unit.modules.BluetoothModule;
import dsd.transport4you.unit.simulator.SimulationSettings;

/**
 * Detects passengers inside the transport unit over BT
 * 
 * @author Dino
 *
 */
public class BluetoothSimulatorModule extends BluetoothModule {

	public List<BluetoothAddress> bluetoothAddresses;

	public BluetoothSimulatorModule() {
		this.bluetoothAddresses = Collections.synchronizedList(new ArrayList<BluetoothAddress>());
	}
	
	@Override
	public Set<BluetoothAddress> getAddressesInRange() {

		Set<BluetoothAddress> addressesInRange;
		synchronized (bluetoothAddresses) {
			addressesInRange = new TreeSet<BluetoothAddress>(bluetoothAddresses);
		}
	
		try {
			Thread.sleep((long)(SimulationSettings.getBtDetectionTime() * 1000));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		return addressesInRange;
	}
	
	/**
	 * Sets addresses in range of this module
	 * @param addressesInRange Addresses that are in range of this module
	 */
	public void setAddressesInRange(List<BluetoothAddress> addressesInRange){
		synchronized (bluetoothAddresses) {
			bluetoothAddresses.removeAll(bluetoothAddresses);
			bluetoothAddresses.addAll(addressesInRange);
		}
	}
}
