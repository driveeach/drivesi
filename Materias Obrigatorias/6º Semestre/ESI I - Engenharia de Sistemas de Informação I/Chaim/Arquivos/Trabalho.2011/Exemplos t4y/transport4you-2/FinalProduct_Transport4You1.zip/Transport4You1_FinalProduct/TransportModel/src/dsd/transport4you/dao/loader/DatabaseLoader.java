/**
 * 
 */
package dsd.transport4you.dao.loader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;

/**
 * @author Dajan,Toni
 *
 */
public class DatabaseLoader {
	
	public static Log log = LogFactory.getLog(DatabaseLoader.class);

	public static void main(String[] args) {
		
		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		
		dao.beginTransaction();
		
		RoleLoader.loadRoles(dao);	
		RandomUserLoader.generateRandomUsers(dao);
		RandomNewsLoader.generateRandomNews(dao);
		
		dao.commitTransaction();
		dao.close();
	}
}
