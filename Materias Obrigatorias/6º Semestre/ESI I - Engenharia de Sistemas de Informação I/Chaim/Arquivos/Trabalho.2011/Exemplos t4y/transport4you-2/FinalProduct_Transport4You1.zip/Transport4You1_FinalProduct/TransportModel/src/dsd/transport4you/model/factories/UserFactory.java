package dsd.transport4you.model.factories;

import java.util.Date;

import dsd.transport4you.model.user.Address;
import dsd.transport4you.model.user.AuthorizationInfo;
import dsd.transport4you.model.user.CreditCardUserInfo;
import dsd.transport4you.model.user.MobileUserInfo;
import dsd.transport4you.model.user.PersonalUserInfo;
import dsd.transport4you.model.user.User;
import dsd.transport4you.model.user.options.BillingMode;
import dsd.transport4you.model.user.options.UserOptions;
import dsd.transport4you.settings.ApplicationSettings;
import dsd.transport4you.util.StringUtil;

public class UserFactory {

	/**
	 * Creates a user with the given properties.
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param email
	 * @param username
	 * @param password
	 * @param address
	 * @param addressNumber
	 * @param town
	 * @param postNumber
	 * @param country
	 * @param dateOfBirth
	 * @param phoneNumber
	 * @param bluetoothMacAddress
	 * @param wifiMacAddress
	 * @param creditCardNumber
	 * @return
	 */
	public static User createUser(String firstName, String middleName,
			String lastName, String email, String username, String password,
			String address, String addressNumber, String town,
			String postNumber, String country, Date dateOfBirth,
			String phoneNumber, String bluetoothMacAddress,
			String wifiMacAddress) {
		
		if (password == null) {
			return null;
		}

		return createUser(
				firstName,
				middleName,
				lastName,
				email,
				username,
				password,
				address,
				addressNumber,
				town,
				postNumber,
				country,
				dateOfBirth,
				phoneNumber,
				bluetoothMacAddress,
				wifiMacAddress,
				ApplicationSettings.DEFAULT_PAYMENT_MODE,
				ApplicationSettings.NOTIFY_ON_SUCCESSFUL_PURCHASE_DEFAULT,
				ApplicationSettings.NOTIFY_ON_STANDARD_ROUTE_CHANGE_DEFAULT,
				ApplicationSettings.NOTIFY_ON_STANDARD_ROUTE_OPTIMIZATION_DEFAULT);
	}

	public static User createUser(String firstName, String middleName,
			String lastName, String email, String username, String password,
			String address, String addressNumber, String town,
			String postNumber, String country, Date dateOfBirth,
			String phoneNumber, String bluetoothMacAddress,
			String wifiMacAddress,String paymentModeStr, Boolean notifyOnSuccessfulPurchase,
			Boolean notifyOnStandardRouteChange,
			Boolean notifyOnStandardRouteOptimization) {

		User user = new User();
		
		String encodedPassword = StringUtil.encodePassword(password, ApplicationSettings.PASSWORD_HASH_ALGORITHM);
		
		AuthorizationInfo authInfo = new AuthorizationInfo();
		authInfo.setValid(true);
		authInfo.setUsername(username);
		authInfo.setPassword(encodedPassword);
		user.setAuthorizationInfo(authInfo);
		
		Address addressObj = new Address(address, addressNumber, town,postNumber, country);
		
		PersonalUserInfo personal = new PersonalUserInfo();
		personal.setFirstName(firstName);
		personal.setMiddleName(middleName);
		personal.setLastName(lastName);
		personal.setEmail(email);
		personal.setAddress(addressObj);
		personal.setDateOfBirth(dateOfBirth);
		user.setPersonalUserInfo(personal);

		MobileUserInfo mobile = new MobileUserInfo();
		mobile.setPhoneNumber(phoneNumber);
		mobile.setBluetoothMacAddress(bluetoothMacAddress);
		mobile.setWifiMacAddress(wifiMacAddress);
		user.setMobileUserInfo(mobile);

		CreditCardUserInfo credit = new CreditCardUserInfo();

		String buyerLastName = "Dajan";
		String buyerFirstName = "Zvekic";
		String buyerAddress1 = "Palinovecka 37";
		String buyerAddress2 = "";
		String buyerCity = "Zagreb";
		String buyerState = "Croatia";
		String buyerZipCode = "10000";
		String creditCardType = "Visa";
		String creditCardNumber = "4937627572675122";
		String CVV2 = "000";
		int expMonth = 11;
		int expYear = 2015;
		
		credit.setLastName(buyerLastName);
		credit.setFirstName(buyerFirstName);
		credit.setAddress1(buyerAddress1);
		credit.setAddress2(buyerAddress2);
		credit.setCity(buyerCity);
		credit.setState(buyerState);
		credit.setZipCode(buyerZipCode);
		credit.setType(creditCardType);
		credit.setNumber(creditCardNumber);
		credit.setCVV2(CVV2);
		credit.setExpirationMonth(expMonth);
		credit.setExpirationYear(expYear);
		user.setCreditCardUserInfo(credit);

		UserOptions options = new UserOptions();
		options.setBillingMode(BillingMode.valueOf(paymentModeStr));
		options.setNotifyOnStandardRouteChange(notifyOnStandardRouteChange);
		options.setNotifyOnStandardRouteOptimization(notifyOnStandardRouteOptimization);
		options.setNotifyOnSuccessfulPurchase(notifyOnSuccessfulPurchase);
		user.setUserOptions(options);

		return user;
	}

}
