package dsd.transport4you.unit.simulator;

import java.util.Random;


/**
 * This class holds all settings for simulation.
 * E.g.
 * 		WIFI_SCAN_PERIOD_START = 3;
 * 		WIFI_SCAN_PERIOD_END = 6;
 * this means that scanning will last for 3,4,5 or 6 seconds. Random number from [3, 6] interval.
 * 
 * @author Dino
 *
 */
public class SimulationSettings {
	
	private static Random rand = new Random();
	
	private static final double WIFI_SCAN_AVG_TIME = 0;
	private static final double WIFI_SCAN_SD_TIME = 0;
	
	private static final double BT_SCAN_AVG_TIME = 0;
	private static final double BT_SCAN_SD_TIME = 0;
	
	private static final int PASSENGER_EXCHANGE_AVG = 10;
	private static final int PASSENGER_EXCHANGE_SD = 2;
	public static final double LAST_STATION_COEFFICIENT = 1.4;
	
	/**
	 * From all passengers at certain station, INACTIVATE_PASSENGERS_ON_EXIT_PERCENTAGE% of them
	 * are put in "inactive" mode as they won't be traveling for some time.
	 */
	public static final double INACTIVATE_PASSENGERS_ON_EXIT_PERCENTAGE = 0.0;
	/**
	 * Passengers at certain station count is increased by ACTIVATE_PASSENGERS_ON_ENTER_PERCENTAGE% 
	 * of current count. New passengers are from "inactive" passengers.
	 */
	public static final double ACTIVATE_PASSENGERS_ON_ENTER_PERCENTAGE = 1.0;
	/**
	 * If station is empty, each passenger from "inactive" ones can be put on station with
	 * ACTIVATE_PASSENGER_AT_EMPTY_STATION_PROBABILITY probability.
	 */
	public static final double ACTIVATE_PASSENGER_AT_EMPTY_STATION_PROBABILITY = 1.0;
	
	private static final double TU_DRIVE_AVG_SPEED = 200;
	private static final double TU_DRIVE_SD_SPEED = 3;
	
	private static final double TU_STOP_AVG_TIME = 5;
	private static final double TU_STOP_SD_TIME = 1;
		
	// ************************************************** //
	
	public static final int SIMULATOR = 0;
	public static final int REAL = 1;
	public static final int PROXY = 2;
	public static int BT_MODULE_IMPL = REAL;
	public static int WIFI_MODULE_IMPL = SIMULATOR;
	public static int GPS_MODULE_IMPL = SIMULATOR;
	public static int GPRS_MODULE_IMPL = SIMULATOR;

	/**
	 * Generates random BT detection time in seconds
	 * 
	 * @return Random detection time in seconds
	 */
	public static double getBtDetectionTime() {
		return rand.nextGaussian() * BT_SCAN_SD_TIME + BT_SCAN_AVG_TIME;
	}
	
	/**
	 * Generates random WiFi detection time in seconds
	 * 
	 * @return Random detection time in seconds
	 */
	public static double getWifiDetectionTime() {
		return rand.nextGaussian() * WIFI_SCAN_SD_TIME + WIFI_SCAN_AVG_TIME;
	}
	
	/**
	 * Generates stops time for transport unit at the station in seconds
	 * 
	 * @return Transport unit stops time on the station in seconds
	 */
	public static double getStopTime() {
		return rand.nextGaussian() * TU_STOP_SD_TIME + TU_STOP_AVG_TIME;
	}

	/**
	 * Generates random passenger exchange count at station 
	 * @return Passenger exchange count at station
	 */
	public static int getPassengerExcangeCount() {
		return (int)rand.nextGaussian() * PASSENGER_EXCHANGE_SD + PASSENGER_EXCHANGE_AVG;
	}
	
	/**
	 * Generates speed in km/h in between two stations 
	 * @return Average speed in between two stations in km/h
	 */
	public static double getAvgSpeed() {
		return rand.nextGaussian() * TU_DRIVE_SD_SPEED + TU_DRIVE_AVG_SPEED;
	}
}
