package dsd.transport4you.commprot.util.exceptions;

public class SMSModuleException extends Exception{

	public SMSModuleException(String string) {
		super(string);
	}

}
