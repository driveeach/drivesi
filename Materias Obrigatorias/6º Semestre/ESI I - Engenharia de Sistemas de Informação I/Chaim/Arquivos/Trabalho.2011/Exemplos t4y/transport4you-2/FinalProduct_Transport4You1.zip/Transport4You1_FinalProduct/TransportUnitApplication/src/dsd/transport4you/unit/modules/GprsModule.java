/**
 * 
 */
package dsd.transport4you.unit.modules;

import dsd.transport4you.settings.ITransportUnitUserData;

/**
 * Module that sends information over GPRS protocol to the main application
 * 
 * @author Dino
 *
 */
public abstract class GprsModule {

	public abstract void sendData(ITransportUnitUserData userData);
}
