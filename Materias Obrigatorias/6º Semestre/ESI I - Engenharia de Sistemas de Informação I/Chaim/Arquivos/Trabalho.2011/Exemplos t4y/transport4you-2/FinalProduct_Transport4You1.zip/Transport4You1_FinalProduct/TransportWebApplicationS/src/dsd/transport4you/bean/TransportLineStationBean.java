package dsd.transport4you.bean;

/**
 * Class which holds data about one TransportLineStation.
 * Class is a value object.
 * @author Dino
 *
 */
public class TransportLineStationBean {

	private GpsLocationBean location;
	private String stationName;
	private Integer lineStationId;
	private boolean selected;
	
	public TransportLineStationBean(GpsLocationBean location,
			String stationName, Integer lineStationId) {
		super();
		this.location = location;
		this.stationName = stationName;
		this.lineStationId = lineStationId;
		this.selected = false;
	}
	
	
	@Override
	public String toString() {
		return stationName+":"+location;
	}
	
	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public GpsLocationBean getLocation() {
		return location;
	}

	public String getStationName() {
		return stationName;
	}

	public Integer getLineStationId() {
		return lineStationId;
	}
}
