package dsd.transport4you.commprot.util;

public class ProcessInfo {

	public int returnValue;
	public String stdout;
	public String stderr;
	
}
