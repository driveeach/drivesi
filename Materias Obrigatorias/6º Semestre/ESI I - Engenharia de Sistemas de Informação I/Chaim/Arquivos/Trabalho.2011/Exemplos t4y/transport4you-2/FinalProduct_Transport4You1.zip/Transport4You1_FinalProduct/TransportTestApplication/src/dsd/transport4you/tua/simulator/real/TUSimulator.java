package dsd.transport4you.tua.simulator.real;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingUtilities;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.interfaces.model.TransportLineDirection;
import dsd.transport4you.interfaces.model.TransportUnitLineData;
import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.tua.simulator.real.gui.TUSimulatorMainFrame;
import dsd.transport4you.unit.eventHandler.TransportUnitObserver;
import dsd.transport4you.unit.simulator.TransportUnit;

public class TUSimulator {

	public static void main(String[] args) throws InterruptedException, InvocationTargetException {
		
		//ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();

		
		final TransportUnit transportUnit = new TransportUnit();
		String unitId = "unique0";
		
		//List<TransportLine> lines = new ArrayList<TransportLine>(dao.getAllTransportLines());
		final List<String> linesForGUI = new ArrayList<String>();
		linesForGUI.add("5: Pre�ko - Maksimir");
		//prepareLinesForGUI(linesForGUI, lines);
		
		System.out.println("UnitId: "+unitId);
		for (String lineForGUI : linesForGUI) {
			System.out.println(lineForGUI);
		}
				
		TransportUnitObserver transportUnitObserver = new TransportUnitObserver(unitId, new TransportUnitLineData("5", TransportLineDirection.FORWARD));
		transportUnit.addObserver(transportUnitObserver);
				
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new TUSimulatorMainFrame(transportUnit, linesForGUI).setVisible(true);
			}
		});
	}

	private static void prepareLinesForGUI(List<String> linesForGUI, List<TransportLine> lines) {

		for (TransportLine transportLine : lines) {
			
			ArrayList<TransportLineStation> forwardTrip = new ArrayList<TransportLineStation>(transportLine.getTransportLineStationsForwardTrip());
			ArrayList<TransportLineStation> backwardTrip = new ArrayList<TransportLineStation>(transportLine.getTransportLineStationsBackwardTrip());

			String from = forwardTrip.get(0).getTransportStation().getName();
			String to = forwardTrip.get(forwardTrip.size() - 1).getTransportStation().getName();
			linesForGUI.add(from+" - "+to);
			
			from = backwardTrip.get(0).getTransportStation().getName();
			to = backwardTrip.get(forwardTrip.size() - 1).getTransportStation().getName();
			linesForGUI.add(from+" - "+to);
		}
		
	}
	
	
}
