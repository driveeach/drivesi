package dsd.transport4you;

public class Constants {

	public static final String PERSISTENCE_UNIT_NAME = "tmpu";

}
