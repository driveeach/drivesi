package dsd.transport4you.main.thread;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TimerTask;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.main.notification.SMSUserNotifier;
import dsd.transport4you.main.notification.UserNotifier;
import dsd.transport4you.model.network.changes.TransportRouteInterruption;
import dsd.transport4you.model.network.changes.TransportRouteModification;
import dsd.transport4you.model.user.User;
import dsd.transport4you.model.user.authorization.Role;
import dsd.transport4you.model.user.authorization.Role.RoleType;

/**
 * @author Dajan
 *
 */
public class AllModificationInterruptionNotificationTask extends TimerTask{

	public static final Log log = LogFactory.getLog(AllModificationInterruptionNotificationTask.class);
	
	private UserNotifier notifier = SMSUserNotifier.getInstance();
	
	private volatile Set<String> alreadyNotified = new HashSet<String>();
	
	@Override
	public void run() {
		
		log.info("started task");
		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		
		List<TransportRouteInterruption> routeInteruptions = dao.getTransportRouteInterruptions();
		List<TransportRouteModification> routeModification = dao.getTransportRouteModifications();
		
		log.info("interruptions:"+routeInteruptions);
		log.info("modifications:"+routeModification);
		
		Role role = dao.getRoleByType(RoleType.USER);
		Collection<User> users = role.getUsers();
		
		Date now = new Date();
		
		for(TransportRouteInterruption interruption : routeInteruptions){	
			String key = "i"+interruption.getId();
			Date startTime = interruption.getFromTime();
			Date endTime = interruption.getToTime();
			String transportLineName = interruption.getFromStation().getTransportLine().getName();
			String stationNameFrom = interruption.getFromStation().getTransportStation().getDisplayName();
			String stationNameTo = interruption.getToStation().getTransportStation().getDisplayName();
			
			if(!alreadyNotified.contains(key) && 
			   now.after(startTime) && 
			   (endTime==null || now.before(endTime))){
				
				log.info("notifying all users about:"+interruption);
				
				for(User user : users){
					notifier.notifyStandardRouteInterruption(user, now, transportLineName, stationNameFrom, stationNameTo, startTime, endTime);			
				}
				alreadyNotified.add(key);
			}
		}
		
		for(TransportRouteModification modification : routeModification){	
			String key = "m"+modification.getId();
			Date startTime = modification.getFromTime();
			Date endTime = modification.getToTime();
			String transportLineName = modification.getFromStation().getTransportLine().getName();
			String stationNameFrom = modification.getFromStation().getTransportStation().getDisplayName();
			String stationNameTo = modification.getToStation().getTransportStation().getDisplayName();
			String modifiedStationList = modification.getStationNameList();
			
			if(!alreadyNotified.contains(key) && 
				now.after(startTime) && 
				(endTime==null || now.before(endTime))){
				
				log.info("notifying all users about:"+modification);
				
				for(User user : users){
					notifier.notifyStandardRouteModification(user, now, transportLineName, stationNameFrom, stationNameTo,modifiedStationList, startTime, endTime);			
				}
				alreadyNotified.add(key);
			}
		}
		
		dao.close();
		log.info("finished task");
	}
}
