package dsd.transport4you.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import dsd.transport4you.model.user.authorization.Role;
import dsd.transport4you.model.user.authorization.Role.RoleType;

public class UserBean {

	private Integer id;
	private String firstName;
	private String lastName;
	private String username;
	private String password;
	private List<String> roleNames;
	
	public UserBean(Integer id,String username, String password, String firstName, String lastName,List<Role> roles){
		this.id=id;
		this.username = username;
		this.password = password;
		this.firstName=firstName;
		this.lastName=lastName;
		
		List<String> roleNames = new ArrayList<String>(roles.size());
		for(Role role : roles){
			roleNames.add(role.getName());
		}
		
		this.roleNames = Collections.unmodifiableList(roleNames);
	}

	public boolean isAdmin(){
		for (String roleName : roleNames) {
			if (RoleType.ADMIN.name().equalsIgnoreCase(roleName)) {
				return true;
			}
		}
		return false;
	}
	
	public boolean isUser(){
		for (String roleName : roleNames) {
			if (RoleType.USER.name().equalsIgnoreCase(roleName)) {
				return true;
			}
		}
		return false;
	}
	
	public Integer getId() {
		return id;
	}
	
	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}
	
	public List<String> getRoleNames() {
		return roleNames;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}	
	
	public void setRoleNames(List<String> roleNames) {
		this.roleNames = roleNames;
	}
	
	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return getUsername()+" ("+getRoleNames()+")";
	}
}
