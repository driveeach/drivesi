/**
 * 
 */
package dsd.transport4you.commprot;

import java.io.IOException;
import java.net.ServerSocket;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.commprot.util.CommunicationProtocolsService;
import dsd.transport4you.commprot.util.QueueSynchronized;
import dsd.transport4you.commprot.util.exceptions.TransportCommunicationProtocolsException;
import dsd.transport4you.commprot.util.threads.TaskReceiver;
import dsd.transport4you.commprot.util.threads.TasksCoordinator;
import dsd.transport4you.commprot.util.threads.TransportServerHandler;
import dsd.transport4you.settings.ITransportUnitUserData;
import dsd.transport4you.settings.ITransportUserDataHandlerFactory;

/**
 * @author dajan
 * 
 */
public class TcpServer implements Runnable {

	private static Log log = LogFactory.getLog(TcpServer.class);

	ServerSocket socket;
	private QueueSynchronized<ITransportUnitUserData> tasks;
	private QueueSynchronized<TransportServerHandler> tuaHandlers;

	/**
	 * Server constructor. Initialize tcp protocol communication.
	 * 
	 * @param socketPortNumber
	 * @param taskQueueSize
	 * @param tuaHandler
	 * @param handlerFactory
	 * @param numberOfTuaHandlers
	 * @throws IOException
	 */
	public TcpServer(int socketPortNumber,
			int taskQueueSize,
			Class<?> tuaHandler,
			ITransportUserDataHandlerFactory handlerFactory,
			int numberOfTuaHandlers) throws IOException {

		socket = new ServerSocket(socketPortNumber);
		this.tasks = new QueueSynchronized<ITransportUnitUserData>(taskQueueSize);
		tuaHandlers = new QueueSynchronized<TransportServerHandler>(
				numberOfTuaHandlers);

		for (int i = 0; i < numberOfTuaHandlers; i++) {
			TransportServerHandler handle2 = (TransportServerHandler) CommunicationProtocolsService
					.getInstance(tuaHandler);
			handle2.setHandlerFactory(handlerFactory);
			
			try {
				tuaHandlers.add(handle2);
			} catch (TransportCommunicationProtocolsException e) {
				log.error("stacktrace starts here...");
				e.printStackTrace();
				log.error("stacktrace ends here...");
			}
			
			new Thread(handle2).start();
		}

	}


	@Override
	public void run() {

		TasksCoordinator coordinator = new TasksCoordinator(tasks, tuaHandlers);
		new Thread(coordinator).start();
		while (true) {
			try {
				Thread.sleep(500);
				//TODO: to ApplicationSettings.java
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				new Thread(new TaskReceiver(tasks, socket.accept())).start();
			} catch (IOException e) {
				
				log.error("stacktrace starts here...");
				e.printStackTrace();
				log.error("stacktrace ends here...");
			}
		}

	}

}
