package dsd.transport4you.dao.loader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.model.factories.TransportNetworkFactory;
import dsd.transport4you.model.network.TransportNetwork;
import dsd.transport4you.util.exceptions.InvalidNetworkXMLFile;

/**
 * Main class that implements loading of a transport network xml definition to the database.
 * @author toni
 */
public class TransportNetworkLoader {
	
	public static Log log = LogFactory.getLog(TransportNetworkLoader.class);
	
	/**
	 * Method reads xml definition of transport network, deserializes it to
	 * java classes, and persists the transport network hierarchy to the database.
	 * @param args path to transport network xml file.
	 * @throws InvalidNetworkXMLFile in case of any problem with the xml file.
	 */
	public static void main(String[] args) throws InvalidNetworkXMLFile {
		
		TransportNetwork network = TransportNetworkFactory.fromXML(args[0]);
		log.info("network "+network.getName()+" created");
		
		ITransportModelDAO dao = TransportModelDAOFactory.createITransportModelDAO();
		dao.beginTransaction();
		
		dao.save(network);
		RandomTransportUnitLoader.generateRandomTransportUnits(dao,network);
		
		dao.commitTransaction();
		dao.close();
		
		log.info("network "+network.getName()+" persisted");
	}
}
