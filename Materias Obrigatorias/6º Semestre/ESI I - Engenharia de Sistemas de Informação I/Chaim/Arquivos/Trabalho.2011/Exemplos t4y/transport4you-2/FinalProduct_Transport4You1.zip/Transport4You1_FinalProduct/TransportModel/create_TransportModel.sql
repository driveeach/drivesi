
    alter table NEWS 
        drop 
        foreign key FK2482D3EB827DA5;

    alter table PAYMENT 
        drop 
        foreign key FKFBE7BDE68AC98B65;

    alter table TICKET 
        drop 
        foreign key FK937B5F0CC559F702;

    alter table TICKET 
        drop 
        foreign key FK937B5F0C8AC98B65;

    alter table TRANSPORT_LAYER 
        drop 
        foreign key FK62BC1C7BD948D532;

    alter table TRANSPORT_LINE 
        drop 
        foreign key FKF2AB576A695C0C52;

    alter table TRANSPORT_LINE_STATION 
        drop 
        foreign key FK401813F7EBC03F;

    alter table TRANSPORT_LINE_STATION 
        drop 
        foreign key FK401813F89CBF37;

    alter table TRANSPORT_LINE_STATION 
        drop 
        foreign key FK401813F10F62F72;

    alter table TRANSPORT_ROUTE 
        drop 
        foreign key FK6316F9738AC98B65;

    alter table TRANSPORT_ROUTE_INTERRUPTION 
        drop 
        foreign key FKFE623611C963709F;

    alter table TRANSPORT_ROUTE_INTERRUPTION 
        drop 
        foreign key FKFE623611E4EDD630;

    alter table TRANSPORT_ROUTE_MODIFICATION 
        drop 
        foreign key FKE4575CE8C963709F;

    alter table TRANSPORT_ROUTE_MODIFICATION 
        drop 
        foreign key FKE4575CE8E4EDD630;

    alter table TRANSPORT_ROUTE_SECTION 
        drop 
        foreign key FK449687F9C963709F;

    alter table TRANSPORT_ROUTE_SECTION 
        drop 
        foreign key FK449687F9E4EDD630;

    alter table TRANSPORT_ROUTE_SECTION 
        drop 
        foreign key FK449687F9CBEFAFAE;

    alter table TRANSPORT_STANDARD_ROUTE_SECTION 
        drop 
        foreign key FKA0F002A3C963709F;

    alter table TRANSPORT_STANDARD_ROUTE_SECTION 
        drop 
        foreign key FKA0F002A3E4EDD630;

    alter table TRANSPORT_STANDARD_ROUTE_SECTION 
        drop 
        foreign key FKA0F002A38AC98B65;

    alter table TRANSPORT_UNIT 
        drop 
        foreign key FKF2AF80FA695C0C52;

    alter table TRANSPORT_UNIT 
        drop 
        foreign key FKF2AF80FA9AC15FAE;

    alter table USER 
        drop 
        foreign key FK27E3CBA08681EC;

    alter table USER_IN_ROLE 
        drop 
        foreign key FK568AA6DC2CEA2C9A;

    alter table USER_IN_ROLE 
        drop 
        foreign key FK568AA6DC8AC98B65;

    drop table if exists NEWS;

    drop table if exists PAYMENT;

    drop table if exists ROLE;

    drop table if exists TICKET;

    drop table if exists TRANSPORT_LAYER;

    drop table if exists TRANSPORT_LINE;

    drop table if exists TRANSPORT_LINE_STATION;

    drop table if exists TRANSPORT_NETWORK;

    drop table if exists TRANSPORT_ROUTE;

    drop table if exists TRANSPORT_ROUTE_INTERRUPTION;

    drop table if exists TRANSPORT_ROUTE_MODIFICATION;

    drop table if exists TRANSPORT_ROUTE_SECTION;

    drop table if exists TRANSPORT_STANDARD_ROUTE_SECTION;

    drop table if exists TRANSPORT_STATION;

    drop table if exists TRANSPORT_UNIT;

    drop table if exists USER;

    drop table if exists USER_IN_ROLE;

    create table NEWS (
        id integer not null auto_increment,
        category integer,
        contents text not null,
        time datetime not null,
        title varchar(255) not null,
        author_id integer not null,
        primary key (id)
    ) type=InnoDB;

    create table PAYMENT (
        id integer not null auto_increment,
        paymentType integer,
        time datetime not null,
        user_id integer,
        primary key (id)
    ) type=InnoDB;

    create table ROLE (
        id integer not null auto_increment,
        name varchar(50) not null unique,
        primary key (id)
    ) type=InnoDB;

    create table TICKET (
        id integer not null auto_increment,
        ticketType integer,
        timeValidFrom datetime,
        timeValidTo datetime,
        payment_id integer not null,
        user_id integer,
        primary key (id)
    ) type=InnoDB;

    create table TRANSPORT_LAYER (
        id integer not null auto_increment,
        type integer,
        transportNetwork_id integer,
        primary key (id),
        unique (type, transportNetwork_id)
    ) type=InnoDB;

    create table TRANSPORT_LINE (
        id integer not null auto_increment,
        name varchar(50) not null unique,
        transportLayer_id integer,
        primary key (id)
    ) type=InnoDB;

    create table TRANSPORT_LINE_STATION (
        id integer not null auto_increment,
        stationNumber integer not null,
        transportLineBackward_id integer,
        transportLineForward_id integer,
        transportStation_id integer,
        primary key (id)
    ) type=InnoDB;

    create table TRANSPORT_NETWORK (
        id integer not null auto_increment,
        name varchar(50) not null unique,
        primary key (id)
    ) type=InnoDB;

    create table TRANSPORT_ROUTE (
        id integer not null auto_increment,
        active bit not null,
        user_id integer,
        primary key (id)
    ) type=InnoDB;

    create table TRANSPORT_ROUTE_INTERRUPTION (
        id integer not null auto_increment,
        fromTime datetime not null,
        toTime datetime,
        fromStation_id integer not null,
        toStation_id integer not null,
        primary key (id)
    ) type=InnoDB;

    create table TRANSPORT_ROUTE_MODIFICATION (
        id integer not null auto_increment,
        fromTime datetime not null,
        stationNameList varchar(255) not null,
        toTime datetime,
        fromStation_id integer not null,
        toStation_id integer not null,
        primary key (id)
    ) type=InnoDB;

    create table TRANSPORT_ROUTE_SECTION (
        id integer not null auto_increment,
        fromStationTime datetime not null,
        toStationTime datetime,
        fromStation_id integer not null,
        route_id integer not null,
        toStation_id integer,
        primary key (id)
    ) type=InnoDB;

    create table TRANSPORT_STANDARD_ROUTE_SECTION (
        id integer not null auto_increment,
        dayOfWeek integer,
        fromStationDayTime time not null,
        toStationDayTime time,
        fromStation_id integer not null,
        toStation_id integer not null,
        user_id integer not null,
        primary key (id)
    ) type=InnoDB;

    create table TRANSPORT_STATION (
        id integer not null auto_increment,
        displayName varchar(50) not null,
        latitude double precision not null,
        longitude double precision not null,
        `index` varchar(50) not null,
        name varchar(50) not null,
        primary key (id),
        unique (name, `index`)
    ) type=InnoDB;

    create table TRANSPORT_UNIT (
        id integer not null auto_increment,
        identifier varchar(50) not null unique,
        timeCurrentStation datetime,
        currentStation_id integer,
        transportLayer_id integer,
        primary key (id)
    ) type=InnoDB;

    create table USER (
        id integer not null auto_increment,
        password varchar(40) not null,
        sessionHash integer,
        sessionToken bigint,
        username varchar(50) not null unique,
        valid bit not null,
        creditCardCVV2 varchar(50) not null,
        creditCardAddress1 varchar(50) not null,
        creditCardAddress2 varchar(50),
        creditCardCity varchar(50) not null,
        creditCardExpirationMonth integer not null,
        creditCardExpirationYear integer not null,
        creditCardFirstName varchar(50) not null,
        creditCardLastName varchar(50) not null,
        creditCardNumber varchar(50) not null,
        creditCardState varchar(50) not null,
        creditCardType varchar(50) not null,
        creditCardZipCode varchar(50) not null,
        bluetoothMacAddress varchar(50) unique,
        phoneNumber varchar(50) not null unique,
        wifiMacAddress varchar(50) unique,
        address varchar(50) not null,
        addressNumber varchar(50) not null,
        country varchar(50) not null,
        postNumber varchar(50) not null,
        town varchar(50) not null,
        dateOfBirth datetime not null,
        email varchar(50) not null,
        firstName varchar(50) not null,
        lastName varchar(50) not null,
        middleName varchar(50),
        billingMode integer,
        notifyOnStandardRouteChange bit,
        notifyOnStandardRouteOptimization bit,
        notifyOnSuccessfulPurchase bit,
        activeTicket_id integer,
        primary key (id)
    ) type=InnoDB;

    create table USER_IN_ROLE (
        id integer not null auto_increment,
        role_id integer not null,
        user_id integer not null,
        primary key (id)
    ) type=InnoDB;

    alter table NEWS 
        add index FK2482D3EB827DA5 (author_id), 
        add constraint FK2482D3EB827DA5 
        foreign key (author_id) 
        references USER (id);

    alter table PAYMENT 
        add index FKFBE7BDE68AC98B65 (user_id), 
        add constraint FKFBE7BDE68AC98B65 
        foreign key (user_id) 
        references USER (id);

    alter table TICKET 
        add index FK937B5F0CC559F702 (payment_id), 
        add constraint FK937B5F0CC559F702 
        foreign key (payment_id) 
        references PAYMENT (id);

    alter table TICKET 
        add index FK937B5F0C8AC98B65 (user_id), 
        add constraint FK937B5F0C8AC98B65 
        foreign key (user_id) 
        references USER (id);

    alter table TRANSPORT_LAYER 
        add index FK62BC1C7BD948D532 (transportNetwork_id), 
        add constraint FK62BC1C7BD948D532 
        foreign key (transportNetwork_id) 
        references TRANSPORT_NETWORK (id);

    alter table TRANSPORT_LINE 
        add index FKF2AB576A695C0C52 (transportLayer_id), 
        add constraint FKF2AB576A695C0C52 
        foreign key (transportLayer_id) 
        references TRANSPORT_LAYER (id);

    alter table TRANSPORT_LINE_STATION 
        add index FK401813F7EBC03F (transportLineBackward_id), 
        add constraint FK401813F7EBC03F 
        foreign key (transportLineBackward_id) 
        references TRANSPORT_LINE (id);

    alter table TRANSPORT_LINE_STATION 
        add index FK401813F89CBF37 (transportLineForward_id), 
        add constraint FK401813F89CBF37 
        foreign key (transportLineForward_id) 
        references TRANSPORT_LINE (id);

    alter table TRANSPORT_LINE_STATION 
        add index FK401813F10F62F72 (transportStation_id), 
        add constraint FK401813F10F62F72 
        foreign key (transportStation_id) 
        references TRANSPORT_STATION (id);

    alter table TRANSPORT_ROUTE 
        add index FK6316F9738AC98B65 (user_id), 
        add constraint FK6316F9738AC98B65 
        foreign key (user_id) 
        references USER (id);

    alter table TRANSPORT_ROUTE_INTERRUPTION 
        add index FKFE623611C963709F (fromStation_id), 
        add constraint FKFE623611C963709F 
        foreign key (fromStation_id) 
        references TRANSPORT_LINE_STATION (id);

    alter table TRANSPORT_ROUTE_INTERRUPTION 
        add index FKFE623611E4EDD630 (toStation_id), 
        add constraint FKFE623611E4EDD630 
        foreign key (toStation_id) 
        references TRANSPORT_LINE_STATION (id);

    alter table TRANSPORT_ROUTE_MODIFICATION 
        add index FKE4575CE8C963709F (fromStation_id), 
        add constraint FKE4575CE8C963709F 
        foreign key (fromStation_id) 
        references TRANSPORT_LINE_STATION (id);

    alter table TRANSPORT_ROUTE_MODIFICATION 
        add index FKE4575CE8E4EDD630 (toStation_id), 
        add constraint FKE4575CE8E4EDD630 
        foreign key (toStation_id) 
        references TRANSPORT_LINE_STATION (id);

    alter table TRANSPORT_ROUTE_SECTION 
        add index FK449687F9C963709F (fromStation_id), 
        add constraint FK449687F9C963709F 
        foreign key (fromStation_id) 
        references TRANSPORT_LINE_STATION (id);

    alter table TRANSPORT_ROUTE_SECTION 
        add index FK449687F9E4EDD630 (toStation_id), 
        add constraint FK449687F9E4EDD630 
        foreign key (toStation_id) 
        references TRANSPORT_LINE_STATION (id);

    alter table TRANSPORT_ROUTE_SECTION 
        add index FK449687F9CBEFAFAE (route_id), 
        add constraint FK449687F9CBEFAFAE 
        foreign key (route_id) 
        references TRANSPORT_ROUTE (id);

    alter table TRANSPORT_STANDARD_ROUTE_SECTION 
        add index FKA0F002A3C963709F (fromStation_id), 
        add constraint FKA0F002A3C963709F 
        foreign key (fromStation_id) 
        references TRANSPORT_LINE_STATION (id);

    alter table TRANSPORT_STANDARD_ROUTE_SECTION 
        add index FKA0F002A3E4EDD630 (toStation_id), 
        add constraint FKA0F002A3E4EDD630 
        foreign key (toStation_id) 
        references TRANSPORT_LINE_STATION (id);

    alter table TRANSPORT_STANDARD_ROUTE_SECTION 
        add index FKA0F002A38AC98B65 (user_id), 
        add constraint FKA0F002A38AC98B65 
        foreign key (user_id) 
        references USER (id);

    alter table TRANSPORT_UNIT 
        add index FKF2AF80FA695C0C52 (transportLayer_id), 
        add constraint FKF2AF80FA695C0C52 
        foreign key (transportLayer_id) 
        references TRANSPORT_LAYER (id);

    alter table TRANSPORT_UNIT 
        add index FKF2AF80FA9AC15FAE (currentStation_id), 
        add constraint FKF2AF80FA9AC15FAE 
        foreign key (currentStation_id) 
        references TRANSPORT_LINE_STATION (id);

    alter table USER 
        add index FK27E3CBA08681EC (activeTicket_id), 
        add constraint FK27E3CBA08681EC 
        foreign key (activeTicket_id) 
        references TICKET (id);

    alter table USER_IN_ROLE 
        add index FK568AA6DC2CEA2C9A (role_id), 
        add constraint FK568AA6DC2CEA2C9A 
        foreign key (role_id) 
        references ROLE (id);

    alter table USER_IN_ROLE 
        add index FK568AA6DC8AC98B65 (user_id), 
        add constraint FK568AA6DC8AC98B65 
        foreign key (user_id) 
        references USER (id);
