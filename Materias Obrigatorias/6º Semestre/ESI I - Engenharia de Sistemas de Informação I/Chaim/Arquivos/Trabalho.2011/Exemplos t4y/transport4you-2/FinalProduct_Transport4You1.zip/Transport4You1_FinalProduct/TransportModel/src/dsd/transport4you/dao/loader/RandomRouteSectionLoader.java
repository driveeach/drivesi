/**
 * 
 */
package dsd.transport4you.dao.loader;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.dao.factories.TransportModelDAOFactory;
import dsd.transport4you.dao.interfaces.ITransportModelDAO;
import dsd.transport4you.model.factories.TransportRouteFactory;
import dsd.transport4you.model.factories.TransportRouteSectionFactory;
import dsd.transport4you.model.network.TransportLine;
import dsd.transport4you.model.network.TransportLineStation;
import dsd.transport4you.model.route.TransportRoute;
import dsd.transport4you.model.route.TransportRouteSection;
import dsd.transport4you.model.user.User;

/**
 * @author Dajan
 *
 */
public class RandomRouteSectionLoader {

	public static Log log = LogFactory.getLog(RandomRouteSectionLoader.class);
	
	public static void main(String[] args) {
		
		log.info("Started random standard route loader ....");
		
		ITransportModelDAO dao = TransportModelDAOFactory
		.createITransportModelDAO();
		
		dao.getEntityManager().getTransaction().begin();
		
		generateRouteSections(dao,1);
		generateRouteSections(dao,2);
		
		dao.getEntityManager().getTransaction().commit();
		dao.close();
		
		
		log.info("Ended random standard route loader ....");
	}

	private static void generateRouteSections(ITransportModelDAO dao, Integer userId) {

		List<TransportLine> transportLines = new ArrayList<TransportLine>(dao.getAllTransportLines());
		TransportLine line = transportLines.get(0);
		
		List<TransportLineStation> lineStations = null;
		
		if(line.getTransportLineStationsBackwardTrip() != null){
			
			lineStations = new ArrayList<TransportLineStation>(line.getTransportLineStationsBackwardTrip());
			
		}else{
			
			lineStations = new ArrayList<TransportLineStation>(line.getTransportLineStationsForwardTrip());
			
		}
				
		
		User user = dao.getUserById(userId);
	
		
		Random rand = new Random();
		
		
		TransportRoute transportRoute = null;
		
		for(int i = 0; i < 20; i ++){
			Date fromStationTime = new Date();
			Date toStationTime = new Date();
			
			int randomTimeFactor = rand.nextInt(5);
			int randomStationFrom = rand.nextInt(lineStations.size()/2);
			int randomStationTo = lineStations.size()/2 - 1 + rand.nextInt(lineStations.size()/2);
			
			fromStationTime.setTime(fromStationTime.getTime() + 10000000 * randomTimeFactor);
			toStationTime.setTime(toStationTime.getTime() + 100000000 * randomTimeFactor);
			
			transportRoute = TransportRouteFactory.createEmptyTransportRoute();
			TransportRouteSection transportSection = TransportRouteSectionFactory.createUsersTransportRouteSection(user, lineStations.get(randomStationFrom), lineStations.get(randomStationTo), fromStationTime, toStationTime, transportRoute);
			//dao.save(transportSection);
			TransportRouteFactory.updateUsersTransportRoute(transportRoute, user, transportSection);
			dao.save(transportRoute);
			//user.addTransportRoute(transportRoute);
			System.out.println(transportRoute);
		}
		
		//log.info("Started update...");
		
		//dao.update(user);
		//User userTest = dao.getUserById(1);
		
		//log.info("Ended update...");
		
	}
	
}
