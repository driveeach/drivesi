/**
 * 
 */
package dsd.transport4you.model.user.options;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Enumerated;

/**
 * Class is a value object. Class contains user options: 
 * <pre>	1. Billing mode. </pre>
 * <pre> 	2. Notification options. </pre>
 * 
 * @author toni, dajan
 * 
 */
@Embeddable
public class UserOptions {

	/**
	 * Preferred payment mode.
	 */
	@Enumerated
	private BillingMode billingMode;

	/**
	 * Notification for successful purchase.
	 */	
	@Column(name="notifyOnSuccessfulPurchase",length=50,unique=false,nullable=true)
	private Boolean notifyOnSuccessfulPurchase;
	/**
	 * Notification for standard route change.
	 */
	@Column(name="notifyOnStandardRouteChange",length=50,unique=false,nullable=true)
	private Boolean notifyOnStandardRouteChange;
	/**
	 * Notification on standard route optimization.
	 */
	@Column(name="notifyOnStandardRouteOptimization",length=50,unique=false,nullable=true)
	private Boolean notifyOnStandardRouteOptimization;
	
	public UserOptions() {
		// TODO Auto-generated constructor stub
	}
	
	public UserOptions(BillingMode paymentMode,
			Boolean notifyOnSuccessfulPurchase,
			Boolean notifyOnStandardRouteChange,
			Boolean notifyOnStandardRouteOptimization) {
		super();
		this.billingMode = paymentMode;
		this.notifyOnSuccessfulPurchase = notifyOnSuccessfulPurchase;
		this.notifyOnStandardRouteChange = notifyOnStandardRouteChange;
		this.notifyOnStandardRouteOptimization = notifyOnStandardRouteOptimization;
	}

	public BillingMode getBillingMode() {
		return billingMode;
	}
	public void setBillingMode(BillingMode paymentMode) {
		this.billingMode = paymentMode;
	}
	public Boolean getNotifyOnSuccessfulPurchase() {
		return notifyOnSuccessfulPurchase;
	}
	public void setNotifyOnSuccessfulPurchase(Boolean notifyOnSuccessfulPurchase) {
		this.notifyOnSuccessfulPurchase = notifyOnSuccessfulPurchase;
	}
	public Boolean getNotifyOnStandardRouteChange() {
		return notifyOnStandardRouteChange;
	}
	public void setNotifyOnStandardRouteChange(Boolean notifyOnStandardRouteChange) {
		this.notifyOnStandardRouteChange = notifyOnStandardRouteChange;
	}
	public Boolean getNotifyOnStandardRouteOptimization() {
		return notifyOnStandardRouteOptimization;
	}
	public void setNotifyOnStandardRouteOptimization(
			Boolean notifyOnStandardRouteOptimization) {
		this.notifyOnStandardRouteOptimization = notifyOnStandardRouteOptimization;
	}
}
