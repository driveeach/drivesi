package dsd.transport4you.main.thread;

import java.util.Date;
import java.util.List;
import java.util.TimerTask;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.commprot.sms.SMSMessage;
import dsd.transport4you.commprot.sms.SMSModule;
import dsd.transport4you.commprot.sms.SMSModuleFactory;
import dsd.transport4you.commprot.util.exceptions.SMSModuleException;
import dsd.transport4you.main.notification.SMSUserNotificationBuffer;

public class SMSSenderTask extends TimerTask {

	public static final Log log = LogFactory.getLog(SMSSenderTask.class);
	
	private SMSModule smsModule;
	private SMSUserNotificationBuffer notificationBuffer;
	
	public SMSSenderTask() {
		smsModule = SMSModuleFactory.createSMSModule();
		notificationBuffer = SMSUserNotificationBuffer.getInstance();
	}
	
	public void run() {
		
		log.info("started task");
		log.info(notificationBuffer);
		Date now = new Date();
		
		List<SMSMessage> messagesToSend = notificationBuffer.popToSend(now);
		
		log.info("msg to send:"+messagesToSend.size());
		log.info("msg in waiting:"+notificationBuffer.size());
		
		for(SMSMessage msg : messagesToSend){
			try {
				smsModule.sendMessage(msg);
			} catch (SMSModuleException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		log.info("finished task");
	}
	
}
