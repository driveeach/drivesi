package dsd.transport4you.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

public interface DatabaseOperationExt<T> {
	public T executeOperationExt(EntityManager em, EntityTransaction tx);
}