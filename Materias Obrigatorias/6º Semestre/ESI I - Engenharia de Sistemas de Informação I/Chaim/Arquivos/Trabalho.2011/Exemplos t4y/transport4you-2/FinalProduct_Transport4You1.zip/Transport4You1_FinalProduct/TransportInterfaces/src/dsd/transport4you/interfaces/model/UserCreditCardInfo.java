/**
 * 
 */
package dsd.transport4you.interfaces.model;

/**
 * @author Dajan
 *
 */
public class UserCreditCardInfo {

	public String paymentAmount;
	public String buyerLastName;
	public String buyerFirstName;
	public String buyerAddress1;
	public String buyerAddress2;
	public String buyerCity;
	public String buyerState;
	public String buyerZipCode;
	public String creditCardType;
	public String creditCardNumber;
	public String CVV2;
	public int expMonth;
	public int expYear;
	
	public UserCreditCardInfo() {
		// TODO Auto-generated constructor stub
	}
	
	public UserCreditCardInfo(String paymentAmount, String buyerLastName,
			String buyerFirstName, String buyerAddress1, String buyerAddress2,
			String buyerCity, String buyerState, String buyerZipCode,
			String creditCardType, String creditCardNumber, String cVV2,
			int expMonth, int expYear) {
		super();
		this.paymentAmount = paymentAmount;
		this.buyerLastName = buyerLastName;
		this.buyerFirstName = buyerFirstName;
		this.buyerAddress1 = buyerAddress1;
		this.buyerAddress2 = buyerAddress2;
		this.buyerCity = buyerCity;
		this.buyerState = buyerState;
		this.buyerZipCode = buyerZipCode;
		this.creditCardType = creditCardType;
		this.creditCardNumber = creditCardNumber;
		CVV2 = cVV2;
		this.expMonth = expMonth;
		this.expYear = expYear;
	}

	/**
	 * @return the paymentAmount
	 */
	public String getPaymentAmount() {
		return paymentAmount;
	}

	/**
	 * @param paymentAmount the paymentAmount to set
	 */
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	/**
	 * @return the buyerLastName
	 */
	public String getBuyerLastName() {
		return buyerLastName;
	}

	/**
	 * @param buyerLastName the buyerLastName to set
	 */
	public void setBuyerLastName(String buyerLastName) {
		this.buyerLastName = buyerLastName;
	}

	/**
	 * @return the buyerFirstName
	 */
	public String getBuyerFirstName() {
		return buyerFirstName;
	}

	/**
	 * @param buyerFirstName the buyerFirstName to set
	 */
	public void setBuyerFirstName(String buyerFirstName) {
		this.buyerFirstName = buyerFirstName;
	}

	/**
	 * @return the buyerAddress1
	 */
	public String getBuyerAddress1() {
		return buyerAddress1;
	}

	/**
	 * @param buyerAddress1 the buyerAddress1 to set
	 */
	public void setBuyerAddress1(String buyerAddress1) {
		this.buyerAddress1 = buyerAddress1;
	}

	/**
	 * @return the buyerAddress2
	 */
	public String getBuyerAddress2() {
		return buyerAddress2;
	}

	/**
	 * @param buyerAddress2 the buyerAddress2 to set
	 */
	public void setBuyerAddress2(String buyerAddress2) {
		this.buyerAddress2 = buyerAddress2;
	}

	/**
	 * @return the buyerCity
	 */
	public String getBuyerCity() {
		return buyerCity;
	}

	/**
	 * @param buyerCity the buyerCity to set
	 */
	public void setBuyerCity(String buyerCity) {
		this.buyerCity = buyerCity;
	}

	/**
	 * @return the buyerState
	 */
	public String getBuyerState() {
		return buyerState;
	}

	/**
	 * @param buyerState the buyerState to set
	 */
	public void setBuyerState(String buyerState) {
		this.buyerState = buyerState;
	}

	/**
	 * @return the buyerZipCode
	 */
	public String getBuyerZipCode() {
		return buyerZipCode;
	}

	/**
	 * @param buyerZipCode the buyerZipCode to set
	 */
	public void setBuyerZipCode(String buyerZipCode) {
		this.buyerZipCode = buyerZipCode;
	}

	/**
	 * @return the creditCardType
	 */
	public String getCreditCardType() {
		return creditCardType;
	}

	/**
	 * @param creditCardType the creditCardType to set
	 */
	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}

	/**
	 * @return the creditCardNumber
	 */
	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	/**
	 * @param creditCardNumber the creditCardNumber to set
	 */
	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	/**
	 * @return the cVV2
	 */
	public String getCVV2() {
		return CVV2;
	}

	/**
	 * @param cVV2 the cVV2 to set
	 */
	public void setCVV2(String cVV2) {
		CVV2 = cVV2;
	}

	/**
	 * @return the expMonth
	 */
	public int getExpMonth() {
		return expMonth;
	}

	/**
	 * @param expMonth the expMonth to set
	 */
	public void setExpMonth(int expMonth) {
		this.expMonth = expMonth;
	}

	/**
	 * @return the expYear
	 */
	public int getExpYear() {
		return expYear;
	}

	/**
	 * @param expYear the expYear to set
	 */
	public void setExpYear(int expYear) {
		this.expYear = expYear;
	}
	
}
