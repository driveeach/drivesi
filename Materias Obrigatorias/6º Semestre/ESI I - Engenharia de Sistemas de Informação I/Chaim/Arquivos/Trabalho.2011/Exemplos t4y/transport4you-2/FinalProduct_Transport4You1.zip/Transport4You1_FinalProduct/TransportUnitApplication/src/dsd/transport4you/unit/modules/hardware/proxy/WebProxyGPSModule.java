package dsd.transport4you.unit.modules.hardware.proxy;

import dsd.transport4you.commprot.rpc.RPCException;
import dsd.transport4you.interfaces.model.GpsLocation;
import dsd.transport4you.unit.exceptions.GPSLocationUnavailable;
import dsd.transport4you.unit.modules.GpsModule;

public class WebProxyGPSModule extends GpsModule {

	private String proxyIP="shap2.info-sol.net";
	private Integer proxyPort=8090;
	
	private String deviceIP="192.168.1.170";
	
	private GPSLocationFetchRPCClient gpsFetch = new GPSLocationFetchRPCClient(proxyIP,proxyPort);
	
	public WebProxyGPSModule() {
		
	}
	
	@Override
	public GpsLocation getCurrentLocation() throws GPSLocationUnavailable {
		try {
			return gpsFetch.getGPSLocationByIP(deviceIP);
		} catch (RPCException e) {
			throw new GPSLocationUnavailable(e);
		}
	}
	
	
	public static void main(String[] args) throws GPSLocationUnavailable {
		
		
		GpsModule module = new WebProxyGPSModule();
		while(true){
			System.out.println(module.getCurrentLocation());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
