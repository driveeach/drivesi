package dsd.transport4you.actions.authorization;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dsd.transport4you.actions.interfaces.IAuthorizationAction;
import dsd.transport4you.bean.UserBean;
import dsd.transport4you.model.user.User;
import dsd.transport4you.settings.Constants;

public class LogoutAction extends AuthorizationAction implements IAuthorizationAction{
	
	private static final long serialVersionUID = -6654291476286884546L;

	private static Log log = LogFactory.getLog(LogoutAction.class);
	
	public String execute() throws Exception { 
		
		UserBean userBean = (UserBean) session.remove(Constants.USER_BEAN);
		
		if(userBean!=null){
			User user = webDAO.getUserById(userBean.getId());
			
			user.clearSessionTokens();
			clearSessionCookie(user,httpResponse);
			log.info("session tokens cleared");
			
			webDAO.beginTransaction();
			webDAO.update(user);
			webDAO.commitTransaction();
		}
		
		return SUCCESS;
	}
}
