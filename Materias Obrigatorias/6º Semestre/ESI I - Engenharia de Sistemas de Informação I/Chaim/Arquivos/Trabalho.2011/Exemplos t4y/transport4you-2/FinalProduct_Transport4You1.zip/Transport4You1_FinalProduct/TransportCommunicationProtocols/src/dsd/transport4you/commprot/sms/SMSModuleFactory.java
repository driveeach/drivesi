package dsd.transport4you.commprot.sms;

import dsd.transport4you.settings.ApplicationSettings;

public class SMSModuleFactory {

	public static SMSModule createSMSModule(){
		
		if(ApplicationSettings.SMS_MODULE_IMPL.equals(ApplicationSettings.SMS_GNOKII)){
			return GNokiiSMSModule.getInstance();
		}else{
			return new DummySMSModule();
		}
	}
}
