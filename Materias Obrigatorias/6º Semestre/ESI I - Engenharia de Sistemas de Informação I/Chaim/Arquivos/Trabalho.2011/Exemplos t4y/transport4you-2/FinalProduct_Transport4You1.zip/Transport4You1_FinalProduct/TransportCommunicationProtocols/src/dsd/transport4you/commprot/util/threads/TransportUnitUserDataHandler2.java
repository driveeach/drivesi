/**
 * 
 */
package dsd.transport4you.commprot.util.threads;

import dsd.transport4you.settings.ITransportUnitUserData;
import dsd.transport4you.settings.ITransportUserDataHandlerFactory;


/**
 * @author toni
 *
 */
 @Deprecated
public class TransportUnitUserDataHandler2 extends TransportServerHandler{

	private ITransportUnitUserData task = null;
	private ITransportUserDataHandlerFactory handlerFactory=null;
	
	public TransportUnitUserDataHandler2() {
		// TODO Auto-generated constructor stub
	}
	
	public TransportUnitUserDataHandler2(ITransportUserDataHandlerFactory handlerFactory) {
		this.handlerFactory=handlerFactory;
	}
	
	public void setHandlerFactory(
			ITransportUserDataHandlerFactory handlerFactory) {
		this.handlerFactory = handlerFactory;
	}
	
	public void setTask(ITransportUnitUserData task){
		this.task = task;
	}
	
	@SuppressWarnings("unused")
	private void releaseTask(){
		this.task = null;
	}
	
	public Boolean isFree(){
		
		if(task == null){
			return true;
		}else{
			return false;
		}
	}
	
	@Override
	public void run() {
		
		while(true){
			
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(isFree()){
				this.handlerFactory.createTransportUserDataHandler().handle(this.task);
			}
			
		}
	}

	@Override
	public Boolean hasTask() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
