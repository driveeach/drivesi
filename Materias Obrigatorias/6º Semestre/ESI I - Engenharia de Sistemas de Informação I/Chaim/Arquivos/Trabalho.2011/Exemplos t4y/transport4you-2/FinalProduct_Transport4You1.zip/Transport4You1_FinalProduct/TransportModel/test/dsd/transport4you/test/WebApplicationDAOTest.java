package dsd.transport4you.test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import dsd.transport4you.dao.factories.WebApplicationDAOFactory;
import dsd.transport4you.dao.interfaces.IWebApplicationDAO;
import dsd.transport4you.model.user.User;

public class WebApplicationDAOTest {

	private IWebApplicationDAO dao;
	
	@Before
	public void setUp(){
		
	}

	@After
	public void tearDown() {
		
	}
	
	@Test()
	public void testAllUsers(){
		dao = WebApplicationDAOFactory.createIWebApplicationDao();
		dao.close();
	}
	
	@Test()
	public void testUserAuthorization(){
	
		dao = WebApplicationDAOFactory.createIWebApplicationDao();
		
		User user = dao.getUserByAuthorization("username1", "password2");
		Assert.assertNull(user);
		
		user = dao.getUserByAuthorization("username1", "password1");
		Assert.assertNotNull(user);
		Assert.assertEquals("username1", user.getAuthorizationInfo().getUsername());
		Assert.assertTrue(user.isUser());
		Assert.assertFalse(user.isAdmin());
		
		dao.close();
	}
	
}
