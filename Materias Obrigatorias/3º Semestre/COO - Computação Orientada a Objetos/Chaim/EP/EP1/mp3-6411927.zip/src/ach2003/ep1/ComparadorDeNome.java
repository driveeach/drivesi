package ach2003.ep1;

import java.util.Comparator;

class ComparadorDeNome implements Comparator<MP3>{

	public int compare(MP3 arg0, MP3 arg1)
	{
		return arg0.getMusica().compareToIgnoreCase(arg1.getMusica());
	}
}