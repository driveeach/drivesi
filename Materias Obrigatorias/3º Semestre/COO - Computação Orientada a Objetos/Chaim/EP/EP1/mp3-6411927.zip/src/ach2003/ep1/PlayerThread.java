package ach2003.ep1;

import java.io.FileNotFoundException;
import java.io.IOException;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player; 				// Biblioteca que possibilita tocar mp3. Para mais info, veja readme.txt


// foi a forma que encontrei de fazer o programa funcionar,
// pois colocar Player.play() em AcervoMP3 suspendia a execucao de todos os comandos ateh o fim da musica
class PlayerThread extends Thread
{
	Player tocadorDeMP3; //um tocador de mp3 basico, com as funcoes play() e close()
	java.io.InputStream arquivo;
	
	//contrutor tenta criar um fluxo com a localizacao do arquivo, cria uma instancia de tocadorDeMP3 e inicia a Thread
	public PlayerThread(String localizacao) throws FileNotFoundException, JavaLayerException
	{
		arquivo = (java.io.InputStream) new java.io.FileInputStream(localizacao);
		tocadorDeMP3 = new Player(arquivo);
		start();
	}
	
	//metodo que precisa ser implementado por qualquer classe que extenda Thread
	public void run()
	{
		//isComplete retorna true se todos os frames de audio MPEG foram tocados
		try 
		{
			tocadorDeMP3.play(); //play() toca a musica ateh o final, em principio
			if (tocadorDeMP3.isComplete())
			{
				encerrar();
			}
		} 
		catch (JavaLayerException e)
		{
			System.out.println("Erro no arquivo mp3. O programa sera encerrado.");
			System.exit(0);
		}
	}
	
	//metodo que encerra a musica a qualquer momento
	public void encerrar()
	{
		tocadorDeMP3.close();
		try
		{
			arquivo.close();
		} 
		catch (IOException e)
		{
			System.out.println("Erro ao tentar fechar o arquivo. O programa sera encerrado.");
			System.exit(0);
		}
		//interrompe este Thread
		this.interrupt();
	}
}