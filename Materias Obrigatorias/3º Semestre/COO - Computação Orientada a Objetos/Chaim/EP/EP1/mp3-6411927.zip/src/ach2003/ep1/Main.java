package ach2003.ep1;

import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		try
		{
		//cria o acervo mp3 que sera manipulado pelos metodos e interacao do usuario atraves do Scanner apontado para a entrada padrao
		AcervoMP3 acervoMP3 = new AcervoMP3();
		Scanner entradaPadrao = new Scanner(System.in);
		
		//tenta alterar o delimitador padr�o " " do Scanner.next para o marcador de nova linha
		try
		{
			//obtem o marcador de nova linha das propriedades do sistema
			entradaPadrao.useDelimiter(System.getProperty("line.separator"));
		}
		catch(SecurityException e)
		{
			//define diretamente os delimitadores com \r\n ou \n
			entradaPadrao.useDelimiter("\r\n|\n");
		}
		int escolha; //variavel usada para definir a instrucao que sera executada
		
		do
		{
			try
			{
				//le da entrada padrao uma opcao
				escolha = Integer.parseInt(entradaPadrao.nextLine());
			}
			//caso escolha receba uma opcao invalida, sai do laco (encerra o programa)
			catch(Exception e) 
			{
				break;
			}
			try
			{
				//as opcoes refletem as instrucoes do EP (auto-explicativo)
				//cada chamada de metodo le diretamento da entrada padrao seus argumentos, fazendo a conversao, quando apropriado, atraves de 'parse'
				if (escolha == 1)
				{
					try
					{
						acervoMP3.insereMP3(entradaPadrao.nextLine(), entradaPadrao.nextLine(), entradaPadrao.nextLine(), Double.parseDouble(entradaPadrao.nextLine()));
					}
					catch(NumberFormatException e) //caso seja fornecido argumento invalido para Double.parseDouble
					{
						System.out.println("Registro nao inserido");
					}
					continue;
				}
				if (escolha == 2)
				{
					acervoMP3.eliminaMP3(entradaPadrao.nextLine(), entradaPadrao.nextLine());
					continue;
				}
				if (escolha == 3)
				{
					acervoMP3.listaEmOrdemDeNome();
					continue;
				}
				if (escolha == 4)
				{
					acervoMP3.listaEmOrdemDeArtista();
					continue;
				}
				if (escolha == 5)
				{
					acervoMP3.listaMusicasDeArtista(entradaPadrao.nextLine());
					continue;
				}
				if (escolha == 6)
				{
					acervoMP3.selecionaAleatorioMusica();
					continue;
				}
				if (escolha == 7)
				{
					acervoMP3.selecionaAleatorioMusica(entradaPadrao.nextLine());
					continue;
				}
				//observacao: implementei seguindo as instrucoes da mensagem recebida via CoL
				if (escolha == 8)
				{
					acervoMP3.salvaAcervoMP3(acervoMP3, entradaPadrao.nextLine());
					continue;
				}
				//observacao: implementei seguindo as instrucoes da mensagem recebida via CoL
				if (escolha == 9)
				{
					acervoMP3 = acervoMP3.carregaAcervoMP3(acervoMP3, entradaPadrao.nextLine());
					continue;
				}
				if (escolha == 10)
				{
					acervoMP3.salvaMP3();
					continue;
				}
				if (escolha == 11)
				{
					acervoMP3 = acervoMP3.carregaMP3();
					continue;
				}
				if (escolha == 12)
				{
					try
					{
						acervoMP3.alteraMP3(Integer.parseInt(entradaPadrao.nextLine()), entradaPadrao.nextLine(), entradaPadrao.nextLine(), entradaPadrao.nextLine(), Double.parseDouble(entradaPadrao.nextLine()));
					}
					catch(NumberFormatException e) //caso seja fornecido argumento invalido para Double.parseDouble
					{
						System.out.println("Problemas na alteracao do arquivo");
					}
					continue;
				}
				if (escolha == 13)
				{
					try
					{
						acervoMP3.toca(entradaPadrao.nextLine(), entradaPadrao.nextLine(), entradaPadrao.nextLine(), Double.parseDouble(entradaPadrao.nextLine()));
					}
					catch(NumberFormatException e) //caso seja fornecido argumento invalido para Double.parseDouble
					{
						System.out.println("Registro inxistente");
					}
					continue;
				}
			}
			catch(NoSuchElementException e)
			{
				break;
			}
		}
		while (escolha > 0 && escolha < 14);
		entradaPadrao.close();
		}
		catch (UnsupportedOperationException e)
		{
			System.out.println("A operacao solicitada nao eh valida. O programa sera encerrado.");
			e.printStackTrace();
			System.exit(0);
		}
		catch(IllegalArgumentException e)
		{
			System.out.println("Metodo passou argumento ilegal. O programa sera encerrado.");
			e.printStackTrace();
			System.exit(0);
		}
		catch(IOException e)
		{
			System.out.println("Erro de E/S. O programa sera encerrado.");
			e.printStackTrace();
			System.exit(0);
		}
		
	}
}