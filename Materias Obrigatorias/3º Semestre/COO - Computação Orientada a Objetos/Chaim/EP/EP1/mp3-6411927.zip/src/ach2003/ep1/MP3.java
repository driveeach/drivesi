package ach2003.ep1;

import java.io.Serializable;

class MP3 implements Serializable
{
	private static final long serialVersionUID = 1L; //eclipse pede pra colocar isso, permite a serializacao
	
	//atributos
	private String musica;
	private String artista;
	private String localizacao;
	private Double preco = 0.0;
	
	//construtor
	MP3(String musica, String artista, String localizacao, Double preco)
	{
		//operador unario verifica se a string passada como parametro possui comprimento MAIOR que o definido nas instrucoes do ep
		//caso afirmativo, chama o metodo substring que passa os primeiros n caracteres para o atributo
		//caso negativo, atribui o parametro ao atributo
		
		this.musica = (musica.length() > 35) ? musica.substring(0, 35) : musica;
		this.artista = (artista.length() > 35) ? artista.substring(0, 35) : artista;
		this.localizacao = (localizacao.length() > 125) ? localizacao.substring(0, 125) : localizacao;
		
		//preco negativo torna-se zero, e arredonda o preco para o centavo imediatamente superior (parece preco de posto de gasolina!)
		this.preco = (preco > 0) ? Math.ceil(preco*100)/100 : 0.0;
	}
	
	//Todas as informacoes sobre o MP3 sao listadas; o conteudo de cada atributo e listado em uma linha
	void imprime()
	{
		System.out.println(this.musica);
		System.out.println(this.artista);
		System.out.println(this.localizacao);
		System.out.println(this.preco.toString());
	}
	
	//getters
	public String getMusica()		{ return musica; }
	public String getArtista() 		{ return artista; }
	public String getLocalizacao() 	{ return localizacao; }
	public Double getPreco() 		{ return preco; }
}
