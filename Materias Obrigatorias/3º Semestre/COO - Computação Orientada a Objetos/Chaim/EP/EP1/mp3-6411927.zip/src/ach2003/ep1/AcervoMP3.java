package ach2003.ep1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;
import javazoom.jl.decoder.JavaLayerException; //excecoes do tocador de mp3, arremessadas pelo contrutor do tocador

class AcervoMP3 implements Serializable
{
	private static final long serialVersionUID = 1L; 	//o eclipse pede para inserir
	private List<MP3> acervo; 							//atributo que armazena o acervo em uso
	
	//a chamada ao construtor cria um novo ArrayList de MP3
	AcervoMP3()
	{
		this.acervo = new ArrayList<MP3>();
	}

	//1. insere um novo MP3 que possui os valores passados por meio dos parametros nome, artista, localizacao e preco
	//   tenta dar add na lista, caso ocorra qualquer excecao o restro nao eh inserido
	void insereMP3(String nome, String artista, String localizacao, Double preco)
	{
		try
		{
			acervo.add(new MP3(nome, artista, localizacao, preco));
		}
		catch(Exception e)
		{
			System.out.println("Registro nao inserido");
		}
		System.out.println("Registro inserido");
	}
	
	//2. elimina um MP3 que possui os valores passados por meio dos parametros nome e artista
	//   caso ocorra alguma excecao, sera tratada pela classe Main
	void eliminaMP3(String nome, String artista) throws UnsupportedOperationException, IndexOutOfBoundsException
	{
		//percorremos o acervo, comparando nome e artista passado como os contidos na ArrayList
		for (int i = 0; i < acervo.size(); i++)
		{
			if (acervo.get(i).getMusica().compareTo(nome) == 0 && acervo.get(i).getArtista().compareTo(artista) == 0) 
			{
				//remove o elemento encontrado, imprime a mensagem e encerra o metodo
				acervo.remove(i);
				System.out.println("Registro eliminado");
				return;
			}
		}
		//percorreu todo o acervo e nao encontrou
		System.out.println("Registro inexistente");
	}
	
	//3. Lista em ordem alfabetica em funcao do nome da musica o conteudo do acervo
	//   Utiliza collections.sort e comparador de nome da musica para ordenar
	void listaEmOrdemDeNome()
	{
		if (acervo.size() == 0) System.out.println("Acervo de MP3 vazio");
		else
		{
			//Ordena o acervo, cria um iterador e percorre o acervo chamando o metodo imprimir() de cada elemento
			Collections.sort(acervo, new ComparadorDeNome());
			Iterator<MP3> it = acervo.listIterator();

			while(it.hasNext())
				it.next().imprime();
		}
	}

	//4. Lista em ordem alfabetica em funcao do nome do artista o conteudo do acervo
	//   utilizando collections.sort e comparador de nome do artista
	void listaEmOrdemDeArtista()
	{
		if (acervo.size() == 0) System.out.println("Acervo de MP3 vazio"); //acervo vazio
		else
		{
			//Ordena o acervo, cria um iterador e percorre o acervo chamando o metodo imprimir() de cada elemento
			Collections.sort(acervo, new ComparadorDeArtista());
			Iterator<MP3> it = acervo.listIterator();

			while(it.hasNext())
				it.next().imprime();
		}
	}
	
	//5. Lista as musicas de um determinado artista, exibindo todas as informacoes
	void listaMusicasDeArtista(String artista)
	{
		if (acervo.size() == 0) System.out.println("Acervo de MP3 vazio"); //teste acervo vazio
		else
		{
			//Ordena o acervo por nome de artista
			Collections.sort(acervo, new ComparadorDeArtista());
			
			//sinaliza se ao menos uma musica foi encontrada
			boolean imprimiu = false; 
			
			//percorremos o acervo ordenado
			for (int i =0; i < acervo.size(); i++)
			{
				if (acervo.get(i).getArtista().compareTo(artista) == 0)
				{
					imprimiu = true;
					acervo.get(i).imprime();
				}
			}
			//se nenhuma musica foi impressa, informa (retorno conforme as especificacoes do EP)
			if (!imprimiu) System.out.println("Acervo de MP3 vazio");
		}
	}
	
	//6. Seleciona aleatoriamente uma musica do acervo e lista seus dados
	//   Utiliza Collections.shuffle para embaralhar o acervo e em seguida imprime o primeiro elemento da lista
	void selecionaAleatorioMusica() throws UnsupportedOperationException
	{
		if (acervo.size() == 0) System.out.println("Acervo de MP3 vazio"); //teste acervo vazio
		else
		{
			Collections.shuffle(acervo);
			acervo.get(0).imprime();
		}
	}
	
	//7. Seleciona aleatoriamente uma musica do artista e lista seus dados
    //   Utiliza Collections.shuffle para embaralhar o acervo e em seguida busca e imprime a primeira musica encontrada do artista
	void selecionaAleatorioMusica(String artista)
	{
		if (acervo.size() == 0) System.out.println("Acervo de MP3 vazio"); //teste acervo vazio
		else
		{
			Collections.shuffle(acervo);
			ListIterator<MP3> it = acervo.listIterator();

			//enquanto houver elementos, percorre a lista embaralhada e se encontrar uma musica do artista desejado, imprime e encerra o metodo
			while(it.hasNext())
			{
				if (acervo.get(it.nextIndex()).getArtista().compareTo(artista) == 0)
				{	
					it.next().imprime();
					return;
				}
				it.next();
			}
			System.out.println("Acervo de MP3 vazio");
		}
		
	}
	//8. Salva um objeto AcervoMP3 em um arquivo cujo nome eh "nomearq"
	void salvaAcervoMP3(AcervoMP3 acervo, String nomearq)
	{
		//cria os fluxos de saida do arquivo e objeto
		FileOutputStream fos = null;
		ObjectOutputStream out = null;
		//tenta realizar a serializacao. exibe mensagem se houver excecao
		try
		{
			fos = new FileOutputStream(nomearq);
			out = new ObjectOutputStream(fos);
			out.writeObject(acervo);
			out.close();
			System.out.println("Arquivo salvo");
		}
		catch(FileNotFoundException ex)
		{
			System.out.println("Problemas no salvamento do arquivo");
		}
		catch(IOException ex)
		{
			System.out.println("Problemas no salvamento do arquivo");
		}
		catch(SecurityException ex)
		{
			System.out.println("Problemas no salvamento do arquivo");
		}
	}
	
	//9. Carrega um objeto AcervoMP3 a partir de arquivo "nomearq".
	AcervoMP3 carregaAcervoMP3(AcervoMP3 acervo, String nomearq)
	{
		//cria os fluxos de entrada do arquivo e objeto
		FileInputStream fis = null;
		ObjectInputStream in = null;
		//tenta devolver um acervo serializado. exibe mensagem se houver excecao
		try
		{
			fis = new FileInputStream(nomearq);
			in = new ObjectInputStream(fis);
			acervo = (AcervoMP3)in.readObject();
			in.close();
			System.out.println("Arquivo carregado");
		}
		catch(FileNotFoundException ex)
		{
			System.out.println("Problemas no carregamento do arquivo"); 
		}
		catch(IOException ex)
		{
			System.out.println("Problemas no carregamento do arquivo"); 
			ex.printStackTrace();
		}
		catch(ClassNotFoundException ex)
		{
			System.out.println("Problemas no carregamento do arquivo"); 
			ex.printStackTrace();
		}
		return acervo;
	}
	//10. Salva os MP3 do acervo em um arquivo "MP3.acv", esvaziando o acervo atual
	void salvaMP3()
	{	
		try
		{
			//cria um fluxo de saida de dados, para escrever no arquivo MP3.acv
			DataOutputStream outfile = new DataOutputStream(new FileOutputStream("MP3.acv"));

			//repete as instrucoes enquanto houver elementos no acervo
			while (!acervo.isEmpty())
			{
				//retira o MP3 atual do acervo, entao grava seus dados no arquivo com tamanho fixo, utilizando StringBuffer
				MP3 atual = acervo.remove(0); //remove e retorna o MP3 atual

				//gravar nome da musica
				StringBuffer sb = new StringBuffer(atual.getMusica());
				sb.setLength(35);
				outfile.writeChars(sb.toString()+'\n');
				//gravar nome do artista
				sb = new StringBuffer(atual.getArtista());
				sb.setLength(35);
				outfile.writeChars(sb.toString()+'\n');
				//gravar localizacao
				sb = new StringBuffer(atual.getLocalizacao());
				sb.setLength(125);
				outfile.writeChars(sb.toString()+'\n');
				//gravar preco
				outfile.writeDouble(atual.getPreco());
				outfile.writeChar('\n');
			}

			outfile.close();
			System.out.println("Arquivo salvo");
		}
		catch(Exception e)
		{
			System.out.println("Problemas no salvamento do arquivo");
		}
	}
	
	//11. Carrega os MP3 salvos no arquivo "MP3.acv" em um objeto AcervoMP3
	AcervoMP3 carregaMP3() throws NullPointerException, UnsupportedOperationException, ClassCastException, IllegalArgumentException, IOException
	{
		//cria um novo acervo que recebera os dados lidos do arquivo e sera retornado
		AcervoMP3 acervo = new AcervoMP3();
		
		//cria um fluxo de entrada de dados, para ler do arquivo MP3.acv
		DataInputStream inputfile = null;
		try 
		{
			inputfile = new DataInputStream(new FileInputStream("MP3.acv"));
		}
		catch (FileNotFoundException e)
		{
			System.out.println("Problemas no carregamento do arquivo");
			return acervo;
		}
		try
		{
			//cria arrays de char e um double que armanezarao os dados lidos
			char lmusica[] = new char[35];
			char lartista[] = new char[35];
			char llocalizacao[] = new char[125];
			double preco;

			//repete a tarefa ateh atingir o fim do arquivo, quando lancara uma EOFException
			while (true)
			{
				//le as sequancias de caracteres e coloca nos arrays de caracteres apropriados
				for(int i=0;i<35;i++) lmusica[i] = inputfile.readChar();
				inputfile.readChar(); //separador \n ignorado
				for(int i=0;i<35;i++) lartista[i] = inputfile.readChar();
				inputfile.readChar(); //separador \n ignorado
				for(int i=0;i<125;i++) llocalizacao[i] = inputfile.readChar();
				inputfile.readChar(); //separador \n ignorado
				preco = inputfile.readDouble(); //le o double
				inputfile.readChar(); //separador \n ignorado

				//variaveis que serao passadas como argumento para criar um MP3, chama
				String nome = tiraEspacos(lmusica, 35); 
				String artista = tiraEspacos(lartista, 35);
				String localizacao = tiraEspacos(llocalizacao, 125);
				
				//adiciona uma nova MP3 na ArrayList, utilizando as informacoes lidas 
				acervo.acervo.add(new MP3(nome, artista, localizacao, preco));
			}
		}
		//atingiu o fim do arquivo, fecha o fluxo de entrada de dados e retorna o acervo criado
		catch (EOFException ioe)
		{
			inputfile.close();
			System.out.println("Arquivo carregado");
			return acervo;
		}
	}
	
	//metodo recebe array de caracteres e converte em String, removendo os espacos em branco no fim das palavras
	String tiraEspacos(char[] seq, int tam)
	{
		int j = 0;
		//conta os espacos em branco
		for(int i=0;i<tam;i++)
			if (seq[i] == '\0') j++;
		String palavra = new String (seq);
		//ajusta o comprimento da string para descartar os espacos em branco apos o fim da palavra
		palavra = palavra.substring(0, seq.length - j);
		return palavra;
	}
	

	//12. Altera o n-esimo MP3 salvo em "MP3.acv" com os valores passados por meio dos parametros.
	void alteraMP3(int n, String nome, String artista, String localizacao, Double preco)
	{
		//calcula o 'salto' 
		int tamanhoDoRegistro = 2 * 35 + 			//tamanho do campo nome em arquivo
								2 * 35 +			//tamanho do campo artista em arquivo
								2 * 125 +			//tamanho da campo localizacao em arquivo
								(Double.SIZE/8)+	//tamanho do campo preco em arquivo
								4 * 2;				//tamanho dos '\n'
		try 
		{
			//cria um fluxo de acesso randomico que permite acessar uma posicao do arquivo diretamente
			RandomAccessFile arquivo = new RandomAccessFile("MP3.acv","rw");
			//testa se o n-esimo MP3 esta no arquivo de fato
			if ((n * tamanhoDoRegistro) < arquivo.length()) 
			{
				//posicionar o ponteiro no registro adequado
				arquivo.seek(n * tamanhoDoRegistro);

				//sobrescreve os campos com as informacoes passadas como parametro, utilizando StringBuffers, para manter o tamanho fixo
				StringBuffer sb = new StringBuffer(nome);
				sb.setLength(35);
				arquivo.writeChars(sb.toString());
				arquivo.writeChar('\n');

				sb = new StringBuffer(artista);
				sb.setLength(35);
				arquivo.writeChars(sb.toString());
				arquivo.writeChar('\n');

				sb = new StringBuffer(localizacao);
				sb.setLength(125);
				arquivo.writeChars(sb.toString());
				arquivo.writeChar('\n');

				//escreve o double passado como parametro o double
				arquivo.writeDouble(preco);
				arquivo.writeChar('\n');

				//confirma alteracao
				System.out.println("Arquivo alterado");
			}
			else
			{
				//caso o n-esimo registro nao exista ou seja invalido, resposta conforme instrucoes do EP
				System.out.println("Problemas na alteracao arquivo");
			}
			//encerra o fluxo
			arquivo.close();
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Problemas na alteracao arquivo");
		} 
		catch (IOException e)
		{
			System.out.println("Problemas na alteracao arquivo");
		}
	}
	
	//13. Toca o MP3, desde que esteja no acervo e sua localizacao seja valida
	//    Mais detalhes em readme.txt
	public void toca(String nome, String artista, String localizacao, double preco) throws IOException
	{	
		//cria um iterador de acervo e realiza busca.
		ListIterator<MP3> it = acervo.listIterator();
		MP3 atual;	//guarda o mp3 retornado pelo metodo next() do iterador
		while(it.hasNext())
		{
			atual = it.next();
			//verificar se eh o arquivo procurado
			if (atual.getMusica().compareTo(nome) == 0 && atual.getArtista().compareTo(artista) == 0 && atual.getLocalizacao().compareTo(localizacao) == 0 && atual.getPreco() == preco) 
			{
				try
				{
					PlayerThread tocaMP3 = new PlayerThread(atual.getLocalizacao());  //thread que toca a musica (utiliza JLayer) 
					int sair = 0; //utilizado para permitir que o usuario encerre a execucao da musica a qualquer momento
					
					//informa qual a musica sendo tocada e da instrucoes
					System.out.println("Tocando a musica "+ atual.getMusica() +".\nTecle 1 para encerrar a execucao e voltar para o menu.");
					
					//solicita interacao do usuario pela entrada padrao ate que forneca 1 ou que a musica chegue no final
					do
					{
						try
						{
							//musica chegou no final, informa e sai do metodo
							if (tocaMP3.tocadorDeMP3.isComplete())
							{
								System.out.println(atual.getMusica() + " tocou ate o final.");
								break;
							}
							
							//leitura das opcoes do usuario
							sair = Integer.parseInt(new Scanner(System.in).nextLine());
						}
						//caso receba uma opcao invalida, tenta novamente
						catch(Exception e)
						{ 
							continue;
						}
						//caso receba a opcao valida, encerra o thread, informa o usuario e encerra o metodo
						if (sair == 1)
						{
							tocaMP3.encerrar(); 
							System.out.println("Musica " + atual.getMusica() + " fechada pelo usuario.");
							return;
						}
					}
					while(sair != 1);
				}
				//avisa que o elemento esta no acervo entretando a localizacao do arquivo nao eh valida
				catch(FileNotFoundException e)
				{
					System.out.println("Arquivo nao encontrado em: "+ atual.getLocalizacao());
				} 
				//erros internos do JLayer
				catch (JavaLayerException e)
				{
					System.out.println("Erro no arquivo mp3, aplicativo sera encerrado.");
					System.exit(0);
				}
		        return;
			}
		}
		//percorreu a lista toda e nao encontrou o elemento procurado
		System.out.println("Registro inexistente");
	}
}